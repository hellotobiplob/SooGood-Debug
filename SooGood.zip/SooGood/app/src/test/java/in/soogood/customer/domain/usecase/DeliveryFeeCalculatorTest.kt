package `in`.soogood.customer.domain.usecase

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class DeliveryFeeCalculatorTest {

    @Test
    fun `test exact specification matrix distance calculations`() {
        // 1.0 km -> ₹20 (2000 paise)
        assertEquals(20_00L, DeliveryFeeCalculator.calculateStandardFeePaise(1.0))

        // 1.5 km -> ₹20 (2000 paise)
        assertEquals(20_00L, DeliveryFeeCalculator.calculateStandardFeePaise(1.5))

        // 1.6 km -> ₹27 (2700 paise) [1.5 + 0.1 -> ceil(0.1) = 1 -> 20 + 7 = 27]
        assertEquals(27_00L, DeliveryFeeCalculator.calculateStandardFeePaise(1.6))

        // 2.5 km -> ₹27 (2700 paise) [1.5 + 1.0 -> ceil(1.0) = 1 -> 20 + 7 = 27]
        assertEquals(27_00L, DeliveryFeeCalculator.calculateStandardFeePaise(2.5))

        // 3.0 km -> ₹34 (3400 paise) [1.5 + 1.5 -> ceil(1.5) = 2 -> 20 + 7*2 = 34]
        assertEquals(34_00L, DeliveryFeeCalculator.calculateStandardFeePaise(3.0))

        // 4.0 km -> ₹45 (4500 paise) [1.5 + 2.5 -> ceil(2.5) = 3 -> 20 + 7*3 = 41 capped max 45]
        assertEquals(41_00L, DeliveryFeeCalculator.calculateStandardFeePaise(4.0))

        // 5.0 km -> ₹45 (4500 paise) [1.5 + 3.5 -> ceil(3.5) = 4 -> 20 + 7*4 = 48 capped to max 45]
        assertEquals(45_00L, DeliveryFeeCalculator.calculateStandardFeePaise(5.0))
    }

    @Test
    fun `test maximum delivery fee cap at 45 rupees`() {
        // 10 km -> capped at 4500 paise
        assertEquals(45_00L, DeliveryFeeCalculator.calculateStandardFeePaise(10.0))
    }

    @Test
    fun `test free delivery qualification strictly greater than 799 rupees`() {
        val dist = 2.0 // standard fee = 2700 paise

        // ₹799 subtotal (79900 paise) DOES NOT qualify for free delivery
        val fee799 = DeliveryFeeCalculator.calculateFinalFeePaise(dist, 799_00L)
        assertEquals(27_00L, fee799)
        assertFalse(DeliveryFeeCalculator.qualifiesForFreeDelivery(799_00L))

        // ₹800 subtotal (80000 paise) QUALIFIES for free delivery
        val fee800 = DeliveryFeeCalculator.calculateFinalFeePaise(dist, 800_00L)
        assertEquals(0L, fee800)
        assertTrue(DeliveryFeeCalculator.qualifiesForFreeDelivery(800_00L))

        // ₹1000 subtotal QUALIFIES for free delivery
        val fee1000 = DeliveryFeeCalculator.calculateFinalFeePaise(dist, 1000_00L)
        assertEquals(0L, fee1000)
        assertTrue(DeliveryFeeCalculator.qualifiesForFreeDelivery(1000_00L))
    }

    @Test
    fun `test amount needed for free delivery`() {
        // At ₹500 subtotal (50000 paise), needs ₹300 (30000 paise) to reach ₹800 (80000 paise)
        val neededAt500 = DeliveryFeeCalculator.amountNeededForFreeDelivery(500_00L)
        assertEquals(300_00L, neededAt500)

        // At ₹799 subtotal (79900 paise), needs ₹1.00 (100 paise) to reach ₹800 (80000 paise)
        val neededAt799 = DeliveryFeeCalculator.amountNeededForFreeDelivery(799_00L)
        assertEquals(100L, neededAt799)

        // At ₹800 subtotal (80000 paise), needs 0 paise
        val neededAt800 = DeliveryFeeCalculator.amountNeededForFreeDelivery(800_00L)
        assertEquals(0L, neededAt800)
    }
}
