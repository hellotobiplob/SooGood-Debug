package `in`.soogood.customer.domain.model

import kotlinx.serialization.Serializable

@Serializable
data class Address(
    val id: String,
    val title: String, // e.g. "Home", "Work", "Other"
    val fullAddress: String,
    val landmark: String? = null,
    val latitude: Double = 12.9716,
    val longitude: Double = 77.5946,
    val isDefault: Boolean = false,
    val receiverName: String? = null,
    val receiverPhone: String? = null,
    val addressType: String = "Home"
)
