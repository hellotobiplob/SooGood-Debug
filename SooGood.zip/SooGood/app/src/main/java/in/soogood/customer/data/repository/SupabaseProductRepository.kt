package `in`.soogood.customer.data.repository

import `in`.soogood.customer.data.remote.DbMenuItem
import `in`.soogood.customer.data.remote.SupabaseRepository
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Product
import `in`.soogood.customer.domain.repository.ProductRepository

class SupabaseProductRepository(
    private val supabaseRemote: SupabaseRepository = SupabaseRepository()
) : ProductRepository {

    override suspend fun getProductsForRestaurant(restaurantId: String): List<Product> {
        val remoteItems = supabaseRemote.fetchMenuItems(restaurantId)
        return remoteItems.map { it.toProduct(CartType.FOOD, restaurantId = restaurantId) }
    }

    override suspend fun getProductsForStore(storeId: String): List<Product> {
        val remoteItems = supabaseRemote.fetchMenuItems(storeId)
        return remoteItems.map { it.toProduct(CartType.HYPERMART, storeId = storeId) }
    }

    override suspend fun getProductById(productId: String): Product? {
        val allStores = supabaseRemote.fetchStores()
        for (store in allStores) {
            val storeId = store.id ?: continue
            val items = supabaseRemote.fetchMenuItems(storeId)
            val item = items.find { it.id == productId }
            if (item != null) {
                val cartType = if (store.storeType.equals("RESTAURANT", ignoreCase = true)) CartType.FOOD else CartType.HYPERMART
                return item.toProduct(cartType, restaurantId = if (cartType == CartType.FOOD) storeId else null, storeId = if (cartType == CartType.HYPERMART) storeId else null)
            }
        }
        return null
    }

    override suspend fun searchProducts(query: String, cartType: CartType): List<Product> {
        if (query.isBlank()) return emptyList()
        val q = query.lowercase().trim()
        val allStores = supabaseRemote.fetchStores()
        val matchingProducts = mutableListOf<Product>()

        for (store in allStores) {
            val isRest = store.storeType.equals("RESTAURANT", ignoreCase = true)
            val storeCartType = if (isRest) CartType.FOOD else CartType.HYPERMART
            if (storeCartType != cartType) continue

            val storeId = store.id ?: continue
            val items = supabaseRemote.fetchMenuItems(storeId)
            items.forEach { item ->
                if (item.name.lowercase().contains(q) || (item.category.lowercase().contains(q))) {
                    matchingProducts.add(item.toProduct(cartType, restaurantId = if (isRest) storeId else null, storeId = if (!isRest) storeId else null))
                }
            }
        }
        return matchingProducts
    }

    override suspend fun getProductsUnderPrice(cartType: CartType, maxPricePaise: Long): List<Product> {
        val allStores = supabaseRemote.fetchStores()
        val productsUnderPrice = mutableListOf<Product>()

        for (store in allStores) {
            val isRest = store.storeType.equals("RESTAURANT", ignoreCase = true)
            val storeCartType = if (isRest) CartType.FOOD else CartType.HYPERMART
            if (storeCartType != cartType) continue

            val storeId = store.id ?: continue
            val items = supabaseRemote.fetchMenuItems(storeId)
            items.forEach { item ->
                val prod = item.toProduct(cartType, restaurantId = if (isRest) storeId else null, storeId = if (!isRest) storeId else null)
                if (prod.pricePaise <= maxPricePaise) {
                    productsUnderPrice.add(prod)
                }
            }
        }
        return productsUnderPrice
    }

    private fun DbMenuItem.toProduct(
        cartType: CartType,
        restaurantId: String? = null,
        storeId: String? = null
    ): Product {
        val img = photoUrl.takeIf { !it.isNullOrBlank() }
            ?: imageUrl.takeIf { !it.isNullOrBlank() }
            ?: "https://picsum.photos/seed/${name.hashCode()}/300/300"
        return Product(
            id = id ?: "item_${name.hashCode()}",
            restaurantId = restaurantId,
            storeId = storeId,
            name = name,
            description = description ?: "",
            pricePaise = (price * 100).toLong(),
            imageUrl = img,
            isVeg = isVeg ?: true,
            isBestseller = true,
            isAvailable = isAvailable ?: true,
            category = category,
            cartType = cartType
        )
    }
}
