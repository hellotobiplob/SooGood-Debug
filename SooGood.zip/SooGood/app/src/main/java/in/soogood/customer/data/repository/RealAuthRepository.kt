package `in`.soogood.customer.data.repository

import `in`.soogood.customer.domain.model.User
import `in`.soogood.customer.domain.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RealAuthRepository : AuthRepository {

    private val _currentUser = MutableStateFlow<User?>(null)
    override val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    override suspend fun signUpWithEmail(
        email: String,
        password: String,
        name: String,
        mobileNumber: String
    ): Result<User> {
        val user = User(
            id = "usr_${System.currentTimeMillis()}",
            name = if (name.isNotBlank()) name else email.substringBefore("@"),
            mobileNumber = mobileNumber,
            email = email,
            isGuest = false
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun signInWithEmail(email: String, password: String): Result<User> {
        val user = User(
            id = "usr_${System.currentTimeMillis()}",
            name = email.substringBefore("@"),
            mobileNumber = "",
            email = email,
            isGuest = false
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun signInWithGoogle(idToken: String, name: String, mobileNumber: String): Result<User> {
        val user = User(
            id = "usr_${System.currentTimeMillis()}",
            name = name,
            mobileNumber = mobileNumber,
            isGuest = false
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun checkAndSignInExistingGoogleUser(idToken: String): Result<User?> {
        return Result.success(null)
    }

    override suspend fun updateProfile(name: String, mobileNumber: String): Result<User> {
        val current = _currentUser.value ?: User(
            id = "usr_${System.currentTimeMillis()}",
            name = name,
            mobileNumber = mobileNumber
        )
        val updated = current.copy(name = name, mobileNumber = mobileNumber)
        _currentUser.value = updated
        return Result.success(updated)
    }

    override suspend fun requestOtp(mobileNumber: String): Result<Boolean> {
        return Result.success(true)
    }

    override suspend fun verifyOtp(mobileNumber: String, otp: String): Result<User> {
        val user = User(
            id = "usr_${System.currentTimeMillis()}",
            name = "Customer",
            mobileNumber = mobileNumber,
            isGuest = false
        )
        _currentUser.value = user
        return Result.success(user)
    }

    override suspend fun logout() {
        _currentUser.value = null
    }
}
