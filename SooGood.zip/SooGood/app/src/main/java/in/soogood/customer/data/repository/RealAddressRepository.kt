package `in`.soogood.customer.data.repository

import android.content.Context
import `in`.soogood.customer.domain.model.Address
import `in`.soogood.customer.domain.repository.AddressRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

class RealAddressRepository(
    private val context: Context? = null
) : AddressRepository {

    private val prefs = context?.getSharedPreferences("soogood_addresses_prefs", Context.MODE_PRIVATE)

    private val _addresses = MutableStateFlow<List<Address>>(loadSavedAddresses())
    override val addresses: StateFlow<List<Address>> = _addresses.asStateFlow()

    private val _selectedAddress = MutableStateFlow<Address?>(_addresses.value.firstOrNull())
    override val selectedAddress: StateFlow<Address?> = _selectedAddress.asStateFlow()

    private fun loadSavedAddresses(): List<Address> {
        val jsonStr = prefs?.getString("saved_addresses_json", null) ?: return emptyList()
        return try {
            Json.decodeFromString<List<Address>>(jsonStr)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveAddressesToStorage(list: List<Address>) {
        try {
            val jsonStr = Json.encodeToString(list)
            prefs?.edit()?.putString("saved_addresses_json", jsonStr)?.apply()
        } catch (_: Exception) {}
    }

    override suspend fun selectAddress(addressId: String) {
        val selected = _addresses.value.find { it.id == addressId }
        if (selected != null) {
            _selectedAddress.value = selected
        }
    }

    override suspend fun addAddress(address: Address) {
        val updated = _addresses.value + address
        _addresses.value = updated
        if (address.isDefault || _selectedAddress.value == null) {
            _selectedAddress.value = address
        }
        saveAddressesToStorage(updated)
    }

    override suspend fun updateAddress(address: Address) {
        val current = _addresses.value
        val updated = current.map { if (it.id == address.id) address else it }
        _addresses.value = updated
        if (_selectedAddress.value?.id == address.id) {
            _selectedAddress.value = address
        }
        saveAddressesToStorage(updated)
    }

    override suspend fun deleteAddress(addressId: String) {
        val updated = _addresses.value.filterNot { it.id == addressId }
        _addresses.value = updated
        if (_selectedAddress.value?.id == addressId) {
            _selectedAddress.value = updated.firstOrNull()
        }
        saveAddressesToStorage(updated)
    }
}
