package `in`.soogood.customer.domain.model

data class CustomizationOption(
    val id: String,
    val name: String,
    val pricePaise: Long = 0L
)

data class CustomizationGroup(
    val id: String,
    val title: String,
    val isRequired: Boolean = false,
    val maxSelections: Int = 1,
    val options: List<CustomizationOption> = emptyList()
)
