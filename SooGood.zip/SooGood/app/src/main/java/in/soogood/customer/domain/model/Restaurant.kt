package `in`.soogood.customer.domain.model

data class Restaurant(
    val id: String,
    val name: String,
    val cuisine: String,
    val rating: Double,
    val totalRatingsCount: Int,
    val deliveryTimeMinutes: Int,
    val distanceKm: Double,
    val imageUrl: String,
    val isVegOnly: Boolean = false,
    val offerText: String? = null,
    val isOpen: Boolean = true,
    val latitude: Double = 12.9716,
    val longitude: Double = 77.5946
)
