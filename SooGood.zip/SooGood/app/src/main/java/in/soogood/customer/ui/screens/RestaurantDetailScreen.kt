package `in`.soogood.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

import `in`.soogood.customer.domain.model.CartItem
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Product
import `in`.soogood.customer.domain.model.Restaurant
import `in`.soogood.customer.domain.model.Store
import `in`.soogood.customer.ui.components.MerchantConflictDialog
import `in`.soogood.customer.ui.components.ProductCard
import `in`.soogood.customer.ui.components.VegNonVegBadge
import `in`.soogood.customer.ui.theme.SooGoodPrimaryGreen
import `in`.soogood.customer.ui.viewmodel.CartViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RestaurantDetailScreen(
    merchantId: String,
    cartType: CartType,
    cartViewModel: CartViewModel,
    onBackClick: () -> Unit,
    onCartClick: () -> Unit
) {
    var restaurant by remember { mutableStateOf<Restaurant?>(null) }
    var store by remember { mutableStateOf<Store?>(null) }
    var products by remember { mutableStateOf<List<Product>>(emptyList()) }
    var isVegOnly by remember { mutableStateOf(false) }

    val foodCart by cartViewModel.foodCart.collectAsState()
    val hypermartCart by cartViewModel.hypermartCart.collectAsState()
    val activeCart = if (cartType == CartType.FOOD) foodCart else hypermartCart

    val conflictState by cartViewModel.merchantConflictState.collectAsState()

    LaunchedEffect(merchantId) {
        val storeRepo = `in`.soogood.customer.data.repository.SupabaseStoreRepository()
        val productRepo = `in`.soogood.customer.data.repository.SupabaseProductRepository()

        if (cartType == CartType.FOOD) {
            restaurant = storeRepo.getRestaurantById(merchantId)
            products = productRepo.getProductsForRestaurant(merchantId)
        } else {
            store = storeRepo.getStoreById(merchantId)
            products = productRepo.getProductsForStore(merchantId)
        }
    }

    val merchantName = restaurant?.name ?: store?.name ?: "Merchant"
    val merchantDist = restaurant?.distanceKm ?: store?.distanceKm ?: 1.5

    conflictState?.let { conflict ->
        MerchantConflictDialog(
            conflict = conflict,
            onConfirmReplace = { cartViewModel.confirmReplaceCart() },
            onDismiss = { cartViewModel.dismissConflictDialog() }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(merchantName, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {
                // Header Info Card
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    color = MaterialTheme.colorScheme.surface,
                    shape = RoundedCornerShape(16.dp),
                    shadowElevation = 2.dp
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = merchantName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = restaurant?.cuisine ?: store?.category ?: "",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = SooGoodPrimaryGreen, shape = RoundedCornerShape(6.dp)) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        Icons.Default.Star,
                                        contentDescription = null,
                                        tint = Color.White,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text(
                                        text = (restaurant?.rating ?: store?.rating ?: 4.5).toString(),
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "${restaurant?.deliveryTimeMinutes ?: store?.estimatedDeliveryMinutes ?: 25} mins • $merchantDist km",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Veg Toggle
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = isVegOnly,
                        onClick = { isVegOnly = !isVegOnly },
                        label = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                VegNonVegBadge(isVeg = true)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Veg Only")
                            }
                        }
                    )
                }

                // Products List
                val displayedProducts = if (isVegOnly) products.filter { it.isVeg } else products

                LazyColumn(
                    contentPadding = PaddingValues(
                        start = 16.dp,
                        end = 16.dp,
                        top = 16.dp,
                        bottom = if (activeCart.itemCount > 0) 90.dp else 16.dp
                    ),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(displayedProducts) { prod ->
                        val existingItem = activeCart.items.find { it.product.id == prod.id }
                        val currentQty = existingItem?.quantity ?: 0

                        ProductCard(
                            product = prod,
                            cartQuantity = currentQty,
                            onAddClick = {
                                cartViewModel.addToCart(
                                    item = CartItem(
                                        id = "item_${prod.id}",
                                        product = prod,
                                        quantity = 1,
                                        selectedWeightVariant = prod.weightVariants.firstOrNull()
                                    ),
                                    merchantId = merchantId,
                                    merchantName = merchantName,
                                    distanceKm = merchantDist
                                )
                            },
                            onIncrease = {
                                cartViewModel.updateQuantity(cartType, existingItem?.id ?: "", currentQty + 1)
                            },
                            onDecrease = {
                                cartViewModel.updateQuantity(cartType, existingItem?.id ?: "", currentQty - 1)
                            }
                        )
                    }
                }
            }

            // FLOATING BOTTOM VIEW CART BANNER
            if (activeCart.itemCount > 0) {
                val totalRupees = activeCart.subtotalPaise / 100
                val itemCountText = "${activeCart.itemCount} ${if (activeCart.itemCount > 1) "ITEMS" else "ITEM"}"

                Surface(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(16.dp)
                        .fillMaxWidth()
                        .clickable { onCartClick() },
                    shape = RoundedCornerShape(16.dp),
                    color = SooGoodPrimaryGreen,
                    shadowElevation = 8.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 18.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "$itemCountText • ₹$totalRupees",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "From ${activeCart.merchantName ?: merchantName}",
                                color = Color.White.copy(alpha = 0.85f),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "View Cart",
                                color = Color.White,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Icon(
                                imageVector = Icons.Default.ShoppingCart,
                                contentDescription = "Cart",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
