package `in`.soogood.customer.data.repository

import android.util.Log
import com.google.firebase.database.FirebaseDatabase
import `in`.soogood.customer.data.remote.DbStore
import `in`.soogood.customer.domain.model.Restaurant
import `in`.soogood.customer.domain.model.Store
import `in`.soogood.customer.domain.repository.StoreRepository
import kotlinx.coroutines.tasks.await

class FirebaseStoreRepository : StoreRepository {

    private val dbRef = FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com").getReference("stores")

    private fun getFallbackStores(): List<DbStore> {
        return listOf(
            DbStore(
                id = "rest_01",
                name = "SooGood Royal Biryani",
                storeType = "RESTAURANT",
                address = "Nazirpur, Nadia",
                latitude = 23.9922,
                longitude = 88.5833,
                phone = "+919732145678",
                isOpen = true,
                rating = 4.8,
                imageUrl = "https://picsum.photos/seed/biryani/400/250"
            ),
            DbStore(
                id = "store_01",
                name = "SooGood Fresh Mart",
                storeType = "DARKSTORE",
                address = "Station Road, Krishnanagar",
                latitude = 23.9950,
                longitude = 88.5800,
                phone = "+919732145679",
                isOpen = true,
                rating = 4.6,
                imageUrl = "https://picsum.photos/seed/mart/400/250"
            )
        )
    }

    private suspend fun fetchStoresFromFirebase(): List<DbStore> {
        return try {
            val snapshot = dbRef.get().await()
            val list = mutableListOf<DbStore>()
            for (child in snapshot.children) {
                val store = child.getValue(DbStore::class.java)
                if (store != null) {
                    list.add(store.copy(id = store.id ?: child.key))
                }
            }
            if (list.isEmpty()) {
                getFallbackStores()
            } else {
                list
            }
        } catch (e: Exception) {
            Log.e("FirebaseStoreRepo", "Error fetching stores from Firebase RTDB (Permission denied or network error), using fallback mock stores", e)
            getFallbackStores()
        }
    }

    override suspend fun getFoodRestaurants(): List<Restaurant> {
        val remoteStores = fetchStoresFromFirebase()
        return remoteStores
            .filter { it.storeType == null || it.storeType.equals("RESTAURANT", ignoreCase = true) }
            .map { it.toRestaurant() }
    }

    override suspend fun getHypermartStores(): List<Store> {
        val remoteStores = fetchStoresFromFirebase()
        return remoteStores
            .filter { it.storeType != null && !it.storeType.equals("RESTAURANT", ignoreCase = true) }
            .map { it.toStore() }
    }

    override suspend fun getRestaurantById(id: String): Restaurant? {
        return getFoodRestaurants().find { it.id == id }
    }

    override suspend fun getStoreById(id: String): Store? {
        return getHypermartStores().find { it.id == id }
    }

    private fun DbStore.toRestaurant(): Restaurant {
        val lat = latitude ?: 23.9922
        val lng = longitude ?: 88.5833
        val isRestaurantOpen = isOpen ?: true
        return Restaurant(
            id = id ?: "rest_${name.hashCode()}",
            name = name,
            cuisine = "Food & Beverages",
            rating = rating ?: 4.5,
            totalRatingsCount = 120,
            deliveryTimeMinutes = 30,
            distanceKm = 1.5,
            imageUrl = imageUrl.takeIf { !it.isNullOrBlank() } ?: "https://picsum.photos/seed/${name.hashCode()}/400/250",
            isVegOnly = false,
            offerText = if (isRestaurantOpen) "OPEN" else "CLOSED",
            isOpen = isRestaurantOpen,
            latitude = lat,
            longitude = lng
        )
    }

    private fun DbStore.toStore(): Store {
        val lat = latitude ?: 23.9922
        val lng = longitude ?: 88.5833
        val isStoreOpen = isOpen ?: true
        return Store(
            id = id ?: "store_${name.hashCode()}",
            name = name,
            category = "Groceries & Fresh Products",
            rating = rating ?: 4.5,
            distanceKm = 1.5,
            estimatedDeliveryMinutes = 45,
            imageUrl = imageUrl.takeIf { !it.isNullOrBlank() } ?: "https://picsum.photos/seed/${name.hashCode()}/400/250",
            offerText = if (isStoreOpen) "OPEN" else "CLOSED",
            isOpen = isStoreOpen,
            latitude = lat,
            longitude = lng
        )
    }
}
