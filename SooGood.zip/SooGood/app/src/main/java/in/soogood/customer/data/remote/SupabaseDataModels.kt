package `in`.soogood.customer.data.remote

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class DbStore(
    val id: String? = null,
    val name: String = "Merchant Store",
    @SerialName("store_type") val storeType: String? = "RESTAURANT", // RESTAURANT, DARKSTORE
    val address: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val phone: String? = null,
    @SerialName("is_open") val isOpen: Boolean? = true,
    @SerialName("status") val status: String? = null,
    val rating: Double? = 4.5,
    @SerialName("image_url") val imageUrl: String? = null
)

@Serializable
data class DbMenuItem(
    val id: String? = null,
    @SerialName("store_id") val storeId: String = "",
    val name: String = "Item",
    val description: String? = null,
    val price: Double = 0.0,
    val category: String = "General",
    @SerialName("is_available") val isAvailable: Boolean? = true,
    @SerialName("is_veg") val isVeg: Boolean? = true,
    @SerialName("prep_time_mins") val prepTimeMins: Int? = 20,
    @SerialName("quantity_value") val quantityValue: String? = null,
    @SerialName("quantity_unit") val quantityUnit: String? = null,
    @SerialName("photo_url") val photoUrl: String? = null,
    @SerialName("image_url") val imageUrl: String? = null
)

@Serializable
data class DbOrder(
    val id: String? = null,
    @SerialName("order_number") val orderNumber: String? = null,
    @SerialName("customer_id") val customerId: String? = null,
    @SerialName("store_id") val storeId: String,
    @SerialName("rider_id") val riderId: String? = null,
    val status: String = "PLACED",
    @SerialName("subtotal_amount") val subtotalAmount: Double,
    @SerialName("delivery_fee") val deliveryFee: Double = 0.0,
    @SerialName("tip_amount") val tipAmount: Double = 0.0,
    @SerialName("total_amount") val totalAmount: Double,
    @SerialName("payment_type") val paymentType: String = "PREPAID",
    @SerialName("is_paid") val isPaid: Boolean = true,
    @SerialName("customer_otp") val customerOtp: String = "1234",
    @SerialName("delivery_address") val deliveryAddress: String,
    @SerialName("delivery_latitude") val deliveryLatitude: Double? = null,
    @SerialName("delivery_longitude") val deliveryLongitude: Double? = null,
    @SerialName("pickup_instructions") val pickupInstructions: String? = null,
    @SerialName("delivery_instructions") val deliveryInstructions: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

@Serializable
data class DbOrderItem(
    val id: String? = null,
    @SerialName("order_id") val orderId: String? = null,
    @SerialName("menu_item_id") val menuItemId: String? = null,
    @SerialName("item_name") val itemName: String,
    val quantity: Int,
    @SerialName("unit_price") val unitPrice: Double,
    val subtotal: Double
)

@Serializable
data class DbCallSignal(
    val id: String? = null,
    @SerialName("order_id") val orderId: String,
    @SerialName("caller_role") val callerRole: String,
    @SerialName("receiver_role") val receiverRole: String,
    @SerialName("sdp_offer") val sdpOffer: String? = null,
    @SerialName("sdp_answer") val sdpAnswer: String? = null,
    @SerialName("call_status") val callStatus: String = "RINGING",
    @SerialName("created_at") val createdAt: String? = null
)
