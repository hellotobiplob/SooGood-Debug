package `in`.soogood.customer.domain.model

data class User(
    val id: String = "",
    val name: String = "",
    val mobileNumber: String = "",
    val email: String? = null,
    val isGuest: Boolean = false
)
