package `in`.soogood.customer.data.repository

import `in`.soogood.customer.data.remote.DbOrder
import `in`.soogood.customer.data.remote.DbOrderItem
import `in`.soogood.customer.data.remote.SupabaseRepository
import `in`.soogood.customer.domain.model.Address
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Order
import `in`.soogood.customer.domain.model.OrderStatus
import `in`.soogood.customer.domain.model.PaymentMethod
import `in`.soogood.customer.domain.repository.OrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SupabaseOrderRepository(
    private val supabaseRemote: SupabaseRepository = SupabaseRepository(),
    private val firebaseRemote: FirebaseRealtimeRepository = FirebaseRealtimeRepository()
) : OrderRepository {

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    override val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    override suspend fun placeOrder(order: Order): Result<Order> {
        val updated = _orders.value.toMutableList().apply { add(0, order) }
        _orders.value = updated

        // Broadcast to Firebase Realtime Database for sub-second live updates
        firebaseRemote.broadcastOrderState(
            LiveOrderState(
                orderId = order.id,
                status = order.orderStatus.name,
                estimatedDeliveryMinutes = order.estimatedDeliveryMinutes,
                deliveryOtp = order.deliveryOtp
            )
        )

        try {
            val isCod = order.paymentMethod == PaymentMethod.CASH_ON_DELIVERY
            val dbOrder = DbOrder(
                orderNumber = order.id,
                storeId = order.merchantId,
                status = order.orderStatus.name,
                subtotalAmount = order.subtotalPaise / 100.0,
                deliveryFee = order.deliveryFeePaise / 100.0,
                totalAmount = order.totalAmountPaise / 100.0,
                paymentType = if (isCod) "CASH_ON_DELIVERY" else "ONLINE",
                isPaid = !isCod,
                customerOtp = order.deliveryOtp,
                deliveryAddress = order.deliveryAddress.fullAddress,
                deliveryLatitude = order.deliveryAddress.latitude,
                deliveryLongitude = order.deliveryAddress.longitude
            )

            val dbItems = order.items.map { item ->
                DbOrderItem(
                    itemName = item.product.name,
                    quantity = item.quantity,
                    unitPrice = item.unitPricePaise / 100.0,
                    subtotal = item.totalItemPricePaise / 100.0
                )
            }

            supabaseRemote.placeOrder(dbOrder, dbItems)
        } catch (_: Exception) {
        }

        return Result.success(order)
    }

    override suspend fun getOrderById(orderId: String): Order? {
        val local = _orders.value.find { it.id == orderId }
        val dbOrder = supabaseRemote.fetchDbOrderByNumber(orderId) ?: supabaseRemote.fetchDbOrderById(orderId)
        if (dbOrder != null) {
            val newStatus = mapDbStatusToDomain(dbOrder.status)
            val hasRider = !dbOrder.riderId.isNullOrBlank()
            val isCodFromDb = dbOrder.paymentType.contains("CASH", ignoreCase = true) || !dbOrder.isPaid
            val paymentMethodFromDb = if (isCodFromDb) PaymentMethod.CASH_ON_DELIVERY else PaymentMethod.ONLINE_SIMULATED

            val mappedOrder = (local ?: mapDbOrderToDomain(dbOrder)).copy(
                orderStatus = newStatus,
                paymentMethod = paymentMethodFromDb,
                driverName = if (hasRider) "Assigned Delivery Partner (${dbOrder.riderId!!.takeLast(6)})" else null,
                driverPhone = if (hasRider) "+91 9732145678" else null
            )

            if (_orders.value.none { it.id == mappedOrder.id }) {
                _orders.value = listOf(mappedOrder) + _orders.value
            } else {
                _orders.value = _orders.value.map { if (it.id == orderId) mappedOrder else it }
            }
            return mappedOrder
        }
        return local
    }

    override suspend fun cancelOrder(orderId: String): Result<Boolean> {
        val current = _orders.value
        val order = current.find { it.id == orderId } ?: return Result.failure(Exception("Order not found"))

        if (order.orderStatus == OrderStatus.DELIVERED || order.orderStatus == OrderStatus.CANCELLED) {
            return Result.failure(Exception("Cannot cancel order in current state"))
        }

        // Send cancel update to Supabase DB so status persists
        try {
            supabaseRemote.updateOrderStatusInDb(orderId, "CANCELLED")
        } catch (_: Exception) {}

        val updated = current.map {
            if (it.id == orderId) it.copy(orderStatus = OrderStatus.CANCELLED) else it
        }
        _orders.value = updated
        return Result.success(true)
    }

    suspend fun loadPastCustomerOrders(customerId: String) {
        try {
            val dbOrders = if (customerId.isNotBlank()) supabaseRemote.fetchCustomerOrders(customerId) else supabaseRemote.fetchAllOrders()
            val mappedList = dbOrders.map { mapDbOrderToDomain(it) }
            val combined = (mappedList + _orders.value).distinctBy { it.id }
            _orders.value = combined
        } catch (_: Exception) {}
    }

    private fun mapDbOrderToDomain(dbOrder: DbOrder): Order {
        val isCod = dbOrder.paymentType.contains("CASH", ignoreCase = true) || !dbOrder.isPaid
        return Order(
            id = dbOrder.orderNumber.orEmpty().ifBlank { dbOrder.id ?: "ORD_${System.currentTimeMillis()}" },
            cartType = CartType.FOOD,
            merchantId = dbOrder.storeId,
            merchantName = "Fulfillment Store",
            items = emptyList(),
            subtotalPaise = (dbOrder.subtotalAmount * 100).toLong(),
            deliveryFeePaise = (dbOrder.deliveryFee * 100).toLong(),
            taxesAndPackagingPaise = 10_00L,
            totalAmountPaise = (dbOrder.totalAmount * 100).toLong(),
            deliveryAddress = Address(
                id = "addr_db",
                title = "Delivery Location",
                fullAddress = dbOrder.deliveryAddress
            ),
            paymentMethod = if (isCod) PaymentMethod.CASH_ON_DELIVERY else PaymentMethod.ONLINE_SIMULATED,
            orderStatus = mapDbStatusToDomain(dbOrder.status),
            deliveryOtp = dbOrder.customerOtp.ifBlank { "1234" }
        )
    }

    private fun mapDbStatusToDomain(statusString: String): OrderStatus {
        return when (statusString.uppercase()) {
            "PLACED", "ORDER_PLACED" -> OrderStatus.ORDER_PLACED
            "ACCEPTED", "MERCHANT_ACCEPTED" -> OrderStatus.MERCHANT_ACCEPTED
            "PREPARING" -> OrderStatus.PREPARING
            "READY", "READY_FOR_PICKUP" -> OrderStatus.READY_FOR_PICKUP
            "OUT_FOR_DELIVERY", "ON_THE_WAY", "PICKED_UP" -> OrderStatus.ON_THE_WAY
            "DELIVERED" -> OrderStatus.DELIVERED
            "CANCELLED" -> OrderStatus.CANCELLED
            else -> OrderStatus.ORDER_PLACED
        }
    }
}
