package `in`.soogood.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.customer.domain.model.Address
import `in`.soogood.customer.domain.repository.AddressRepository
import `in`.soogood.customer.ui.theme.SooGoodBrand
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddressesScreen(
    addressRepository: AddressRepository,
    onBackClick: () -> Unit,
    onAddAddressClick: () -> Unit = {},
    onEditAddressClick: (Address) -> Unit = {}
) {
    val addresses by addressRepository.addresses.collectAsState()
    val selectedAddress by addressRepository.selectedAddress.collectAsState()
    val scope = rememberCoroutineScope()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Saved addresses", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = { IconButton(onClick = onBackClick) { Icon(Icons.Default.ArrowBack, "Back") } }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp))
                        .border(1.5.dp, SooGoodBrand, RoundedCornerShape(16.dp))
                        .clickable(onClick = onAddAddressClick).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Add, null, tint = SooGoodBrand)
                    Spacer(Modifier.width(12.dp))
                    Text("Add new address", color = SooGoodBrand, fontWeight = FontWeight.Bold)
                }
            }

            items(addresses) { addr ->
                val isSelected = selectedAddress?.id == addr.id
                val icon = when {
                    addr.title.contains("home", true) || addr.addressType.contains("home", true) -> Icons.Default.Home
                    addr.title.contains("work", true) || addr.addressType.contains("work", true) -> Icons.Default.Work
                    else -> Icons.Default.LocationOn
                }
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surface)
                        .border(
                            width = if (isSelected) 1.5.dp else 0.dp,
                            color = if (isSelected) SooGoodBrand else Color.Transparent,
                            shape = RoundedCornerShape(16.dp)
                        )
                        .clickable { scope.launch { addressRepository.selectAddress(addr.id) } }
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(44.dp).clip(RoundedCornerShape(12.dp)).background(SooGoodBrand.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = SooGoodBrand) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = SooGoodBrand,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = addr.addressType.uppercase(),
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            if (!addr.receiverName.isNullOrBlank()) {
                                Spacer(Modifier.width(8.dp))
                                Text(addr.receiverName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (!addr.receiverPhone.isNullOrBlank()) {
                            Spacer(Modifier.height(2.dp))
                            Text("Mobile: +91 ${addr.receiverPhone}", style = MaterialTheme.typography.bodySmall, color = SooGoodBrand, fontWeight = FontWeight.SemiBold)
                        }
                        Spacer(Modifier.height(2.dp))
                        Text(addr.fullAddress, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onEditAddressClick(addr) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Address", tint = SooGoodBrand)
                        }
                        if (isSelected) {
                            Icon(Icons.Default.CheckCircle, "Selected", tint = SooGoodBrand)
                        }
                    }
                }
            }
        }
    }
}
