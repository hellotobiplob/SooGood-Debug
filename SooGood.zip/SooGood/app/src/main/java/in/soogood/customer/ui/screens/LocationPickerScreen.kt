package `in`.soogood.customer.ui.screens

import android.Manifest
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SmallFloatingActionButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import `in`.soogood.customer.domain.model.Address
import `in`.soogood.customer.domain.model.User
import `in`.soogood.customer.ui.theme.SooGoodBrand
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapListener
import org.osmdroid.events.ScrollEvent
import org.osmdroid.events.ZoomEvent
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView

@SuppressLint("MissingPermission")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LocationPickerScreen(
    onBackClick: () -> Unit,
    onConfirmAddress: (address: Address) -> Unit,
    initialAddress: Address? = null,
    currentUser: User? = null,
    vm: LocationPickerViewModel = viewModel()
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val suggestions by vm.suggestions.collectAsState()
    val error by vm.error.collectAsState()
    val address by vm.address.collectAsState()
    val moveTo by vm.moveTo.collectAsState()
    var query by remember { mutableStateOf("") }

    var currentLat by remember { mutableStateOf(initialAddress?.latitude ?: 23.9922) } // Default Nazirpur
    var currentLng by remember { mutableStateOf(initialAddress?.longitude ?: 88.5833) }

    var showAddressFormSheet by remember { mutableStateOf(false) }

    // Address Form State - Empty default fields for customer input
    var receiverName by remember { mutableStateOf(initialAddress?.receiverName ?: currentUser?.name ?: "") }
    var receiverPhone by remember { mutableStateOf(initialAddress?.receiverPhone ?: currentUser?.mobileNumber ?: "") }
    var selectedAddressType by remember { mutableStateOf(initialAddress?.addressType ?: "Home") }
    var houseNo by remember { mutableStateOf(initialAddress?.fullAddress?.substringBefore(",")?.trim() ?: "") }
    var areaName by remember { mutableStateOf(initialAddress?.fullAddress?.substringAfter(",")?.substringBefore("(")?.trim() ?: "Nazirpur, Nadia, PIN 741165") }
    var landmark by remember { mutableStateOf(initialAddress?.landmark ?: "") }

    var hasPerm by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }

    var mapViewInstance by remember { mutableStateOf<MapView?>(null) }

    suspend fun goToMyLocation() {
        val loc = LocationServices.getFusedLocationProviderClient(ctx)
            .getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null).await()
        if (loc != null) {
            currentLat = loc.latitude
            currentLng = loc.longitude
            mapViewInstance?.controller?.animateTo(GeoPoint(loc.latitude, loc.longitude))
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        hasPerm = r[Manifest.permission.ACCESS_FINE_LOCATION] == true || r[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (hasPerm) scope.launch { runCatching { goToMyLocation() } }
    }

    fun requestMyLocation() {
        if (hasPerm) scope.launch { runCatching { goToMyLocation() } }
        else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    LaunchedEffect(Unit) {
        if (initialAddress == null) {
            requestMyLocation()
        }
    }

    LaunchedEffect(moveTo) {
        moveTo?.let { latLng ->
            currentLat = latLng.latitude
            currentLng = latLng.longitude
            mapViewInstance?.controller?.animateTo(GeoPoint(latLng.latitude, latLng.longitude))
            vm.clearMoveTo()
        }
    }

    LaunchedEffect(address) {
        if (address.isNotBlank()) {
            areaName = address
        }
    }

    Box(Modifier.fillMaxSize()) {
        // Free OpenStreetMap Tiles View (No API Key Required!)
        AndroidView(
            factory = { context ->
                Configuration.getInstance().userAgentValue = "SooGoodCustomerApp/1.0 (in.soogood.customer)"
                MapView(context).apply {
                    setTileSource(TileSourceFactory.MAPNIK) // Real OpenStreetMap Tiles!
                    setMultiTouchControls(true)
                    controller.setZoom(16.5)
                    controller.setCenter(GeoPoint(currentLat, currentLng))

                    addMapListener(object : MapListener {
                        override fun onScroll(event: ScrollEvent?): Boolean {
                            val center = mapCenter
                            currentLat = center.latitude
                            currentLng = center.longitude
                            vm.reverseGeocode(com.google.android.gms.maps.model.LatLng(center.latitude, center.longitude))
                            return true
                        }

                        override fun onZoom(event: ZoomEvent?): Boolean {
                            return true
                        }
                    })

                    mapViewInstance = this
                }
            },
            update = { mapView ->
                mapViewInstance = mapView
            },
            modifier = Modifier.fillMaxSize()
        )

        // Fixed Centre Location Pin
        Icon(
            imageVector = Icons.Default.LocationOn,
            contentDescription = "Selected location",
            tint = SooGoodBrand,
            modifier = Modifier
                .align(Alignment.Center)
                .size(48.dp)
                .offset(y = (-24).dp)
        )

        // Top Search Bar & Free Nominatim Auto-suggestions
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(12.dp)
        ) {
            Surface(shape = RoundedCornerShape(14.dp), shadowElevation = 6.dp) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it; vm.onQueryChange(it) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Search area in Nazirpur, street or landmark") },
                    leadingIcon = { IconButton(onClick = onBackClick) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") } }
                )
            }

            if (suggestions.isNotEmpty() || error != null) {
                Surface(
                    modifier = Modifier.padding(top = 6.dp),
                    shape = RoundedCornerShape(14.dp),
                    shadowElevation = 6.dp
                ) {
                    LazyColumn(Modifier.heightIn(max = 320.dp)) {
                        if (suggestions.isEmpty() && error != null) {
                            item { Text(error!!, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) }
                        }
                        items(suggestions) { s ->
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        focus.clearFocus()
                                        query = s.primary
                                        vm.pick(s)
                                    }
                                    .padding(horizontal = 16.dp, vertical = 12.dp)
                            ) {
                                Text(s.primary, fontWeight = FontWeight.SemiBold)
                                if (s.secondary.isNotBlank()) {
                                    Text(
                                        text = s.secondary,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            HorizontalDivider()
                        }
                    }
                }
            }
        }

        // Bottom Location Confirmation Card & GPS FAB
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(12.dp),
            horizontalAlignment = Alignment.End
        ) {
            SmallFloatingActionButton(
                onClick = { requestMyLocation() },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Icon(Icons.Default.MyLocation, "Use current location", tint = SooGoodBrand)
            }

            Spacer(Modifier.height(8.dp))

            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                shadowElevation = 8.dp
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Deliver to this location", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(4.dp))
                    Text(address.ifBlank { "Move the map to pick a spot" }, fontWeight = FontWeight.Bold, maxLines = 3)
                    Spacer(Modifier.height(12.dp))
                    Button(
                        onClick = { showAddressFormSheet = true },
                        enabled = address.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)
                    ) {
                        Text(if (initialAddress != null) "Edit Address Details ➔" else "Confirm location ➔", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // CUSTOM RECEIVER & ADDRESS DETAILS BOTTOM SHEET
        if (showAddressFormSheet) {
            ModalBottomSheet(
                onDismissRequest = { showAddressFormSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Complete Address & Receiver Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    // Address Type Selection Chips
                    Text("Save Address As", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = selectedAddressType == "Home",
                            onClick = { selectedAddressType = "Home" },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Home, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Home")
                                }
                            }
                        )
                        FilterChip(
                            selected = selectedAddressType == "Work",
                            onClick = { selectedAddressType = "Work" },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Work, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Work")
                                }
                            }
                        )
                        FilterChip(
                            selected = selectedAddressType == "Other",
                            onClick = { selectedAddressType = "Other" },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Other")
                                }
                            }
                        )
                    }

                    // Receiver Name Field
                    OutlinedTextField(
                        value = receiverName,
                        onValueChange = { receiverName = it },
                        label = { Text("Receiver's Full Name") },
                        placeholder = { Text("Enter receiver's name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Receiver Phone Field
                    OutlinedTextField(
                        value = receiverPhone,
                        onValueChange = { receiverPhone = it },
                        label = { Text("Receiver's Mobile Number") },
                        placeholder = { Text("10-digit mobile number") },
                        leadingIcon = { Icon(Icons.Default.Call, contentDescription = null) },
                        prefix = { Text("+91 ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // House / Building Field
                    OutlinedTextField(
                        value = houseNo,
                        onValueChange = { houseNo = it },
                        label = { Text("Flat / House / Building No.") },
                        placeholder = { Text("e.g. House No. 12B, Block C") },
                        leadingIcon = { Icon(Icons.Default.Home, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Area Field (Pre-filled from map selection)
                    OutlinedTextField(
                        value = areaName,
                        onValueChange = { areaName = it },
                        label = { Text("Area / Locality / Village (Map Selected)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    // Landmark Field
                    OutlinedTextField(
                        value = landmark,
                        onValueChange = { landmark = it },
                        label = { Text("Nearby Landmark (Optional)") },
                        placeholder = { Text("e.g. Near Bus Stand, Opp. Temple") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            val fullAddressText = if (houseNo.isNotBlank()) "$houseNo, $areaName" else areaName
                            val finalAddressText = if (landmark.isNotBlank()) "$fullAddressText (Landmark: $landmark)" else fullAddressText

                            val addressToSave = Address(
                                id = initialAddress?.id ?: "addr_${System.currentTimeMillis()}",
                                title = selectedAddressType,
                                fullAddress = finalAddressText,
                                landmark = landmark.ifBlank { null },
                                latitude = currentLat,
                                longitude = currentLng,
                                isDefault = true,
                                receiverName = receiverName,
                                receiverPhone = receiverPhone,
                                addressType = selectedAddressType
                            )
                            showAddressFormSheet = false
                            onConfirmAddress(addressToSave)
                        },
                        enabled = receiverName.isNotBlank() && receiverPhone.length >= 10 && houseNo.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("SAVE & CONFIRM ADDRESS", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
