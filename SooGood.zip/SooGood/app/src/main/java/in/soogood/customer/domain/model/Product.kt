package `in`.soogood.customer.domain.model

data class Product(
    val id: String,
    val restaurantId: String? = null,
    val storeId: String? = null,
    val name: String,
    val description: String,
    val pricePaise: Long,
    val originalPricePaise: Long? = null,
    val imageUrl: String,
    val isVeg: Boolean = true,
    val isBestseller: Boolean = false,
    val isAvailable: Boolean = true,
    val category: String,
    val cartType: CartType,
    val weightVariants: List<String> = emptyList(), // e.g. ["250g", "500g", "1kg"] for grocery/meat
    val customizationGroups: List<CustomizationGroup> = emptyList() // for food
)
