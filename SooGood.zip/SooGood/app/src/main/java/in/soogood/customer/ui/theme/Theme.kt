package `in`.soogood.customer.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = SooGoodBrand,
    onPrimary = Color.White,
    primaryContainer = SooGoodTint,
    onPrimaryContainer = SooGoodBrandDark,
    secondary = SooGoodFood,
    tertiary = SooGoodMart,
    background = SooGoodBackground,
    onBackground = SooGoodInk,
    surface = Color.White,
    onSurface = SooGoodInk,
    surfaceVariant = Color(0xFFEEEEF6),
    onSurfaceVariant = Color(0xFF6B6B85),
    outline = Color(0xFFE2E2EE)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF9B87FF),
    onPrimary = Color(0xFF1A0E66),
    primaryContainer = Color(0xFF2C2160),
    onPrimaryContainer = Color(0xFFE4DEFF),
    secondary = SooGoodFood,
    tertiary = SooGoodMart,
    background = Color(0xFF0E0E1A),
    onBackground = Color(0xFFF1F1FA),
    surface = Color(0xFF181828),
    onSurface = Color(0xFFF1F1FA),
    surfaceVariant = Color(0xFF242438),
    onSurfaceVariant = Color(0xFFA5A5C0),
    outline = Color(0xFF32324A)
)

val SooGoodShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(14.dp),
    large = RoundedCornerShape(20.dp)
)

@Composable
fun SooGoodTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        shapes = SooGoodShapes,
        content = content
    )
}
