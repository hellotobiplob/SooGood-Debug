package `in`.soogood.customer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Product
import `in`.soogood.customer.domain.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class SearchViewModel(
    private val productRepository: ProductRepository
) : ViewModel() {

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _cartType = MutableStateFlow(CartType.FOOD)
    val cartType: StateFlow<CartType> = _cartType.asStateFlow()

    private val _searchResults = MutableStateFlow<List<Product>>(emptyList())
    val searchResults: StateFlow<List<Product>> = _searchResults.asStateFlow()

    private val _isVegOnly = MutableStateFlow(false)
    val isVegOnly: StateFlow<Boolean> = _isVegOnly.asStateFlow()

    fun setCartType(type: CartType) {
        _cartType.value = type
        performSearch()
    }

    fun onQueryChanged(query: String) {
        _searchQuery.value = query
        performSearch()
    }

    fun toggleVegOnly() {
        _isVegOnly.value = !_isVegOnly.value
        performSearch()
    }

    private fun performSearch() {
        viewModelScope.launch {
            val q = _searchQuery.value.trim()
            val results = productRepository.searchProducts(q, _cartType.value)

            val filteredByPrice = if (q.equals("99 Store", ignoreCase = true) || q.equals("99", ignoreCase = true) || q.equals("Under ₹99", ignoreCase = true)) {
                results.filter { it.pricePaise <= 99_00L }
            } else {
                results
            }

            _searchResults.value = if (_isVegOnly.value) {
                filteredByPrice.filter { it.isVeg }
            } else {
                filteredByPrice
            }
        }
    }
}
