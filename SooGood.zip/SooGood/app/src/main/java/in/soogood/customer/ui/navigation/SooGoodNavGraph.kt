package `in`.soogood.customer.ui.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import `in`.soogood.customer.data.repository.FirebaseAuthRepository
import `in`.soogood.customer.data.repository.FirebaseOrderRepository
import `in`.soogood.customer.data.repository.FirebaseProductRepository
import `in`.soogood.customer.data.repository.FirebaseStoreRepository
import `in`.soogood.customer.data.repository.InMemoryCartRepository
import `in`.soogood.customer.data.repository.RealAddressRepository
import `in`.soogood.customer.data.repository.RealNotificationRepository
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.ui.screens.AddressesScreen
import `in`.soogood.customer.ui.screens.AuthScreen
import `in`.soogood.customer.ui.screens.CartScreen
import `in`.soogood.customer.ui.screens.CheckoutScreen
import `in`.soogood.customer.ui.screens.HomeScreen
import `in`.soogood.customer.ui.screens.LocationPickerScreen
import `in`.soogood.customer.ui.screens.NotificationsScreen
import `in`.soogood.customer.ui.screens.OnboardingScreen
import `in`.soogood.customer.ui.screens.OrderHistoryScreen
import `in`.soogood.customer.ui.screens.OrderTrackingScreen
import `in`.soogood.customer.ui.screens.ProfileScreen
import `in`.soogood.customer.ui.screens.RestaurantDetailScreen
import `in`.soogood.customer.ui.screens.SearchScreen
import `in`.soogood.customer.ui.screens.SplashScreen
import `in`.soogood.customer.ui.screens.Store99Screen
import `in`.soogood.customer.ui.viewmodel.AuthViewModel
import `in`.soogood.customer.ui.viewmodel.CartViewModel
import `in`.soogood.customer.ui.viewmodel.HomeViewModel
import `in`.soogood.customer.ui.viewmodel.OrderViewModel
import `in`.soogood.customer.ui.viewmodel.SearchViewModel
import `in`.soogood.customer.ui.viewmodel.Store99ViewModel

object NavRoutes {
    const val SPLASH = "splash"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val SEARCH = "search/{cartType}"
    const val STORE_99 = "store_99/{cartType}"
    const val RESTAURANT_DETAIL = "restaurant_detail/{merchantId}/{cartType}"
    const val CART = "cart/{cartType}"
    const val CHECKOUT = "checkout/{cartType}"
    const val ORDER_TRACKING = "order_tracking/{orderId}"
    const val ORDER_HISTORY = "order_history"
    const val AUTH = "auth"
    const val ADDRESSES = "addresses"
    const val PROFILE = "profile"
    const val NOTIFICATIONS = "notifications"
    const val LOCATION_PICKER = "location_picker"
}

@Composable
fun SooGoodNavGraph() {
    val navController = rememberNavController()
    val scope = rememberCoroutineScope()

    var editingAddress by remember { mutableStateOf<`in`.soogood.customer.domain.model.Address?>(null) }

    val context = androidx.compose.ui.platform.LocalContext.current.applicationContext

    // Instantiate Repositories (Firebase-only backend)
    val storeRepo = remember { FirebaseStoreRepository() }
    val productRepo = remember { FirebaseProductRepository() }
    val addressRepo = remember { RealAddressRepository(context) }
    val cartRepo = remember { InMemoryCartRepository() }
    val orderRepo = remember { FirebaseOrderRepository() }
    val authRepo = remember { FirebaseAuthRepository(context) }
    val notificationRepo = remember { RealNotificationRepository() }

    // Instantiate ViewModels
    val homeViewModel = remember { HomeViewModel(storeRepo, addressRepo, cartRepo, notificationRepo) }
    val cartViewModel = remember { CartViewModel(cartRepo) }
    val searchViewModel = remember { SearchViewModel(productRepo) }
    val orderViewModel = remember { OrderViewModel(orderRepo, cartRepo, addressRepo) }
    val authViewModel = remember { AuthViewModel(authRepo) }

    NavHost(
        navController = navController,
        startDestination = NavRoutes.SPLASH
    ) {
        composable(NavRoutes.SPLASH) {
            SplashScreen(
                onSplashFinished = {
                    val isLoggedIn = authRepo.currentUser.value != null
                    val destination = if (isLoggedIn) NavRoutes.HOME else NavRoutes.AUTH
                    navController.navigate(destination) {
                        popUpTo(NavRoutes.SPLASH) { inclusive = true }
                    }
                }
            )
        }

        composable(NavRoutes.ONBOARDING) {
            OnboardingScreen(
                onSkipOrFinish = {
                    navController.navigate(NavRoutes.HOME) {
                        popUpTo(NavRoutes.ONBOARDING) { inclusive = true }
                    }
                }
            )
        }

        composable(NavRoutes.HOME) {
            HomeScreen(
                viewModel = homeViewModel,
                onRestaurantClick = { id ->
                    val currentTab = homeViewModel.selectedTab.value
                    navController.navigate("restaurant_detail/$id/${currentTab.name}")
                },
                onCategoryClick = { category ->
                    val currentTab = homeViewModel.selectedTab.value
                    searchViewModel.setCartType(currentTab)
                    searchViewModel.onQueryChanged(category)
                    navController.navigate("search/${currentTab.name}")
                },
                on99StoreClick = { cartType ->
                    navController.navigate("store_99/${cartType.name}")
                },
                onSearchClick = { cartType ->
                    navController.navigate("search/${cartType.name}")
                },
                onCartClick = { cartType ->
                    navController.navigate("cart/${cartType.name}")
                },
                onAddressClick = {
                    navController.navigate(NavRoutes.ADDRESSES)
                },
                onNotificationClick = {
                    navController.navigate(NavRoutes.NOTIFICATIONS)
                },
                onOrdersClick = {
                    navController.navigate(NavRoutes.ORDER_HISTORY)
                },
                onProfileClick = {
                    navController.navigate(NavRoutes.PROFILE)
                }
            )
        }

        composable(
            route = NavRoutes.STORE_99,
            arguments = listOf(navArgument("cartType") { type = NavType.StringType })
        ) { backStackEntry ->
            val cartTypeStr = backStackEntry.arguments?.getString("cartType") ?: CartType.FOOD.name
            val cartType = CartType.valueOf(cartTypeStr)
            val store99ViewModel = remember(cartType) { Store99ViewModel(productRepo, cartType) }

            Store99Screen(
                cartType = cartType,
                viewModel = store99ViewModel,
                cartViewModel = cartViewModel,
                onBackClick = { navController.popBackStack() },
                onCartClick = { navController.navigate("cart/${cartType.name}") }
            )
        }

        composable(
            route = NavRoutes.SEARCH,
            arguments = listOf(navArgument("cartType") { type = NavType.StringType })
        ) { backStackEntry ->
            val cartTypeStr = backStackEntry.arguments?.getString("cartType") ?: CartType.FOOD.name
            val cartType = CartType.valueOf(cartTypeStr)
            SearchScreen(
                cartType = cartType,
                onBackClick = { navController.popBackStack() },
                onSearch = { query -> searchViewModel.onQueryChanged(query) },
                onCategoryClick = { category ->
                    searchViewModel.onQueryChanged(category)
                }
            )
        }

        composable(
            route = NavRoutes.RESTAURANT_DETAIL,
            arguments = listOf(
                navArgument("merchantId") { type = NavType.StringType },
                navArgument("cartType") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val merchantId = backStackEntry.arguments?.getString("merchantId") ?: ""
            val cartTypeStr = backStackEntry.arguments?.getString("cartType") ?: CartType.FOOD.name
            val cartType = CartType.valueOf(cartTypeStr)

            RestaurantDetailScreen(
                merchantId = merchantId,
                cartType = cartType,
                cartViewModel = cartViewModel,
                onBackClick = { navController.popBackStack() },
                onCartClick = { navController.navigate("cart/${cartType.name}") }
            )
        }

        composable(
            route = NavRoutes.CART,
            arguments = listOf(navArgument("cartType") { type = NavType.StringType })
        ) { backStackEntry ->
            val cartTypeStr = backStackEntry.arguments?.getString("cartType") ?: CartType.FOOD.name
            val cartType = CartType.valueOf(cartTypeStr)

            CartScreen(
                cartType = cartType,
                cartViewModel = cartViewModel,
                onBackClick = { navController.popBackStack() },
                onCheckoutClick = { type ->
                    navController.navigate("checkout/${type.name}")
                }
            )
        }

        composable(
            route = NavRoutes.CHECKOUT,
            arguments = listOf(navArgument("cartType") { type = NavType.StringType })
        ) { backStackEntry ->
            val cartTypeStr = backStackEntry.arguments?.getString("cartType") ?: CartType.FOOD.name
            val cartType = CartType.valueOf(cartTypeStr)

            CheckoutScreen(
                cartType = cartType,
                cartViewModel = cartViewModel,
                orderViewModel = orderViewModel,
                authViewModel = authViewModel,
                addressRepository = addressRepo,
                onBackClick = { navController.popBackStack() },
                onLoginClick = { navController.navigate(NavRoutes.AUTH) },
                onAddAddressClick = {
                    editingAddress = null
                    navController.navigate(NavRoutes.LOCATION_PICKER)
                },
                onOrderPlaced = { orderId ->
                    navController.navigate("order_tracking/$orderId") {
                        popUpTo(NavRoutes.HOME) { inclusive = false }
                    }
                }
            )
        }

        composable(
            route = NavRoutes.ORDER_TRACKING,
            arguments = listOf(navArgument("orderId") { type = NavType.StringType })
        ) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            OrderTrackingScreen(
                orderId = orderId,
                orderViewModel = orderViewModel,
                onBackClick = { navController.popBackStack() }
            )
        }

        composable(NavRoutes.ORDER_HISTORY) {
            OrderHistoryScreen(
                orderViewModel = orderViewModel,
                onBackClick = { navController.popBackStack() },
                onOrderClick = { orderId ->
                    navController.navigate("order_tracking/$orderId")
                }
            )
        }

        composable(NavRoutes.AUTH) {
            AuthScreen(
                authViewModel = authViewModel,
                onBackClick = { navController.popBackStack() },
                onAuthSuccess = {
                    navController.navigate(NavRoutes.HOME) {
                        popUpTo(NavRoutes.AUTH) { inclusive = true }
                    }
                }
            )
        }

        composable(NavRoutes.ADDRESSES) {
            AddressesScreen(
                addressRepository = addressRepo,
                onBackClick = { navController.popBackStack() },
                onAddAddressClick = {
                    editingAddress = null
                    navController.navigate(NavRoutes.LOCATION_PICKER)
                },
                onEditAddressClick = { addressToEdit ->
                    editingAddress = addressToEdit
                    navController.navigate(NavRoutes.LOCATION_PICKER)
                }
            )
        }

        composable(NavRoutes.LOCATION_PICKER) {
            val currentUser by authViewModel.currentUser.collectAsState()
            LocationPickerScreen(
                onBackClick = { navController.popBackStack() },
                currentUser = currentUser,
                initialAddress = editingAddress,
                onConfirmAddress = { address ->
                    scope.launch {
                        if (addressRepo.addresses.value.any { it.id == address.id }) {
                            addressRepo.updateAddress(address)
                        } else {
                            addressRepo.addAddress(address)
                        }
                    }
                    editingAddress = null
                    navController.popBackStack()
                }
            )
        }

        composable(NavRoutes.PROFILE) {
            ProfileScreen(
                authViewModel = authViewModel,
                onBackClick = { navController.popBackStack() },
                onOrdersClick = { navController.navigate(NavRoutes.ORDER_HISTORY) },
                onAddressesClick = { navController.navigate(NavRoutes.ADDRESSES) },
                onLoginClick = { navController.navigate(NavRoutes.AUTH) }
            )
        }

        composable(NavRoutes.NOTIFICATIONS) {
            NotificationsScreen(
                onBackClick = { navController.popBackStack() }
            )
        }
    }
}
