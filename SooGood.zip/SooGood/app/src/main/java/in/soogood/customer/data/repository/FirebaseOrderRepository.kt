package `in`.soogood.customer.data.repository

import android.util.Log
import com.google.firebase.database.FirebaseDatabase
import `in`.soogood.customer.domain.model.Order
import `in`.soogood.customer.domain.model.OrderStatus
import `in`.soogood.customer.domain.repository.OrderRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class FirebaseOrderRepository : OrderRepository {

    private val dbRef = FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com").getReference("orders")
    private val liveDbRef = FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com").getReference("live_orders")
    private val firebaseRealtimeRepo = FirebaseRealtimeRepository()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    override val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    override suspend fun placeOrder(order: Order): Result<Order> {
        val updated = _orders.value.toMutableList().apply { add(0, order) }
        _orders.value = updated

        try {
            dbRef.child(order.id).setValue(order).await()

            firebaseRealtimeRepo.broadcastOrderState(
                LiveOrderState(
                    orderId = order.id,
                    status = order.orderStatus.name,
                    estimatedDeliveryMinutes = order.estimatedDeliveryMinutes,
                    deliveryOtp = order.deliveryOtp
                )
            )
            Log.d("FirebaseOrderRepo", "Successfully placed order in Firebase RTDB: ${order.id}")
        } catch (e: Exception) {
            Log.e("FirebaseOrderRepo", "Error placing order in Firebase RTDB", e)
        }

        return Result.success(order)
    }

    override suspend fun getOrderById(orderId: String): Order? {
        val local = _orders.value.find { it.id == orderId }
        try {
            val snapshot = dbRef.child(orderId).get().await()
            val order = snapshot.getValue(Order::class.java)
            if (order != null) {
                if (_orders.value.none { it.id == order.id }) {
                    _orders.value = listOf(order) + _orders.value
                }
                return order
            }
        } catch (e: Exception) {
            Log.e("FirebaseOrderRepo", "Error fetching order by ID from Firebase RTDB", e)
        }
        return local
    }

    override suspend fun cancelOrder(orderId: String): Result<Boolean> {
        val current = _orders.value
        val order = current.find { it.id == orderId } ?: return Result.failure(Exception("Order not found"))

        if (order.orderStatus == OrderStatus.DELIVERED || order.orderStatus == OrderStatus.CANCELLED) {
            return Result.failure(Exception("Cannot cancel order in current state"))
        }

        try {
            dbRef.child(orderId).child("orderStatus").setValue(OrderStatus.CANCELLED.name).await()
            liveDbRef.child(orderId).child("status").setValue("CANCELLED").await()
        } catch (e: Exception) {
            Log.e("FirebaseOrderRepo", "Error cancelling order in Firebase RTDB", e)
        }

        val updated = current.map {
            if (it.id == orderId) it.copy(orderStatus = OrderStatus.CANCELLED) else it
        }
        _orders.value = updated
        return Result.success(true)
    }
}
