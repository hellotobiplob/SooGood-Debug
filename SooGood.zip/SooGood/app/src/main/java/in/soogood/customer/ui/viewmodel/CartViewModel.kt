package `in`.soogood.customer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.customer.domain.model.Cart
import `in`.soogood.customer.domain.model.CartItem
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.repository.AddToCartResult
import `in`.soogood.customer.domain.repository.CartRepository
import `in`.soogood.customer.domain.usecase.DeliveryFeeCalculator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class CartViewModel(
    private val cartRepository: CartRepository
) : ViewModel() {

    val foodCart: StateFlow<Cart> = cartRepository.foodCart
    val hypermartCart: StateFlow<Cart> = cartRepository.hypermartCart

    private val _merchantConflictState = MutableStateFlow<AddToCartResult.MerchantConflict?>(null)
    val merchantConflictState: StateFlow<AddToCartResult.MerchantConflict?> = _merchantConflictState.asStateFlow()

    fun addToCart(
        item: CartItem,
        merchantId: String,
        merchantName: String,
        distanceKm: Double,
        forceReplace: Boolean = false
    ) {
        viewModelScope.launch {
            val result = cartRepository.addToCart(
                item = item,
                merchantId = merchantId,
                merchantName = merchantName,
                distanceKm = distanceKm,
                forceReplace = forceReplace
            )
            if (result is AddToCartResult.MerchantConflict) {
                _merchantConflictState.value = result
            } else {
                _merchantConflictState.value = null
            }
        }
    }

    fun dismissConflictDialog() {
        _merchantConflictState.value = null
    }

    fun confirmReplaceCart() {
        val conflict = _merchantConflictState.value ?: return
        viewModelScope.launch {
            cartRepository.addToCart(
                item = conflict.pendingCartItem,
                merchantId = conflict.pendingCartItem.product.restaurantId
                    ?: conflict.pendingCartItem.product.storeId
                    ?: "merchant",
                merchantName = conflict.newMerchantName,
                distanceKm = 1.5,
                forceReplace = true
            )
            _merchantConflictState.value = null
        }
    }

    fun updateQuantity(cartType: CartType, itemId: String, newQuantity: Int) {
        viewModelScope.launch {
            cartRepository.updateQuantity(cartType, itemId, newQuantity)
        }
    }

    fun removeItem(cartType: CartType, itemId: String) {
        viewModelScope.launch {
            cartRepository.removeItem(cartType, itemId)
        }
    }

    fun clearCart(cartType: CartType) {
        viewModelScope.launch {
            cartRepository.clearCart(cartType)
        }
    }

    // Calculation Helpers
    fun getDeliveryFeePaise(cart: Cart): Long {
        return DeliveryFeeCalculator.calculateFinalFeePaise(cart.distanceKm, cart.subtotalPaise)
    }

    fun getPlatformFeePaise(cart: Cart): Long {
        if (cart.isEmpty) return 0L
        return DeliveryFeeCalculator.PLATFORM_FEE_PAISE // ₹5.00
    }

    fun getPackagingFeePaise(cart: Cart): Long {
        if (cart.isEmpty) return 0L
        val basePkg = cart.itemCount * 10_00L
        return basePkg.coerceAtMost(35_00L) // Capped at max ₹35 (35_00L)
    }

    fun getGovtGstPaise(cart: Cart): Long {
        if (cart.isEmpty) return 0L
        val foodGst = (cart.subtotalPaise * 0.05).toLong() // 5% Govt Food GST
        val deliveryGst = (getDeliveryFeePaise(cart) * 0.18).toLong() // 18% GST on Delivery Fee
        return foodGst + deliveryGst
    }

    fun getTaxesAndPackagingPaise(cart: Cart): Long {
        if (cart.isEmpty) return 0L
        return getPackagingFeePaise(cart) + getGovtGstPaise(cart)
    }

    fun getTotalAmountPaise(cart: Cart): Long {
        if (cart.isEmpty) return 0L
        return cart.subtotalPaise + getDeliveryFeePaise(cart) + getPlatformFeePaise(cart) + getTaxesAndPackagingPaise(cart)
    }

    fun getAmountNeededForFreeDelivery(cart: Cart): Long {
        return DeliveryFeeCalculator.amountNeededForFreeDelivery(cart.subtotalPaise)
    }

    fun isCartDeliverable(cart: Cart): Boolean {
        return DeliveryFeeCalculator.isWithinDeliveryRadius(cart.distanceKm)
    }
}
