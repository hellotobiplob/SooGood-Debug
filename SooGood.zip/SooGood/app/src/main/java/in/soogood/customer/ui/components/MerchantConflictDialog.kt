package `in`.soogood.customer.ui.components

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import `in`.soogood.customer.domain.repository.AddToCartResult

@Composable
fun MerchantConflictDialog(
    conflict: AddToCartResult.MerchantConflict,
    onConfirmReplace: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Replace Cart Items?") },
        text = {
            Text(
                "Your cart contains items from ${conflict.currentMerchantName}. " +
                        "Would you like to clear your cart and add items from ${conflict.newMerchantName} instead?"
            )
        },
        confirmButton = {
            TextButton(onClick = onConfirmReplace) {
                Text("Replace & Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
