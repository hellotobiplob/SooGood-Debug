package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.Address
import kotlinx.coroutines.flow.StateFlow

interface AddressRepository {
    val addresses: StateFlow<List<Address>>
    val selectedAddress: StateFlow<Address?>
    suspend fun selectAddress(addressId: String)
    suspend fun addAddress(address: Address)
    suspend fun updateAddress(address: Address)
    suspend fun deleteAddress(addressId: String)
}
