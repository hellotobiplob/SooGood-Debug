package `in`.soogood.customer.domain.usecase

import kotlin.math.ceil

/**
 * Encapsulates SooGood delivery fee business rules.
 *
 * Rules:
 * - ₹20 base fee (2000 paise) for distance <= 1.5 km
 * - ₹7 extra (700 paise) for each additional km or fraction beyond 1.5 km
 * - Capped at maximum ₹45 (4500 paise)
 * - Platform Fee ₹5 (500 paise) per order
 * - Maximum deliverable radius = 8.9 km from restaurant/store
 * - Free delivery for merchandise subtotal strictly greater than ₹799 (> 79900 paise)
 *   i.e. ₹799 = paid delivery, ₹800 = free delivery
 *
 * Calculations are performed strictly in integer Paise to prevent floating-point representation errors.
 */
object DeliveryFeeCalculator {

    const val BASE_FEE_PAISE = 20_00L       // ₹20.00
    const val EXTRA_PER_KM_PAISE = 7_00L    // ₹7.00
    const val MAX_FEE_PAISE = 45_00L         // ₹45.00
    const val PLATFORM_FEE_PAISE = 5_00L    // ₹5.00 Platform Fee
    const val FREE_DELIVERY_THRESHOLD_PAISE = 799_00L // Strictly > ₹799.00 required (e.g. ₹800+)
    const val MAX_DELIVERY_RADIUS_KM = 8.9  // Maximum delivery distance in km

    /**
     * Checks whether the restaurant/store is within the maximum deliverable radius of 8.9 km.
     */
    fun isWithinDeliveryRadius(distanceKm: Double): Boolean {
        return distanceKm <= MAX_DELIVERY_RADIUS_KM
    }

    /**
     * Calculates the delivery fee before free delivery qualification.
     * @param distanceKm Distance between store/restaurant and delivery address in km
     * @return Ordinary delivery fee in Paise
     */
    fun calculateStandardFeePaise(distanceKm: Double): Long {
        if (distanceKm <= 0.0) return BASE_FEE_PAISE

        val extraKm = (distanceKm - 1.5).coerceAtLeast(0.0)
        val extraSlices = ceil(extraKm).toLong()

        val totalFee = BASE_FEE_PAISE + (extraSlices * EXTRA_PER_KM_PAISE)
        return totalFee.coerceAtMost(MAX_FEE_PAISE)
    }

    /**
     * Calculates the final delivery fee accounting for free delivery threshold.
     * @param distanceKm Distance in km
     * @param subtotalPaise Merchandise subtotal in Paise
     * @return Final delivery fee in Paise
     */
    fun calculateFinalFeePaise(distanceKm: Double, subtotalPaise: Long): Long {
        if (subtotalPaise > FREE_DELIVERY_THRESHOLD_PAISE) {
            return 0L
        }
        return calculateStandardFeePaise(distanceKm)
    }

    /**
     * Helper to check if a subtotal qualifies for free delivery.
     */
    fun qualifiesForFreeDelivery(subtotalPaise: Long): Boolean {
        return subtotalPaise > FREE_DELIVERY_THRESHOLD_PAISE
    }

    /**
     * Amount remaining in Paise to qualify for free delivery, or 0 if already qualifying.
     */
    fun amountNeededForFreeDelivery(subtotalPaise: Long): Long {
        if (qualifiesForFreeDelivery(subtotalPaise)) return 0L
        return (FREE_DELIVERY_THRESHOLD_PAISE + 100L) - subtotalPaise
    }
}
