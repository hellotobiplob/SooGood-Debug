package `in`.soogood.customer.data.repository

import `in`.soogood.customer.data.remote.DbStore
import `in`.soogood.customer.data.remote.SupabaseRepository
import `in`.soogood.customer.domain.model.Restaurant
import `in`.soogood.customer.domain.model.Store
import `in`.soogood.customer.domain.repository.StoreRepository

class SupabaseStoreRepository(
    private val supabaseRemote: SupabaseRepository = SupabaseRepository()
) : StoreRepository {

    override suspend fun getFoodRestaurants(): List<Restaurant> {
        val remoteStores = supabaseRemote.fetchStores()
        return remoteStores
            .filter { it.storeType == null || it.storeType.equals("RESTAURANT", ignoreCase = true) }
            .map { it.toRestaurant() }
    }

    override suspend fun getHypermartStores(): List<Store> {
        val remoteStores = supabaseRemote.fetchStores()
        return remoteStores
            .filter { it.storeType != null && !it.storeType.equals("RESTAURANT", ignoreCase = true) }
            .map { it.toStore() }
    }

    override suspend fun getRestaurantById(id: String): Restaurant? {
        val restaurants = getFoodRestaurants()
        return restaurants.find { it.id == id }
    }

    override suspend fun getStoreById(id: String): Store? {
        val stores = getHypermartStores()
        return stores.find { it.id == id }
    }

    private fun DbStore.toRestaurant(): Restaurant {
        val lat = latitude ?: 23.9922
        val lng = longitude ?: 88.5833
        val isRestaurantOpen = isOpen ?: (status.equals("APPROVED", ignoreCase = true) || status.equals("OPEN", ignoreCase = true) || status == null)
        return Restaurant(
            id = id ?: "rest_${name.hashCode()}",
            name = name,
            cuisine = "Food & Beverages",
            rating = rating ?: 4.5,
            totalRatingsCount = 120,
            deliveryTimeMinutes = 30,
            distanceKm = 1.5,
            imageUrl = imageUrl.takeIf { !it.isNullOrBlank() } ?: "https://picsum.photos/seed/${name.hashCode()}/400/250",
            isVegOnly = false,
            offerText = if (isRestaurantOpen) "OPEN" else "CLOSED",
            isOpen = isRestaurantOpen,
            latitude = lat,
            longitude = lng
        )
    }

    private fun DbStore.toStore(): Store {
        val lat = latitude ?: 23.9922
        val lng = longitude ?: 88.5833
        val isStoreOpen = isOpen ?: (status.equals("APPROVED", ignoreCase = true) || status.equals("OPEN", ignoreCase = true) || status == null)
        return Store(
            id = id ?: "store_${name.hashCode()}",
            name = name,
            category = "Groceries & Fresh Products",
            rating = rating ?: 4.5,
            distanceKm = 1.5,
            estimatedDeliveryMinutes = 45,
            imageUrl = imageUrl.takeIf { !it.isNullOrBlank() } ?: "https://picsum.photos/seed/${name.hashCode()}/400/250",
            offerText = if (isStoreOpen) "OPEN" else "CLOSED",
            isOpen = isStoreOpen,
            latitude = lat,
            longitude = lng
        )
    }
}
