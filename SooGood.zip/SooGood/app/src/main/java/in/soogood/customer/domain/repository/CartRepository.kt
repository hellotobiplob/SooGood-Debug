package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.Cart
import `in`.soogood.customer.domain.model.CartItem
import `in`.soogood.customer.domain.model.CartType
import kotlinx.coroutines.flow.StateFlow

sealed class AddToCartResult {
    object Success : AddToCartResult()
    data class MerchantConflict(
        val currentMerchantName: String,
        val newMerchantName: String,
        val pendingCartItem: CartItem,
        val cartType: CartType
    ) : AddToCartResult()
}

interface CartRepository {
    val foodCart: StateFlow<Cart>
    val hypermartCart: StateFlow<Cart>

    suspend fun addToCart(
        item: CartItem,
        merchantId: String,
        merchantName: String,
        distanceKm: Double,
        forceReplace: Boolean = false
    ): AddToCartResult

    suspend fun updateQuantity(cartType: CartType, itemId: String, newQuantity: Int)
    suspend fun removeItem(cartType: CartType, itemId: String)
    suspend fun clearCart(cartType: CartType)
}
