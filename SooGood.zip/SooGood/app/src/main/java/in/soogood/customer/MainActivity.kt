package `in`.soogood.customer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.google.android.libraries.places.api.Places
import `in`.soogood.customer.ui.navigation.SooGoodNavGraph
import `in`.soogood.customer.ui.theme.SooGoodTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!Places.isInitialized()) {
            Places.initialize(applicationContext, "AIzaSyA-EXAMPLE_KEY_FOR_MAPS_VIEW_PROD")
        }
        enableEdgeToEdge()
        setContent {
            SooGoodTheme {
                SooGoodNavGraph()
            }
        }
    }
}
