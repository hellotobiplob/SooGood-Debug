package `in`.soogood.customer.data.remote

import android.util.Log
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns

class SupabaseRepository {

    private val client = SupabaseConfig.client

    suspend fun fetchStores(): List<DbStore> {
        return try {
            client.postgrest["stores"]
                .select(columns = Columns.ALL)
                .decodeList<DbStore>()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching stores from Supabase", e)
            emptyList()
        }
    }

    suspend fun fetchMenuItems(storeId: String): List<DbMenuItem> {
        return try {
            client.postgrest["menu_items"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", storeId)
                    }
                }
                .decodeList<DbMenuItem>()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching menu items from Supabase", e)
            emptyList()
        }
    }

    suspend fun placeOrder(order: DbOrder, items: List<DbOrderItem>): String? {
        return try {
            val createdOrder = client.postgrest["orders"]
                .insert(order) {
                    select()
                }
                .decodeSingle<DbOrder>()

            val orderId = createdOrder.id ?: return null

            val orderItemsWithId = items.map { it.copy(orderId = orderId) }
            client.postgrest["order_items"].insert(orderItemsWithId)

            Log.d(TAG, "Successfully placed real order in Supabase: $orderId")
            orderId
        } catch (e: Exception) {
            Log.e(TAG, "Error placing order in Supabase", e)
            null
        }
    }

    suspend fun updateOrderStatusInDb(orderNumber: String, status: String): Boolean {
        return try {
            client.postgrest["orders"].update(
                update = {
                    set("status", status)
                }
            ) {
                filter {
                    eq("order_number", orderNumber)
                }
            }
            Log.d(TAG, "Successfully updated order status to $status for $orderNumber")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status in Supabase", e)
            false
        }
    }

    suspend fun fetchDbOrderByNumber(orderNumber: String): DbOrder? {
        return try {
            client.postgrest["orders"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("order_number", orderNumber)
                    }
                }
                .decodeList<DbOrder>()
                .firstOrNull()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching db order by number", e)
            null
        }
    }

    suspend fun fetchDbOrderById(id: String): DbOrder? {
        return try {
            client.postgrest["orders"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("id", id)
                    }
                }
                .decodeList<DbOrder>()
                .firstOrNull()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching db order by id", e)
            null
        }
    }

    suspend fun fetchCustomerOrders(customerId: String): List<DbOrder> {
        return try {
            client.postgrest["orders"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("customer_id", customerId)
                    }
                }
                .decodeList<DbOrder>()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching customer orders", e)
            emptyList()
        }
    }

    suspend fun fetchAllOrders(): List<DbOrder> {
        return try {
            client.postgrest["orders"]
                .select(columns = Columns.ALL)
                .decodeList<DbOrder>()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching all orders from Supabase", e)
            emptyList()
        }
    }

    companion object {
        private const val TAG = "CustomerSupabaseRepo"
    }
}
