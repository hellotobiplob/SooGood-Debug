package `in`.soogood.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DeliveryDining
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import `in`.soogood.customer.domain.model.OrderStatus
import `in`.soogood.customer.domain.model.PaymentMethod
import `in`.soogood.customer.ui.components.InAppCallOverlay
import `in`.soogood.customer.ui.theme.SooGoodBrand
import `in`.soogood.customer.ui.theme.SooGoodPrimaryGreen
import `in`.soogood.customer.ui.viewmodel.OrderViewModel
import kotlinx.coroutines.delay
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

private data class ChatMessage(val sender: String, val text: String, val isFromRider: Boolean)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OrderTrackingScreen(
    orderId: String,
    orderViewModel: OrderViewModel,
    onBackClick: () -> Unit
) {
    val order by orderViewModel.currentOrder.collectAsState()

    var showRiderChatSheet by remember { mutableStateOf(false) }
    var activeCallTargetLabel by remember { mutableStateOf<String?>(null) }
    var chatInputText by remember { mutableStateOf("") }
    val chatMessages = remember {
        mutableStateListOf(
            ChatMessage("Rider", "Hello! I am on my way to deliver your order.", isFromRider = true)
        )
    }

    LaunchedEffect(orderId) {
        orderViewModel.loadOrderDetails(orderId)
    }

    activeCallTargetLabel?.let { targetLabel ->
        InAppCallOverlay(
            orderId = order?.id ?: orderId,
            targetRoleLabel = targetLabel,
            onEndCall = { activeCallTargetLabel = null }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Order Details & Live Tracking", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        val currentOrder = order
        if (currentOrder == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("Loading order details...", style = MaterialTheme.typography.bodyLarge)
            }
        } else {
            // Live 30-Second Cancel Countdown
            val now = System.currentTimeMillis()
            val elapsedSec = ((now - currentOrder.createdAtMillis) / 1000).toInt()
            var remainingCancelSec by remember(currentOrder.createdAtMillis) {
                mutableStateOf((30 - elapsedSec).coerceAtLeast(0))
            }

            LaunchedEffect(remainingCancelSec) {
                if (remainingCancelSec > 0) {
                    delay(1000)
                    remainingCancelSec -= 1
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(MaterialTheme.colorScheme.background),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // ORDER SUMMARY & PAYMENT DETAILS CARD
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.ReceiptLong, contentDescription = null, tint = SooGoodPrimaryGreen)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Order #${currentOrder.id.takeLast(8)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                }
                                Surface(
                                    color = SooGoodPrimaryGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "₹${currentOrder.totalAmountPaise / 100}",
                                        style = MaterialTheme.typography.titleLarge,
                                        color = SooGoodPrimaryGreen,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(2.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Payment Method", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(
                                    text = if (currentOrder.paymentMethod == PaymentMethod.CASH_ON_DELIVERY) "Cash on Delivery" else "Online Paid",
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Payment Status", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Surface(
                                    color = if (currentOrder.paymentMethod == PaymentMethod.CASH_ON_DELIVERY) Color(0xFFFFF3BF) else Color(0xFFD3F9D8),
                                    shape = RoundedCornerShape(6.dp)
                                ) {
                                    Text(
                                        text = if (currentOrder.paymentMethod == PaymentMethod.CASH_ON_DELIVERY) "COD PENDING" else "PAID ✓",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (currentOrder.paymentMethod == PaymentMethod.CASH_ON_DELIVERY) Color(0xFFD9480F) else Color(0xFF2B8A3E),
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // REAL OPENSTREETMAP LIVE TRACKING CARD
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text("Live Map Tracking", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Surface(
                                    color = SooGoodPrimaryGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(
                                        text = "LIVE • ${currentOrder.estimatedDeliveryMinutes} MINS ETA",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = SooGoodPrimaryGreen,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            val storeLat = 23.9922
                            val storeLng = 88.5833
                            val customerLat = currentOrder.deliveryAddress.latitude
                            val customerLng = currentOrder.deliveryAddress.longitude

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(200.dp)
                                    .clip(RoundedCornerShape(12.dp))
                            ) {
                                AndroidView(
                                    factory = { context ->
                                        Configuration.getInstance().userAgentValue = "SooGoodCustomerApp/1.0"
                                        MapView(context).apply {
                                            setTileSource(TileSourceFactory.MAPNIK)
                                            setMultiTouchControls(true)
                                            controller.setZoom(15.0)

                                            val centerLat = (storeLat + customerLat) / 2.0
                                            val centerLng = (storeLng + customerLng) / 2.0
                                            controller.setCenter(GeoPoint(centerLat, centerLng))

                                            val storeMarker = Marker(this).apply {
                                                position = GeoPoint(storeLat, storeLng)
                                                title = "🏪 ${currentOrder.merchantName}"
                                                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                                            }
                                            overlays.add(storeMarker)

                                            val customerMarker = Marker(this).apply {
                                                position = GeoPoint(customerLat, customerLng)
                                                title = "📍 Delivery: ${currentOrder.deliveryAddress.receiverName ?: "Customer"}"
                                                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
                                            }
                                            overlays.add(customerMarker)

                                            val rLat = currentOrder.driverLat ?: ((storeLat + customerLat) / 2.0)
                                            val rLng = currentOrder.driverLng ?: ((storeLng + customerLng) / 2.0)
                                            val riderMarker = Marker(this).apply {
                                                position = GeoPoint(rLat, rLng)
                                                title = "🛵 Rider (${currentOrder.driverName ?: "En route"})"
                                                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                                            }
                                            overlays.add(riderMarker)
                                        }
                                    },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                        }
                    }
                }

                // DELIVERY OTP CARD
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(16.dp),
                        shadowElevation = 2.dp
                    ) {
                        Column(
                            modifier = Modifier.padding(20.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Key,
                                    contentDescription = "OTP",
                                    tint = SooGoodPrimaryGreen
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Delivery Verification OTP",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Surface(
                                color = MaterialTheme.colorScheme.surface,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = currentOrder.deliveryOtp,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 8.sp,
                                    color = SooGoodPrimaryGreen,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = "Share this OTP with your delivery executive upon arrival",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Delivery Status Timeline
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Status: ${currentOrder.orderStatus.name.replace("_", " ")}",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SooGoodPrimaryGreen
                            )
                            Text(
                                text = "Estimated Delivery: ${currentOrder.estimatedDeliveryMinutes} mins",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            StatusStepRow(title = "Order Placed", isDone = true)
                            StatusStepRow(title = "Merchant Accepted", isDone = currentOrder.orderStatus >= OrderStatus.MERCHANT_ACCEPTED)
                            StatusStepRow(title = "Preparing / Packing", isDone = currentOrder.orderStatus >= OrderStatus.PREPARING)
                            StatusStepRow(title = "On The Way 🛵", isDone = currentOrder.orderStatus >= OrderStatus.ON_THE_WAY)
                            StatusStepRow(title = "Delivered 🎉", isDone = currentOrder.orderStatus == OrderStatus.DELIVERED)
                        }
                    }
                }

                // Delivery Partner Info & In-App Chat
                item {
                    val isDriverAssigned = !currentOrder.driverName.isNullOrBlank()
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(48.dp)
                                            .clip(CircleShape)
                                            .background(MaterialTheme.colorScheme.primaryContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DeliveryDining,
                                            contentDescription = "Driver",
                                            tint = SooGoodPrimaryGreen
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = if (isDriverAssigned) currentOrder.driverName!! else "Assigning Delivery Partner...",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (isDriverAssigned) (currentOrder.driverPhone ?: "+91 9732145678") else "A delivery partner will be assigned shortly",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = {
                                        if (isDriverAssigned) {
                                            activeCallTargetLabel = "Delivery Partner (${currentOrder.driverName})"
                                        }
                                    },
                                    enabled = isDriverAssigned
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Call,
                                        contentDescription = "Call Driver",
                                        tint = if (isDriverAssigned) SooGoodPrimaryGreen else MaterialTheme.colorScheme.outline
                                    )
                                }
                            }

                            if (isDriverAssigned) {
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = { showRiderChatSheet = true },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Icon(Icons.Default.Chat, contentDescription = null, tint = SooGoodBrand)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("💬 Chat with Rider", color = SooGoodBrand, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                // Actions: 30-Second Cancel Order Window
                if (currentOrder.orderStatus != OrderStatus.DELIVERED && currentOrder.orderStatus != OrderStatus.CANCELLED) {
                    item {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            if (remainingCancelSec > 0) {
                                OutlinedButton(
                                    onClick = { orderViewModel.cancelOrder(currentOrder.id) },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(48.dp),
                                    shape = RoundedCornerShape(12.dp)
                                ) {
                                    Text(
                                        text = "Cancel Order (${remainingCancelSec}s remaining)",
                                        color = Color.Red,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else {
                                Text(
                                    text = "🔒 Cancellation window closed (30s limit exceeded)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }

            // IN-APP RIDER CHAT BOTTOM SHEET
            if (showRiderChatSheet) {
                ModalBottomSheet(
                    onDismissRequest = { showRiderChatSheet = false },
                    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(400.dp)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "💬 Live Chat with Delivery Partner",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 12.dp)
                        )

                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(chatMessages) { msg ->
                                Surface(
                                    color = if (msg.isFromRider) MaterialTheme.colorScheme.surfaceVariant else SooGoodPrimaryGreen.copy(alpha = 0.2f),
                                    shape = RoundedCornerShape(12.dp),
                                    modifier = Modifier.align(if (msg.isFromRider) Alignment.Start else Alignment.End)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Text(msg.sender, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                        Text(msg.text, style = MaterialTheme.typography.bodyMedium)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedTextField(
                                value = chatInputText,
                                onValueChange = { chatInputText = it },
                                placeholder = { Text("Type message to rider...") },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = {
                                    if (chatInputText.isNotBlank()) {
                                        chatMessages.add(ChatMessage("You", chatInputText, isFromRider = false))
                                        chatInputText = ""
                                    }
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SooGoodPrimaryGreen)
                            ) {
                                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusStepRow(title: String, isDone: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = if (isDone) SooGoodPrimaryGreen else MaterialTheme.colorScheme.outline,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(12.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal,
            color = if (isDone) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
        )
    }
}
