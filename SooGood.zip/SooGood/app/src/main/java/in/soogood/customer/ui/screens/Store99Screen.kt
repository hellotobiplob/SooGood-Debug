package `in`.soogood.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.customer.domain.model.CartItem
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.ui.components.MerchantConflictDialog
import `in`.soogood.customer.ui.components.ProductCard
import `in`.soogood.customer.ui.theme.SooGoodFood
import `in`.soogood.customer.ui.theme.SooGoodMart
import `in`.soogood.customer.ui.viewmodel.CartViewModel
import `in`.soogood.customer.ui.viewmodel.Store99ViewModel

@Composable
fun Store99Screen(
    cartType: CartType,
    viewModel: Store99ViewModel,
    cartViewModel: CartViewModel,
    onBackClick: () -> Unit,
    onCartClick: () -> Unit
) {
    val isFood = cartType == CartType.FOOD
    val accent = if (isFood) SooGoodFood else SooGoodMart

    val products by viewModel.products.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()

    val foodCart by cartViewModel.foodCart.collectAsState()
    val hypermartCart by cartViewModel.hypermartCart.collectAsState()
    val activeCart = if (isFood) foodCart else hypermartCart

    val conflictState by cartViewModel.merchantConflictState.collectAsState()

    conflictState?.let { conflict ->
        MerchantConflictDialog(
            conflict = conflict,
            onConfirmReplace = { cartViewModel.confirmReplaceCart() },
            onDismiss = { cartViewModel.dismissConflictDialog() }
        )
    }

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .statusBarsPadding()
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .clickable(onClick = onBackClick),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back"
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isFood) "99 Store · Food Items" else "99 Store · Hypermart Items",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "All items available under ₹99 rupees",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = accent)
                }
            } else {
                LazyColumn(
                    contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(Brush.linearGradient(listOf(accent, accent.copy(alpha = 0.8f))))
                                .padding(20.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "UNDER ₹99 STORE 🏷️",
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        fontSize = 20.sp
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = if (isFood)
                                            "Tasty dishes & snacks priced under ₹99"
                                        else
                                            "Daily essentials & groceries under ₹99",
                                        color = Color.White.copy(alpha = 0.9f),
                                        fontSize = 13.sp
                                    )
                                }
                                Icon(
                                    imageVector = Icons.Default.LocalOffer,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(48.dp)
                                )
                            }
                        }
                    }

                    if (products.isEmpty()) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Surface(
                                    color = accent.copy(alpha = 0.12f),
                                    shape = CircleShape,
                                    modifier = Modifier.size(80.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("🏷️", fontSize = 40.sp)
                                    }
                                }
                                Spacer(modifier = Modifier.height(16.dp))
                                Text(
                                    text = "No Items Under ₹99 Found",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Check back soon! We are adding more budget-friendly items daily.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    textAlign = TextAlign.Center
                                )
                            }
                        }
                    } else {
                        items(products) { product ->
                            val qty = activeCart.items.find { it.product.id == product.id }?.quantity ?: 0
                            ProductCard(
                                product = product,
                                cartQuantity = qty,
                                onAddClick = {
                                    val item = CartItem(
                                        id = product.id,
                                        product = product,
                                        quantity = 1
                                    )
                                    val mId = product.restaurantId ?: product.storeId ?: "store_99"
                                    val mName = if (isFood) "Restaurant Partner" else "Hypermart Partner"
                                    cartViewModel.addToCart(
                                        item = item,
                                        merchantId = mId,
                                        merchantName = mName,
                                        distanceKm = 1.5
                                    )
                                },
                                onIncrease = { cartViewModel.updateQuantity(cartType, product.id, qty + 1) },
                                onDecrease = { cartViewModel.updateQuantity(cartType, product.id, qty - 1) }
                            )
                        }
                    }
                }
            }

            if (activeCart.itemCount > 0) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(accent)
                        .clickable(onClick = onCartClick)
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.ShoppingCart, null, tint = Color.White)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "${activeCart.itemCount} item${if (activeCart.itemCount > 1) "s" else ""} in cart",
                        color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                    )
                    Text("View cart  ›", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
