package `in`.soogood.customer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.customer.domain.model.Address
import `in`.soogood.customer.domain.model.Cart
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.NotificationItem
import `in`.soogood.customer.domain.model.Restaurant
import `in`.soogood.customer.domain.model.Store
import `in`.soogood.customer.domain.repository.AddressRepository
import `in`.soogood.customer.domain.repository.CartRepository
import `in`.soogood.customer.domain.repository.NotificationRepository
import `in`.soogood.customer.domain.repository.StoreRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class HomeViewModel(
    private val storeRepository: StoreRepository,
    private val addressRepository: AddressRepository,
    private val cartRepository: CartRepository,
    private val notificationRepository: NotificationRepository
) : ViewModel() {

    private val _selectedTab = MutableStateFlow(CartType.FOOD)
    val selectedTab: StateFlow<CartType> = _selectedTab.asStateFlow()

    private val _restaurants = MutableStateFlow<List<Restaurant>>(emptyList())
    val restaurants: StateFlow<List<Restaurant>> = _restaurants.asStateFlow()

    private val _hypermartStores = MutableStateFlow<List<Store>>(emptyList())
    val hypermartStores: StateFlow<List<Store>> = _hypermartStores.asStateFlow()

    val selectedAddress: StateFlow<Address?> = addressRepository.selectedAddress
    val foodCart: StateFlow<Cart> = cartRepository.foodCart
    val hypermartCart: StateFlow<Cart> = cartRepository.hypermartCart
    val notifications: StateFlow<List<NotificationItem>> = notificationRepository.notifications

    init {
        loadData()
        observeAddressChanges()
    }

    fun selectTab(tab: CartType) {
        _selectedTab.value = tab
    }

    fun loadData() {
        viewModelScope.launch {
            val rawRestaurants = storeRepository.getFoodRestaurants()
            val rawStores = storeRepository.getHypermartStores()
            recalculateDistances(selectedAddress.value, rawRestaurants, rawStores)
        }
    }

    private fun observeAddressChanges() {
        viewModelScope.launch {
            selectedAddress.collect { addr ->
                recalculateDistances(addr, _restaurants.value, _hypermartStores.value)
            }
        }
    }

    private fun recalculateDistances(
        address: Address?,
        restaurantsList: List<Restaurant>,
        storesList: List<Store>
    ) {
        val userLat = if (address?.latitude != null && address.latitude != 0.0) address.latitude else 23.9922
        val userLng = if (address?.longitude != null && address.longitude != 0.0) address.longitude else 88.5833

        val updatedRestaurants = restaurantsList.map { r ->
            val dist = calculateDistance(userLat, userLng, r.latitude, r.longitude)
            r.copy(distanceKm = dist)
        }

        val updatedStores = storesList.map { s ->
            val dist = calculateDistance(userLat, userLng, s.latitude, s.longitude)
            s.copy(distanceKm = dist)
        }

        _restaurants.value = updatedRestaurants
        _hypermartStores.value = updatedStores
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        if (lat1 == 0.0 && lon1 == 0.0) return 1.5
        if (lat2 == 0.0 && lon2 == 0.0) return 1.5
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                Math.sin(dLon / 2) * Math.sin(dLon / 2)
        val c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
        val rawDist = r * c
        return Math.round(rawDist * 10.0) / 10.0
    }
}
