package `in`.soogood.customer.domain.model

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestampMillis: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val type: String = "ORDER" // ORDER, PROMO, SYSTEM
)
