package `in`.soogood.customer.ui.screens

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.TrendingUp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.ui.theme.SooGoodFood
import `in`.soogood.customer.ui.theme.SooGoodMart
import java.util.Locale

// TODO: replace with real suggestions from your search API (restaurants/dishes or dark-store catalogue)
private val foodTrending = listOf("Biryani", "Pizza", "Burger", "Paneer Butter Masala", "Dosa", "Chinese", "Ice cream")
private val martTrending = listOf("Milk", "Eggs", "Bread", "Onion", "Tomato", "Atta", "Chicken", "Curd", "Bananas", "Butter")
private val martBrowse = listOf(
    "🥦 Vegetables", "🍎 Fruits", "🥛 Dairy & Bread", "🥚 Eggs", "🍗 Chicken & Meat",
    "🐟 Fish & Seafood", "🌾 Atta, Rice & Dal", "🍪 Snacks", "🧃 Cold drinks", "🧴 Personal care"
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SearchScreen(
    cartType: CartType,
    onBackClick: () -> Unit,
    onSearch: (query: String) -> Unit,
    onCategoryClick: (String) -> Unit = {}
) {
    val isFood = cartType == CartType.FOOD
    val accent = if (isFood) SooGoodFood else SooGoodMart
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val focusRequester = remember { FocusRequester() }

    var query by remember { mutableStateOf("") }
    val recents = remember { mutableStateListOf<String>() } // TODO: persist with DataStore/Room
    val trending = if (isFood) foodTrending else martTrending

    fun submit(text: String) {
        val q = text.trim()
        if (q.isEmpty()) return
        recents.remove(q); recents.add(0, q)
        if (recents.size > 8) recents.removeAt(recents.lastIndex)
        focusManager.clearFocus()
        onSearch(q)
    }

    // Voice search via the system speech recognizer (no RECORD_AUDIO permission required)
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spoken.isNullOrBlank()) { query = spoken; submit(spoken) }
        }
    }
    fun startVoice() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PROMPT, if (isFood) "Say a dish or restaurant" else "Say what you need")
        }
        try { voiceLauncher.launch(intent) }
        catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Voice search isn't available on this device", Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(Unit) { focusRequester.requestFocus() }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding().imePadding()) {
        // Search field
        Row(Modifier.padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onBackClick), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.ArrowBack, "Back")
            }
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 12.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Search, null, tint = accent)
                Spacer(Modifier.width(8.dp))
                Box(Modifier.weight(1f)) {
                    if (query.isEmpty()) {
                        Text(
                            if (isFood) "Search restaurants or dishes" else "Search for milk, eggs, atta…",
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp),
                        cursorBrush = SolidColor(accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { submit(query) }),
                        modifier = Modifier.fillMaxWidth().focusRequester(focusRequester)
                    )
                }
                if (query.isNotEmpty()) {
                    Icon(Icons.Default.Close, "Clear", Modifier.size(20.dp).clickable { query = "" })
                    Spacer(Modifier.width(10.dp))
                }
                Box(
                    Modifier.size(34.dp).clip(CircleShape).background(accent.copy(alpha = 0.12f)).clickable { startVoice() },
                    contentAlignment = Alignment.Center
                ) { Icon(Icons.Default.Mic, "Voice search", tint = accent, modifier = Modifier.size(20.dp)) }
            }
        }

        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp)) {
            if (query.isBlank()) {
                if (recents.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Recent searches", fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                        Text("Clear", color = accent, fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.clickable { recents.clear() })
                    }
                    Spacer(Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        recents.forEach { SearchChip(it, Icons.Default.History) { query = it; submit(it) } }
                    }
                    Spacer(Modifier.height(24.dp))
                }

                Text("Trending now", fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(10.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    trending.forEach { SearchChip(it, Icons.Default.TrendingUp) { query = it; submit(it) } }
                }

                if (!isFood) {
                    Spacer(Modifier.height(24.dp))
                    Text("Browse categories", fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(10.dp))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        martBrowse.forEach { label ->
                            Text(
                                label, fontWeight = FontWeight.Medium,
                                modifier = Modifier.clip(RoundedCornerShape(12.dp))
                                    .background(accent.copy(alpha = 0.10f))
                                    .clickable { onCategoryClick(label.substringAfter(' ')) }
                                    .padding(horizontal = 14.dp, vertical = 10.dp)
                            )
                        }
                    }
                }
            } else {
                // Live suggestions
                val matches = (trending + martBrowse.map { it.substringAfter(' ') })
                    .filter { it.contains(query.trim(), ignoreCase = true) }.distinct().take(8)
                SuggestionRow("Search for \"${query.trim()}\"", accent) { submit(query) }
                matches.forEach { SuggestionRow(it, accent) { query = it; submit(it) } }
            }
        }
    }
}

@Composable
private fun SearchChip(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(MaterialTheme.colorScheme.surface)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.width(6.dp))
        Text(text, fontSize = 14.sp)
    }
}

@Composable
private fun SuggestionRow(text: String, accent: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Search, null, tint = accent, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, fontSize = 15.sp)
    }
}
