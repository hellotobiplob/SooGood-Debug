package `in`.soogood.customer.data.repository

import `in`.soogood.customer.domain.model.Cart
import `in`.soogood.customer.domain.model.CartItem
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.repository.AddToCartResult
import `in`.soogood.customer.domain.repository.CartRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class InMemoryCartRepository : CartRepository {

    private val _foodCart = MutableStateFlow(Cart(cartType = CartType.FOOD))
    override val foodCart: StateFlow<Cart> = _foodCart.asStateFlow()

    private val _hypermartCart = MutableStateFlow(Cart(cartType = CartType.HYPERMART))
    override val hypermartCart: StateFlow<Cart> = _hypermartCart.asStateFlow()

    override suspend fun addToCart(
        item: CartItem,
        merchantId: String,
        merchantName: String,
        distanceKm: Double,
        forceReplace: Boolean
    ): AddToCartResult {
        val targetFlow = if (item.product.cartType == CartType.FOOD) _foodCart else _hypermartCart
        val currentCart = targetFlow.value

        if (!currentCart.isEmpty && currentCart.merchantId != merchantId && !forceReplace) {
            return AddToCartResult.MerchantConflict(
                currentMerchantName = currentCart.merchantName ?: "Another Store",
                newMerchantName = merchantName,
                pendingCartItem = item,
                cartType = item.product.cartType
            )
        }

        val baseCart = if (forceReplace || currentCart.merchantId != merchantId) {
            Cart(
                cartType = item.product.cartType,
                merchantId = merchantId,
                merchantName = merchantName,
                distanceKm = distanceKm,
                items = emptyList()
            )
        } else {
            currentCart.copy(distanceKm = distanceKm)
        }

        val existingIndex = baseCart.items.indexOfFirst {
            it.product.id == item.product.id &&
                    it.selectedWeightVariant == item.selectedWeightVariant &&
                    it.selectedCustomizations == item.selectedCustomizations
        }

        val updatedItems = if (existingIndex >= 0) {
            val existing = baseCart.items[existingIndex]
            val updated = existing.copy(quantity = existing.quantity + item.quantity)
            baseCart.items.toMutableList().apply { set(existingIndex, updated) }
        } else {
            baseCart.items + item
        }

        targetFlow.value = baseCart.copy(items = updatedItems)
        return AddToCartResult.Success
    }

    override suspend fun updateQuantity(cartType: CartType, itemId: String, newQuantity: Int) {
        val targetFlow = if (cartType == CartType.FOOD) _foodCart else _hypermartCart
        val current = targetFlow.value

        if (newQuantity <= 0) {
            removeItem(cartType, itemId)
            return
        }

        val updatedItems = current.items.map { item ->
            if (item.id == itemId) item.copy(quantity = newQuantity) else item
        }
        targetFlow.value = current.copy(items = updatedItems)
    }

    override suspend fun removeItem(cartType: CartType, itemId: String) {
        val targetFlow = if (cartType == CartType.FOOD) _foodCart else _hypermartCart
        val current = targetFlow.value
        val updatedItems = current.items.filterNot { it.id == itemId }

        if (updatedItems.isEmpty()) {
            targetFlow.value = Cart(cartType = cartType)
        } else {
            targetFlow.value = current.copy(items = updatedItems)
        }
    }

    override suspend fun clearCart(cartType: CartType) {
        if (cartType == CartType.FOOD) {
            _foodCart.value = Cart(cartType = CartType.FOOD)
        } else {
            _hypermartCart.value = Cart(cartType = CartType.HYPERMART)
        }
    }
}
