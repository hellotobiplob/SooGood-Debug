package `in`.soogood.customer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Product
import `in`.soogood.customer.domain.repository.ProductRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class Store99ViewModel(
    private val productRepository: ProductRepository,
    val cartType: CartType
) : ViewModel() {

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        loadUnder99Products()
    }

    fun loadUnder99Products() {
        viewModelScope.launch {
            _isLoading.value = true
            try {
                _products.value = productRepository.getProductsUnderPrice(cartType, maxPricePaise = 99_00L)
            } catch (_: Exception) {
                _products.value = emptyList()
            } finally {
                _isLoading.value = false
            }
        }
    }
}
