package `in`.soogood.customer.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.customer.ui.theme.SooGoodBrand
import `in`.soogood.customer.ui.theme.SooGoodBrandDark
import `in`.soogood.customer.ui.theme.SooGoodFood
import `in`.soogood.customer.ui.theme.SooGoodMart
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@Composable
fun SplashScreen(onSplashFinished: () -> Unit) {
    val logoScale = remember { Animatable(0.3f) }
    val logoAlpha = remember { Animatable(0f) }
    val titleY = remember { Animatable(30f) }
    val titleAlpha = remember { Animatable(0f) }
    val badgeAlpha = remember { Animatable(0f) }

    LaunchedEffect(Unit) {
        launch { logoAlpha.animateTo(1f, tween(350)) }
        launch { logoScale.animateTo(1f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow)) }
        delay(300)
        launch { titleY.animateTo(0f, tween(450, easing = FastOutSlowInEasing)) }
        launch { titleAlpha.animateTo(1f, tween(450)) }
        delay(250)
        badgeAlpha.animateTo(1f, tween(400))
        delay(1200)
        onSplashFinished()
    }

    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(SooGoodBrand, SooGoodBrandDark))),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Box(
                Modifier.scale(logoScale.value).alpha(logoAlpha.value).size(104.dp)
                    .clip(RoundedCornerShape(30.dp)).background(Color.White),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.ShoppingBag, "SooGood", tint = SooGoodBrand, modifier = Modifier.size(58.dp))
            }

            Spacer(Modifier.height(24.dp))

            Column(
                Modifier.offset { IntOffset(0, titleY.value.dp.roundToPx()) }.alpha(titleAlpha.value),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("SooGood", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Spacer(Modifier.height(4.dp))
                Text("Food & groceries, delivered fast", fontSize = 16.sp, color = Color.White.copy(alpha = 0.85f))
            }

            Spacer(Modifier.height(32.dp))

            Row(Modifier.alpha(badgeAlpha.value), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Pill("Food", Icons.Default.Restaurant, SooGoodFood)
                Pill("Hypermart", Icons.Default.Bolt, SooGoodMart)
            }
        }
    }
}

@Composable
private fun Pill(text: String, icon: androidx.compose.ui.graphics.vector.ImageVector, color: Color) {
    Row(
        Modifier.clip(RoundedCornerShape(24.dp)).background(color).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}
