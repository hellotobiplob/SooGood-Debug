package `in`.soogood.customer.data.repository

import android.util.Log
import com.google.firebase.database.FirebaseDatabase
import `in`.soogood.customer.data.remote.DbMenuItem
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Product
import `in`.soogood.customer.domain.repository.ProductRepository
import kotlinx.coroutines.tasks.await

class FirebaseProductRepository : ProductRepository {

    private val dbRef = FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com").getReference("menu_items")
    private val storeRepo = FirebaseStoreRepository()

    private fun getFallbackMenuItems(storeId: String): List<DbMenuItem> {
        return if (storeId == "rest_01") {
            listOf(
                DbMenuItem(
                    id = "item_01",
                    storeId = storeId,
                    name = "Chicken Dum Biryani",
                    description = "Aromatic basmati rice cooked with tender chicken and authentic spices",
                    price = 220.0,
                    category = "Biryani",
                    isAvailable = true,
                    isVeg = false,
                    imageUrl = "https://picsum.photos/seed/biryaniitem/300/300"
                ),
                DbMenuItem(
                    id = "item_02",
                    storeId = storeId,
                    name = "Paneer Butter Masala",
                    description = "Soft paneer cubes in rich tomato gravy with butter and cream",
                    price = 180.0,
                    category = "Main Course",
                    isAvailable = true,
                    isVeg = true,
                    imageUrl = "https://picsum.photos/seed/paneer/300/300"
                )
            )
        } else {
            listOf(
                DbMenuItem(
                    id = "item_g1",
                    storeId = storeId,
                    name = "Fresh Organic Milk (1L)",
                    description = "Farm fresh cow milk packed hygienically",
                    price = 65.0,
                    category = "Dairy",
                    isAvailable = true,
                    isVeg = true,
                    imageUrl = "https://picsum.photos/seed/milk/300/300"
                )
            )
        }
    }

    private suspend fun fetchMenuItemsForStore(storeId: String): List<DbMenuItem> {
        return try {
            val snapshot = dbRef.child(storeId).get().await()
            val list = mutableListOf<DbMenuItem>()
            for (child in snapshot.children) {
                val item = child.getValue(DbMenuItem::class.java)
                if (item != null) {
                    list.add(item.copy(id = item.id ?: child.key, storeId = storeId))
                }
            }
            if (list.isEmpty()) {
                getFallbackMenuItems(storeId)
            } else {
                list
            }
        } catch (e: Exception) {
            Log.e("FirebaseProductRepo", "Error fetching menu items from Firebase RTDB (Permission denied or network error), using fallback mock items", e)
            getFallbackMenuItems(storeId)
        }
    }

    override suspend fun getProductsForRestaurant(restaurantId: String): List<Product> {
        val items = fetchMenuItemsForStore(restaurantId)
        return items.map { it.toProduct(CartType.FOOD, restaurantId = restaurantId) }
    }

    override suspend fun getProductsForStore(storeId: String): List<Product> {
        val items = fetchMenuItemsForStore(storeId)
        return items.map { it.toProduct(CartType.HYPERMART, storeId = storeId) }
    }

    override suspend fun getProductById(productId: String): Product? {
        val restaurants = storeRepo.getFoodRestaurants()
        val stores = storeRepo.getHypermartStores()
        val allStores = restaurants.map { it.id } + stores.map { it.id }

        for (storeId in allStores) {
            val items = fetchMenuItemsForStore(storeId)
            val found = items.find { it.id == productId }
            if (found != null) {
                val cartType = if (restaurants.any { it.id == storeId }) CartType.FOOD else CartType.HYPERMART
                return found.toProduct(cartType, restaurantId = if (cartType == CartType.FOOD) storeId else null, storeId = if (cartType == CartType.HYPERMART) storeId else null)
            }
        }
        return null
    }

    override suspend fun searchProducts(query: String, cartType: CartType): List<Product> {
        if (query.isBlank()) return emptyList()
        val q = query.lowercase().trim()
        val restaurants = storeRepo.getFoodRestaurants()
        val stores = storeRepo.getHypermartStores()
        val targetStores = if (cartType == CartType.FOOD) restaurants.map { it.id } else stores.map { it.id }

        val matching = mutableListOf<Product>()
        for (storeId in targetStores) {
            val items = fetchMenuItemsForStore(storeId)
            items.forEach { item ->
                if (item.name.lowercase().contains(q) || item.category.lowercase().contains(q)) {
                    matching.add(item.toProduct(cartType, restaurantId = if (cartType == CartType.FOOD) storeId else null, storeId = if (cartType == CartType.HYPERMART) storeId else null))
                }
            }
        }
        return matching
    }

    override suspend fun getProductsUnderPrice(cartType: CartType, maxPricePaise: Long): List<Product> {
        val restaurants = storeRepo.getFoodRestaurants()
        val stores = storeRepo.getHypermartStores()
        val targetStores = if (cartType == CartType.FOOD) restaurants.map { it.id } else stores.map { it.id }

        val result = mutableListOf<Product>()
        for (storeId in targetStores) {
            val items = fetchMenuItemsForStore(storeId)
            items.forEach { item ->
                val prod = item.toProduct(cartType, restaurantId = if (cartType == CartType.FOOD) storeId else null, storeId = if (cartType == CartType.HYPERMART) storeId else null)
                if (prod.pricePaise <= maxPricePaise) {
                    result.add(prod)
                }
            }
        }
        return result
    }

    private fun DbMenuItem.toProduct(
        cartType: CartType,
        restaurantId: String? = null,
        storeId: String? = null
    ): Product {
        val img = photoUrl.takeIf { !it.isNullOrBlank() }
            ?: imageUrl.takeIf { !it.isNullOrBlank() }
            ?: "https://picsum.photos/seed/${name.hashCode()}/300/300"
        return Product(
            id = id ?: "item_${name.hashCode()}",
            restaurantId = restaurantId,
            storeId = storeId,
            name = name,
            description = description ?: "",
            pricePaise = (price * 100).toLong(),
            imageUrl = img,
            isVeg = isVeg ?: true,
            isBestseller = true,
            isAvailable = isAvailable ?: true,
            category = category,
            cartType = cartType
        )
    }
}
