package `in`.soogood.customer.domain.model

enum class OrderStatus {
    ORDER_PLACED,
    PAYMENT_CONFIRMED,
    MERCHANT_ACCEPTED,
    PREPARING,
    READY_FOR_PICKUP,
    DRIVER_ASSIGNED,
    PICKED_UP,
    ON_THE_WAY,
    DELIVERED,
    CANCELLED
}

enum class PaymentMethod {
    CASH_ON_DELIVERY,
    ONLINE_SIMULATED
}

data class Order(
    val id: String,
    val cartType: CartType,
    val merchantId: String,
    val merchantName: String,
    val items: List<CartItem>,
    val subtotalPaise: Long,
    val deliveryFeePaise: Long,
    val taxesAndPackagingPaise: Long,
    val discountPaise: Long = 0L,
    val totalAmountPaise: Long,
    val deliveryAddress: Address,
    val paymentMethod: PaymentMethod,
    val orderStatus: OrderStatus,
    val deliveryOtp: String = "4829",
    val createdAtMillis: Long = System.currentTimeMillis(),
    val estimatedDeliveryMinutes: Int = 30,
    val driverName: String? = null,
    val driverPhone: String? = null,
    val driverLat: Double? = null,
    val driverLng: Double? = null
)
