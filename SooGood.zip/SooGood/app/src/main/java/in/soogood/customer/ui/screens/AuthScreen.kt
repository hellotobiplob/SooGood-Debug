package `in`.soogood.customer.ui.screens

import android.util.Log
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import androidx.credentials.exceptions.GetCredentialException
import androidx.credentials.exceptions.NoCredentialException
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import kotlinx.coroutines.launch
import `in`.soogood.customer.R
import `in`.soogood.customer.ui.theme.SooGoodPrimaryGreen
import `in`.soogood.customer.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AuthScreen(
    authViewModel: AuthViewModel,
    onBackClick: () -> Unit,
    onAuthSuccess: () -> Unit
) {
    val email by authViewModel.email.collectAsState()
    val name by authViewModel.name.collectAsState()
    val mobileNumber by authViewModel.mobileNumber.collectAsState()
    val isLoading by authViewModel.isLoading.collectAsState()
    val errorMessage by authViewModel.errorMessage.collectAsState()
    val isGoogleAuthPending by authViewModel.isGoogleAuthPending.collectAsState()

    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isGoogleAuthPending) "Complete Your Profile" else "Sign In to SooGood", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = {
                        if (isGoogleAuthPending) {
                            authViewModel.cancelGoogleSignIn()
                        } else {
                            onBackClick()
                        }
                    }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(24.dp)
                .background(MaterialTheme.colorScheme.background),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (isGoogleAuthPending) {
                // PROFILE COMPLETION AFTER GOOGLE AUTH
                Text(
                    text = "Google Account Verified",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Please verify your name and enter your 10-digit Indian mobile number",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(24.dp))

                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    color = SooGoodPrimaryGreen.copy(alpha = 0.1f),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Google Account Email:", style = MaterialTheme.typography.labelSmall, color = SooGoodPrimaryGreen)
                        Text(email, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { authViewModel.updateName(it) },
                    label = { Text("Full Name (Retrieved from Google & Editable)") },
                    placeholder = { Text("e.g. Subhash Mondal") },
                    leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = SooGoodPrimaryGreen) },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(16.dp))

                OutlinedTextField(
                    value = mobileNumber,
                    onValueChange = { authViewModel.updateMobileNumber(it) },
                    label = { Text("10-Digit Indian Mobile Number") },
                    placeholder = { Text("9732145678") },
                    leadingIcon = { Icon(Icons.Default.Call, contentDescription = null, tint = SooGoodPrimaryGreen) },
                    prefix = { Text("+91 ") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )

                errorMessage?.let { error ->
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = error,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                Spacer(modifier = Modifier.height(24.dp))

                val isGoogleSubmitEnabled = !isLoading && name.isNotBlank() && mobileNumber.length == 10

                Button(
                    onClick = {
                        authViewModel.completeGoogleSignIn(onAuthSuccess)
                    },
                    enabled = isGoogleSubmitEnabled,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SooGoodPrimaryGreen)
                ) {
                    Text(
                        text = if (isLoading) "Please wait..." else "SUBMIT & CONTINUE",
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                // CLEAN GOOGLE SIGN IN UI (NATIVE CREDENTIAL MANAGER ACCOUNT PICKER)
                Text(
                    text = "Welcome to SooGood",
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Food & groceries delivered fast to your doorstep",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(32.dp))

                errorMessage?.let { error ->
                    Text(
                        text = error,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                OutlinedButton(
                    onClick = {
                        scope.launch {
                            try {
                                val webClientId = context.getString(R.string.default_web_client_id)

                                val signInWithGoogleOption = GetSignInWithGoogleOption.Builder(webClientId)
                                    .build()

                                val googleIdOption = GetGoogleIdOption.Builder()
                                    .setServerClientId(webClientId)
                                    .setFilterByAuthorizedAccounts(false)
                                    .setAutoSelectEnabled(false)
                                    .build()

                                val request = GetCredentialRequest.Builder()
                                    .addCredentialOption(signInWithGoogleOption)
                                    .addCredentialOption(googleIdOption)
                                    .build()

                                val credentialManager = CredentialManager.create(context)
                                val result = credentialManager.getCredential(context, request)
                                val credential = result.credential

                                if (credential is GoogleIdTokenCredential) {
                                    val gName = credential.displayName
                                        ?: credential.givenName
                                        ?: credential.id.substringBefore("@")
                                    val gEmail = credential.id
                                    val gIdToken = credential.idToken
                                    authViewModel.handleGoogleAccountSelected(gName, gEmail, gIdToken, onAuthSuccess)
                                } else if (credential.type == GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                                    try {
                                        val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)
                                        val gName = googleIdTokenCredential.displayName
                                            ?: googleIdTokenCredential.givenName
                                            ?: googleIdTokenCredential.id.substringBefore("@")
                                        val gEmail = googleIdTokenCredential.id
                                        val gIdToken = googleIdTokenCredential.idToken
                                        authViewModel.handleGoogleAccountSelected(gName, gEmail, gIdToken, onAuthSuccess)
                                    } catch (e: Exception) {
                                        Log.e("AuthScreen", "Failed to parse GoogleIdTokenCredential", e)
                                        authViewModel.setErrorMessage("Failed to read account info from Google.")
                                    }
                                } else {
                                    authViewModel.setErrorMessage("Unsupported credential type returned.")
                                }
                            } catch (e: GetCredentialCancellationException) {
                                // User cancelled the Google account picker dialog; do nothing cleanly
                                Log.d("AuthScreen", "Google Sign-In cancelled by user")
                            } catch (e: NoCredentialException) {
                                Log.e("AuthScreen", "NoCredentialException during Google Sign-In", e)
                                authViewModel.setErrorMessage("No Google account credential available on device. Please verify your Google account or SHA-1 configuration.")
                            } catch (e: GetCredentialException) {
                                Log.e("AuthScreen", "GetCredentialException during Google Sign-In", e)
                                authViewModel.setErrorMessage("Google Sign-In error: ${e.localizedMessage}")
                            } catch (e: Exception) {
                                Log.e("AuthScreen", "Unexpected error during Google Sign-In", e)
                                authViewModel.setErrorMessage("Google Sign-In failed. Please try again.")
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "G",
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF4285F4)
                        )
                        Spacer(modifier = Modifier.width(16.dp))
                        Text(
                            text = "Sign in with Google",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
