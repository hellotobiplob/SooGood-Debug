package `in`.soogood.customer.data.repository

import android.content.Context
import android.util.Log
import androidx.core.content.edit
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.database.FirebaseDatabase
import `in`.soogood.customer.domain.model.User
import `in`.soogood.customer.domain.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await

class FirebaseAuthRepository(context: Context? = null) : AuthRepository {

    private val firebaseAuth = FirebaseAuth.getInstance()
    private val dbRef = FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com").getReference("users")
    private val prefs = context?.getSharedPreferences("soogood_firebase_auth_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<User?>(loadSavedUser())
    override val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        val fbUser = firebaseAuth.currentUser
        if (fbUser != null) {
            val saved = loadSavedUser()
            if (saved != null && saved.id == fbUser.uid) {
                _currentUser.value = saved
            } else {
                _currentUser.value = User(
                    id = fbUser.uid,
                    name = fbUser.displayName ?: fbUser.email?.substringBefore("@") ?: "Customer",
                    mobileNumber = fbUser.phoneNumber ?: "",
                    email = fbUser.email,
                    isGuest = false
                )
            }
        }
    }

    private fun loadSavedUser(): User? {
        val p = prefs ?: return null
        val savedId = p.getString("user_id", null) ?: return null
        val savedName = p.getString("user_name", "") ?: ""
        val savedMobile = p.getString("user_mobile", "") ?: ""
        val savedEmail = p.getString("user_email", null)

        return User(
            id = savedId,
            name = savedName,
            mobileNumber = savedMobile,
            email = savedEmail,
            isGuest = false
        )
    }

    private fun persistLocalUser(user: User) {
        prefs?.edit {
            putString("user_id", user.id)
            putString("user_name", user.name)
            putString("user_mobile", user.mobileNumber)
            putString("user_email", user.email)
        }
    }

    override suspend fun checkAndSignInExistingGoogleUser(idToken: String): Result<User?> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val authResult = firebaseAuth.signInWithCredential(credential).await()
            val fbUser = authResult.user ?: return Result.success(null)
            val uid = fbUser.uid
            val userEmail = fbUser.email ?: ""

            var existingUser: User? = null
            try {
                val snapshot = dbRef.child(uid).get().await()
                if (snapshot.exists()) {
                    val u = try { snapshot.getValue(User::class.java) } catch (_: Exception) { null }
                    if (u != null) {
                        existingUser = u.copy(id = uid)
                    } else {
                        val name = snapshot.child("name").getValue(String::class.java) ?: ""
                        val mobile = snapshot.child("mobileNumber").getValue(String::class.java) ?: ""
                        val email = snapshot.child("email").getValue(String::class.java) ?: userEmail
                        existingUser = User(id = uid, name = name, mobileNumber = mobile, email = email)
                    }
                }
            } catch (e: Exception) {
                Log.e("FirebaseAuthRepo", "Error fetching user snapshot from RTDB for $uid", e)
            }

            if (existingUser == null && userEmail.isNotBlank()) {
                try {
                    val allUsers = dbRef.get().await()
                    for (child in allUsers.children) {
                        val u = try { child.getValue(User::class.java) } catch (_: Exception) { null }
                        val email = u?.email ?: child.child("email").getValue(String::class.java)
                        if (email.equals(userEmail, ignoreCase = true)) {
                            val name = u?.name ?: child.child("name").getValue(String::class.java) ?: userEmail.substringBefore("@")
                            val mobile = u?.mobileNumber ?: child.child("mobileNumber").getValue(String::class.java) ?: ""
                            val id = child.key ?: uid
                            existingUser = User(id = id, name = name, mobileNumber = mobile, email = email)
                            break
                        }
                    }
                } catch (e: Exception) {
                    Log.e("FirebaseAuthRepo", "Error searching users by email in RTDB", e)
                }
            }

            if (existingUser == null) {
                val saved = loadSavedUser()
                if (saved != null && (saved.id == uid || saved.email.equals(userEmail, ignoreCase = true))) {
                    existingUser = saved
                }
            }

            if (existingUser != null && existingUser.mobileNumber.isNotBlank()) {
                val validUser = existingUser.copy(
                    id = uid,
                    email = userEmail.ifBlank { existingUser.email }
                )
                _currentUser.value = validUser
                persistLocalUser(validUser)
                Log.d("FirebaseAuthRepo", "Found existing registered Google user: ${validUser.email}")
                Result.success(validUser)
            } else {
                Log.d("FirebaseAuthRepo", "No existing registered user with mobile number found for: $userEmail")
                Result.success(null)
            }
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Error checking existing Google user", e)
            Result.failure(e)
        }
    }

    override suspend fun signInWithGoogle(
        idToken: String,
        name: String,
        mobileNumber: String
    ): Result<User> {
        return try {
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val authResult = firebaseAuth.signInWithCredential(credential).await()
            val fbUser = authResult.user ?: throw Exception("Firebase Auth returned null user.")

            val uid = fbUser.uid
            val userEmail = fbUser.email ?: ""
            val displayName = name.ifBlank { fbUser.displayName ?: userEmail.substringBefore("@") }

            val user = User(
                id = uid,
                name = displayName,
                mobileNumber = mobileNumber,
                email = userEmail,
                isGuest = false
            )

            dbRef.child(uid).setValue(user).await()
            Log.d("FirebaseAuthRepo", "Successfully authenticated with Firebase Auth & saved profile to Firebase RTDB: $uid")

            _currentUser.value = user
            persistLocalUser(user)
            Result.success(user)
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Error during real Google Sign-In with Firebase Auth & RTDB", e)
            Result.failure(e)
        }
    }

    override suspend fun signUpWithEmail(
        email: String,
        password: String,
        name: String,
        mobileNumber: String
    ): Result<User> {
        val uid = "usr_${System.currentTimeMillis()}"
        val user = User(
            id = uid,
            name = name.ifBlank { email.substringBefore("@") },
            mobileNumber = mobileNumber,
            email = email,
            isGuest = false
        )
        _currentUser.value = user
        persistLocalUser(user)

        try {
            dbRef.child(uid).setValue(user).await()
            Log.d("FirebaseAuthRepo", "Successfully saved user to Firebase RTDB")
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Firebase RTDB write error (using local profile)", e)
        }
        return Result.success(user)
    }

    override suspend fun signInWithEmail(email: String, password: String): Result<User> {
        var foundUser: User? = null
        try {
            val snapshot = dbRef.get().await()
            for (child in snapshot.children) {
                val u = child.getValue(User::class.java)
                if (u != null && u.email.equals(email, ignoreCase = true)) {
                    foundUser = u
                    break
                }
            }
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Firebase RTDB read error (using local profile)", e)
        }

        val user = foundUser ?: loadSavedUser() ?: User(
            id = "usr_${System.currentTimeMillis()}",
            name = email.substringBefore("@"),
            mobileNumber = "",
            email = email,
            isGuest = false
        )
        _currentUser.value = user
        persistLocalUser(user)
        return Result.success(user)
    }

    override suspend fun updateProfile(name: String, mobileNumber: String): Result<User> {
        val current = _currentUser.value ?: loadSavedUser() ?: User(
            id = "usr_${System.currentTimeMillis()}",
            name = name,
            mobileNumber = mobileNumber
        )
        val updated = current.copy(name = name, mobileNumber = mobileNumber)
        _currentUser.value = updated
        persistLocalUser(updated)

        try {
            dbRef.child(updated.id).setValue(updated)
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Firebase RTDB profile update error", e)
        }
        return Result.success(updated)
    }

    override suspend fun requestOtp(mobileNumber: String): Result<Boolean> {
        return Result.success(true)
    }

    override suspend fun verifyOtp(mobileNumber: String, otp: String): Result<User> {
        val uid = "usr_${System.currentTimeMillis()}"
        val user = User(
            id = uid,
            name = "Customer",
            mobileNumber = mobileNumber,
            isGuest = false
        )
        _currentUser.value = user
        persistLocalUser(user)

        try {
            dbRef.child(uid).setValue(user)
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Firebase RTDB OTP verify error", e)
        }
        return Result.success(user)
    }

    override suspend fun logout() {
        try {
            firebaseAuth.signOut()
        } catch (e: Exception) {
            Log.e("FirebaseAuthRepo", "Error signing out from Firebase Auth", e)
        }
        prefs?.edit { clear() }
        _currentUser.value = null
    }
}
