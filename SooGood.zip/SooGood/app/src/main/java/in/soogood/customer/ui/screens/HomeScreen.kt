package `in`.soogood.customer.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import `in`.soogood.customer.util.LocaleHelper
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Restaurant
import `in`.soogood.customer.domain.model.Store
import `in`.soogood.customer.domain.usecase.DeliveryFeeCalculator
import `in`.soogood.customer.ui.theme.SooGoodBrand
import `in`.soogood.customer.ui.theme.SooGoodFood
import `in`.soogood.customer.ui.theme.SooGoodMart
import `in`.soogood.customer.ui.viewmodel.HomeViewModel
import kotlinx.coroutines.delay

private data class Cat(val emoji: String, val label: String)

private val martCategories = listOf(
    Cat("🥦", "Vegetables"), Cat("🍎", "Fruits"), Cat("🥛", "Dairy"), Cat("🥚", "Eggs"),
    Cat("🍗", "Chicken"), Cat("🐟", "Fish"), Cat("🌾", "Atta & Rice"), Cat("🍪", "Snacks")
)
private val foodCategories = listOf(
    Cat("🍛", "Biryani"), Cat("🌯", "Kathi Rolls"), Cat("🍩", "Bengali Sweets"),
    Cat("🐟", "Fish Curry"), Cat("🍜", "Chowmein"), Cat("🫓", "Luchi Alur Dom"),
    Cat("🌮", "Mughlai Paratha"), Cat("🥟", "Momos"), Cat("☕", "Chai & Snacks"),
    Cat("🍔", "Burgers"), Cat("🍕", "Pizza")
)

@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onRestaurantClick: (String) -> Unit,
    onCategoryClick: (String) -> Unit,
    on99StoreClick: (CartType) -> Unit,
    onSearchClick: (CartType) -> Unit,
    onCartClick: (CartType) -> Unit,
    onAddressClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onOrdersClick: () -> Unit,
    onProfileClick: () -> Unit
) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val restaurants by viewModel.restaurants.collectAsState()
    val hypermartStores by viewModel.hypermartStores.collectAsState()
    val selectedAddress by viewModel.selectedAddress.collectAsState()
    val foodCart by viewModel.foodCart.collectAsState()
    val hypermartCart by viewModel.hypermartCart.collectAsState()
    val notifications by viewModel.notifications.collectAsState()

    val isFood = selectedTab == CartType.FOOD
    val cartCount = if (isFood) foodCart.itemCount else hypermartCart.itemCount
    val unread = notifications.count { !it.isRead }
    val accent by animateColorAsState(if (isFood) SooGoodFood else SooGoodMart, tween(300), label = "accent")

    // Filter stores within delivery radius, falling back to all stores so newly created stores are never hidden
    val nearbyRestaurants = restaurants.filter { it.distanceKm <= 25.0 }.ifEmpty { restaurants }
    val nearbyHypermartStores = hypermartStores.filter { it.distanceKm <= 25.0 }.ifEmpty { hypermartStores }

    Scaffold(
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = true,
                    onClick = { /* Already on Home */ },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home", fontWeight = FontWeight.Bold) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SooGoodBrand,
                        selectedTextColor = SooGoodBrand,
                        indicatorColor = SooGoodBrand.copy(alpha = 0.12f)
                    )
                )

                NavigationBarItem(
                    selected = false,
                    onClick = { on99StoreClick(selectedTab) },
                    icon = { Icon(Icons.Default.LocalOffer, contentDescription = "99 Store") },
                    label = { Text("99 Store", fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )

                NavigationBarItem(
                    selected = false,
                    onClick = onOrdersClick,
                    icon = { Icon(Icons.AutoMirrored.Filled.ReceiptLong, contentDescription = "Orders") },
                    label = { Text("Orders", fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )

                NavigationBarItem(
                    selected = false,
                    onClick = onProfileClick,
                    icon = { Icon(Icons.Default.Person, contentDescription = "Profile") },
                    label = { Text("Profile", fontWeight = FontWeight.SemiBold) },
                    colors = NavigationBarItemDefaults.colors(
                        unselectedIconColor = Color.Gray,
                        unselectedTextColor = Color.Gray
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(MaterialTheme.colorScheme.background)
        ) {
            Column(Modifier.fillMaxSize()) {
                HomeHeader(
                    accent = accent,
                    addressTitle = selectedAddress?.title ?: "Add Delivery Address",
                    tab = selectedTab,
                    unread = unread,
                    cartCount = cartCount,
                    onTabSelected = { viewModel.selectTab(it) },
                    onAddressClick = onAddressClick,
                    onSearchClick = { onSearchClick(selectedTab) },
                    onNotificationClick = onNotificationClick,
                    onCartClick = { onCartClick(selectedTab) }
                )

                val isServiceAvailable = if (isFood) nearbyRestaurants.isNotEmpty() else nearbyHypermartStores.isNotEmpty()

                if (!isServiceAvailable) {
                    SooGoodUnavailableScreen()
                } else if (isFood) {
                    FoodContent(nearbyRestaurants, onRestaurantClick, onCategoryClick)
                } else {
                    MartContent(nearbyHypermartStores, accent, onRestaurantClick, onCategoryClick)
                }
            }

            if (cartCount > 0) {
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(16.dp)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(accent)
                        .clickable { onCartClick(selectedTab) }
                        .padding(horizontal = 18.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.ShoppingCart, null, tint = Color.White)
                    Spacer(Modifier.width(10.dp))
                    Text(
                        "$cartCount item${if (cartCount > 1) "s" else ""} in cart",
                        color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                    )
                    Text("View cart  ›", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

// ───────────────────────── Header ─────────────────────────

@Composable
private fun HomeHeader(
    accent: Color,
    addressTitle: String,
    tab: CartType,
    unread: Int,
    cartCount: Int,
    onTabSelected: (CartType) -> Unit,
    onAddressClick: () -> Unit,
    onSearchClick: () -> Unit,
    onNotificationClick: () -> Unit,
    onCartClick: () -> Unit
) {
    val isFood = tab == CartType.FOOD
    Column(
        Modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(accent, lerp(accent, Color.Black, 0.2f))))
            .padding(horizontal = 16.dp)
            .padding(top = 8.dp, bottom = 14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).clickable(onClick = onAddressClick)
            ) {
                Text(
                    if (isFood) "Food delivery to" else "Hypermart · ⚡ 45 min to",
                    color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(4.dp))
                    Text(
                        addressTitle, color = Color.White, fontWeight = FontWeight.Bold,
                        fontSize = 18.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.widthIn(max = 200.dp)
                    )
                    Icon(Icons.Default.KeyboardArrowDown, null, tint = Color.White)
                }
            }
            val context = LocalContext.current
            Box(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.2f))
                    .clickable {
                        val next = if (LocaleHelper.currentLanguage.value == "bn") "en" else "bn"
                        LocaleHelper.setLocale(context, next)
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (LocaleHelper.currentLanguage.value == "bn") "🌐 বাংলা" else "🌐 EN",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                )
            }
            Spacer(Modifier.width(8.dp))
            HeaderIcon(Icons.Default.Notifications, unread, onNotificationClick)
            Spacer(Modifier.width(8.dp))
            HeaderIcon(Icons.Default.ShoppingCart, cartCount, onCartClick)
        }

        Spacer(Modifier.height(14.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White)
                .clickable(onClick = onSearchClick)
                .padding(horizontal = 14.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Search, null, tint = accent)
            Spacer(Modifier.width(10.dp))
            Text(
                if (isFood) "Search \"biryani\", \"pizza\"…" else "Search \"milk\", \"eggs\", \"atta\"…",
                color = Color(0xFF6B6B85), modifier = Modifier.weight(1f), maxLines = 1
            )
            Icon(Icons.Default.Mic, "Voice search", tint = accent)
        }

        Spacer(Modifier.height(12.dp))

        Row(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.18f))
                .padding(4.dp)
        ) {
            CartType.values().forEach { type ->
                val selected = type == tab
                Row(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(11.dp))
                        .background(if (selected) Color.White else Color.Transparent)
                        .clickable { onTabSelected(type) }
                        .padding(vertical = 10.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val food = type == CartType.FOOD
                    Icon(
                        if (food) Icons.Default.Restaurant else Icons.Default.Bolt, null,
                        tint = if (selected) accent else Color.White, modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (food) "Food" else "Hypermart", fontWeight = FontWeight.Bold,
                        color = if (selected) accent else Color.White
                    )
                }
            }
        }
    }
}

@Composable
private fun HeaderIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, badge: Int, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(22.dp))
        if (badge > 0) {
            Box(
                Modifier.align(Alignment.TopEnd).padding(2.dp).size(16.dp).clip(CircleShape).background(Color(0xFFFFD43B)),
                contentAlignment = Alignment.Center
            ) {
                Text(if (badge > 9) "9+" else "$badge", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color.Black)
            }
        }
    }
}

@Composable
private fun SooGoodUnavailableScreen() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Surface(
            color = SooGoodBrand.copy(alpha = 0.12f),
            shape = CircleShape,
            modifier = Modifier.size(100.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Text("🛵", fontSize = 52.sp)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Coming Soon to Your Location",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = "No restaurants or hypermarts are listed within 8 km of your selected location. SooGood is expanding fast and coming soon to your area!",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
            lineHeight = 22.sp
        )
    }
}

// ───────────────────────── Food ─────────────────────────

private data class BannerData(
    val title: String,
    val subtitle: String,
    val emoji: String,
    val c1: Color,
    val c2: Color
)

@Composable
private fun AutoSlidingBannerCarousel() {
    val freeDeliveryThreshold = DeliveryFeeCalculator.FREE_DELIVERY_THRESHOLD_PAISE / 100
    val banners = remember(freeDeliveryThreshold) {
        listOf(
            BannerData(
                title = "FLAT ₹20 OFF",
                subtitle = "On order above ₹599",
                emoji = "🍔",
                c1 = Color(0xFFFF6B35),
                c2 = Color(0xFFFF9A3C)
            ),
            BannerData(
                title = "FREE DELIVERY",
                subtitle = "On order above ₹$freeDeliveryThreshold",
                emoji = "🛵",
                c1 = Color(0xFF5B3DF5),
                c2 = Color(0xFF8E7BFF)
            )
        )
    }

    val pagerState = rememberPagerState(pageCount = { banners.size })

    LaunchedEffect(pagerState) {
        while (true) {
            delay(12_000L) // Auto slide every 12 seconds
            val nextPage = (pagerState.currentPage + 1) % banners.size
            pagerState.animateScrollToPage(nextPage)
        }
    }

    Column {
        HorizontalPager(
            state = pagerState,
            pageSpacing = 12.dp,
            modifier = Modifier.fillMaxWidth()
        ) { page ->
            val b = banners[page]
            PromoBanner(
                title = b.title,
                subtitle = b.subtitle,
                emoji = b.emoji,
                c1 = b.c1,
                c2 = b.c2,
                fullWidth = true
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center
        ) {
            repeat(banners.size) { index ->
                val isSelected = pagerState.currentPage == index
                Box(
                    modifier = Modifier
                        .padding(horizontal = 3.dp)
                        .size(if (isSelected) 8.dp else 6.dp)
                        .clip(CircleShape)
                        .background(if (isSelected) SooGoodBrand else Color.Gray.copy(alpha = 0.4f))
                )
            }
        }
    }
}

@Composable
private fun FoodContent(
    restaurants: List<Restaurant>,
    onRestaurantClick: (String) -> Unit,
    onCategoryClick: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            AutoSlidingBannerCarousel()
        }
        item {
            SectionTitle("What's on your mind?")
            Spacer(Modifier.height(12.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                items(foodCategories) { RoundCategory(it, SooGoodFood.copy(alpha = 0.12f)) { onCategoryClick(it.label) } }
            }
        }
        item { SectionTitle("Popular restaurants near you") }
        items(restaurants) { RestaurantItem(it) { onRestaurantClick(it.id) } }
    }
}

@Composable
private fun RestaurantItem(restaurant: Restaurant, onClick: () -> Unit) {
    val hue = (restaurant.name.hashCode().toUInt() % 360u).toFloat()
    val c1 = Color.hsv(hue, 0.35f, 0.98f)
    val c2 = Color.hsv((hue + 40f) % 360f, 0.45f, 0.92f)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(150.dp).background(Brush.linearGradient(listOf(c1, c2)))) {
                Text("🍽️", fontSize = 48.sp, modifier = Modifier.align(Alignment.Center))
                if (!restaurant.offerText.isNullOrBlank()) {
                    Text(
                        restaurant.offerText.toString(),
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.BottomStart).padding(12.dp)
                            .clip(RoundedCornerShape(8.dp)).background(Color(0xCC14142B))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        restaurant.name, style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(SooGoodMart).padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("%.1f".format(restaurant.rating), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.width(2.dp))
                        Icon(Icons.Default.Star, null, tint = Color.White, modifier = Modifier.size(12.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "${restaurant.cuisine} · ${restaurant.deliveryTimeMinutes} mins · ${restaurant.distanceKm} km",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ───────────────────────── Hypermart ─────────────────────────

@Composable
private fun MartContent(
    stores: List<Store>,
    accent: Color,
    onStoreClick: (String) -> Unit,
    onCategoryClick: (String) -> Unit
) {
    LazyColumn(
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 96.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        item {
            PromoBanner(
                "Groceries in 45 mins ⚡", "Fresh vegetables, dairy, eggs & meat from your nearest dark store",
                "🛒", Color(0xFF12B886), Color(0xFF38D9A9), fullWidth = true
            )
        }
        item {
            SectionTitle("Shop by category")
            Spacer(Modifier.height(12.dp))
            martCategories.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    row.forEach { cat ->
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable { onCategoryClick(cat.label) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                Modifier.size(68.dp).clip(RoundedCornerShape(18.dp)).background(accent.copy(alpha = 0.12f)),
                                contentAlignment = Alignment.Center
                            ) { Text(cat.emoji, fontSize = 32.sp) }
                            Spacer(Modifier.height(6.dp))
                            Text(cat.label, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                        }
                    }
                }
            }
        }
        item { SectionTitle("Hypermart Stores near you") }
        if (stores.isEmpty()) {
            item {
                Text(
                    "No hypermart stores available right now.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
        } else {
            items(stores) { store ->
                StoreItem(store) { onStoreClick(store.id) }
            }
        }
    }
}

@Composable
private fun StoreItem(store: Store, onClick: () -> Unit) {
    val hue = (store.name.hashCode().toUInt() % 360u).toFloat()
    val c1 = Color.hsv(hue, 0.35f, 0.98f)
    val c2 = Color.hsv((hue + 40f) % 360f, 0.45f, 0.92f)
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(140.dp).background(Brush.linearGradient(listOf(c1, c2)))) {
                Text("🛒", fontSize = 48.sp, modifier = Modifier.align(Alignment.Center))
                if (!store.offerText.isNullOrBlank()) {
                    Text(
                        store.offerText.toString(),
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                        modifier = Modifier
                            .align(Alignment.BottomStart).padding(12.dp)
                            .clip(RoundedCornerShape(8.dp)).background(Color(0xCC14142B))
                            .padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        store.name, style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Row(
                        Modifier.clip(RoundedCornerShape(8.dp)).background(SooGoodMart).padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("%.1f".format(store.rating), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.width(2.dp))
                        Icon(Icons.Default.Star, null, tint = Color.White, modifier = Modifier.size(12.dp))
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(
                    "${store.category} · ${store.estimatedDeliveryMinutes} mins · ${store.distanceKm} km",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

// ───────────────────────── Shared bits ─────────────────────────

@Composable
private fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold)
}

@Composable
private fun RoundCategory(cat: Cat, bg: Color, onClick: () -> Unit) {
    Column(
        Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
            Text(cat.emoji, fontSize = 30.sp)
        }
        Spacer(Modifier.height(6.dp))
        Text(cat.label, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun PromoBanner(
    title: String, subtitle: String, emoji: String, c1: Color, c2: Color, fullWidth: Boolean = false
) {
    Box(
        Modifier
            .then(if (fullWidth) Modifier.fillMaxWidth() else Modifier.width(300.dp))
            .height(120.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Brush.linearGradient(listOf(c1, c2)))
            .padding(18.dp)
    ) {
        Column(Modifier.align(Alignment.CenterStart).fillMaxWidth(0.7f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Spacer(Modifier.height(4.dp))
            Text(subtitle, color = Color.White.copy(alpha = 0.92f), fontSize = 13.sp, lineHeight = 17.sp)
        }
        Text(emoji, fontSize = 56.sp, modifier = Modifier.align(Alignment.CenterEnd))
    }
}
