package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.NotificationItem
import kotlinx.coroutines.flow.StateFlow

interface NotificationRepository {
    val notifications: StateFlow<List<NotificationItem>>
    suspend fun markAsRead(notificationId: String)
    suspend fun clearAll()
}
