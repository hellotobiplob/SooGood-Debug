package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.Order
import kotlinx.coroutines.flow.StateFlow

interface OrderRepository {
    val orders: StateFlow<List<Order>>
    suspend fun placeOrder(order: Order): Result<Order>
    suspend fun getOrderById(orderId: String): Order?
    suspend fun cancelOrder(orderId: String): Result<Boolean>
}
