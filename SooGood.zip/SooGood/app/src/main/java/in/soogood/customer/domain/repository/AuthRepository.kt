package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.User
import kotlinx.coroutines.flow.StateFlow

interface AuthRepository {
    val currentUser: StateFlow<User?>
    suspend fun requestOtp(mobileNumber: String): Result<Boolean>
    suspend fun verifyOtp(mobileNumber: String, otp: String): Result<User>
    suspend fun signUpWithEmail(email: String, password: String, name: String, mobileNumber: String): Result<User>
    suspend fun signInWithEmail(email: String, password: String): Result<User>
    suspend fun signInWithGoogle(idToken: String, name: String, mobileNumber: String): Result<User>
    suspend fun checkAndSignInExistingGoogleUser(idToken: String): Result<User?>
    suspend fun updateProfile(name: String, mobileNumber: String): Result<User>
    suspend fun logout()
}
