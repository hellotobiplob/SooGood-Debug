package `in`.soogood.customer.domain.model

data class Store(
    val id: String,
    val name: String,
    val category: String,
    val rating: Double,
    val distanceKm: Double,
    val estimatedDeliveryMinutes: Int,
    val imageUrl: String,
    val offerText: String? = null,
    val isOpen: Boolean = true,
    val latitude: Double = 12.9716,
    val longitude: Double = 77.5946
)
