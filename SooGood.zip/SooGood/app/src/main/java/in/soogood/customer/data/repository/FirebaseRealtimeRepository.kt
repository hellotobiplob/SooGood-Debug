package `in`.soogood.customer.data.repository

import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class LiveOrderState(
    val orderId: String = "",
    val status: String = "PLACED",
    val riderId: String? = null,
    val riderName: String? = null,
    val riderPhone: String? = null,
    val riderLat: Double? = null,
    val riderLng: Double? = null,
    val estimatedDeliveryMinutes: Int = 30,
    val deliveryOtp: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

class FirebaseRealtimeRepository {

    private fun getDbRef(): DatabaseReference {
        return FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com").getReference("live_orders")
    }

    fun broadcastOrderState(state: LiveOrderState) {
        if (state.orderId.isBlank()) return
        val updates = mapOf<String, Any>(
            "orderId" to state.orderId,
            "status" to state.status,
            "riderId" to (state.riderId ?: ""),
            "riderName" to (state.riderName ?: ""),
            "riderPhone" to (state.riderPhone ?: ""),
            "riderLat" to (state.riderLat ?: 23.9922),
            "riderLng" to (state.riderLng ?: 88.5833),
            "estimatedDeliveryMinutes" to state.estimatedDeliveryMinutes,
            "deliveryOtp" to state.deliveryOtp,
            "updatedAt" to System.currentTimeMillis()
        )
        getDbRef().child(state.orderId).updateChildren(updates)
            .addOnSuccessListener {
                Log.d("FirebaseRealtime", "Successfully broadcasted order state for ${state.orderId}")
            }
            .addOnFailureListener { e ->
                Log.e("FirebaseRealtime", "Failed to broadcast order state", e)
            }
    }

    fun observeLiveOrder(orderId: String): Flow<LiveOrderState?> = callbackFlow {
        if (orderId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    trySend(null)
                    return
                }

                try {
                    val status = snapshot.child("status").getValue(String::class.java) ?: "PLACED"
                    val riderId = snapshot.child("riderId").getValue(String::class.java)
                    val riderName = snapshot.child("riderName").getValue(String::class.java)
                    val riderPhone = snapshot.child("riderPhone").getValue(String::class.java)
                    val riderLat = snapshot.child("riderLat").getValue(Double::class.java)
                    val riderLng = snapshot.child("riderLng").getValue(Double::class.java)
                    val eta = snapshot.child("estimatedDeliveryMinutes").getValue(Int::class.java) ?: 30
                    val otp = snapshot.child("deliveryOtp").getValue(String::class.java) ?: ""
                    val time = snapshot.child("updatedAt").getValue(Long::class.java) ?: System.currentTimeMillis()

                    val liveState = LiveOrderState(
                        orderId = orderId,
                        status = status,
                        riderId = riderId,
                        riderName = riderName,
                        riderPhone = riderPhone,
                        riderLat = riderLat,
                        riderLng = riderLng,
                        estimatedDeliveryMinutes = eta,
                        deliveryOtp = otp,
                        updatedAt = time
                    )
                    trySend(liveState)
                } catch (e: Exception) {
                    Log.e("FirebaseRealtime", "Error parsing live order snapshot", e)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseRealtime", "Live order listener cancelled: ${error.message}")
            }
        }

        getDbRef().child(orderId).addValueEventListener(listener)

        awaitClose {
            getDbRef().child(orderId).removeEventListener(listener)
        }
    }
}
