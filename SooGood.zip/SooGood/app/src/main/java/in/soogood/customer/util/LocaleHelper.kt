package `in`.soogood.customer.util

import android.content.Context
import android.content.res.Configuration
import androidx.compose.runtime.mutableStateOf
import java.util.Locale

object LocaleHelper {
    private const val PREF_NAME = "soogood_locale_pref"
    private const val KEY_LANG = "selected_language"

    var currentLanguage = mutableStateOf("en")

    fun getSavedLanguage(context: Context): String {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val lang = prefs.getString(KEY_LANG, "en") ?: "en"
        currentLanguage.value = lang
        return lang
    }

    fun setLocale(context: Context, languageCode: String): Context {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_LANG, languageCode).apply()
        currentLanguage.value = languageCode

        val locale = Locale(languageCode)
        Locale.setDefault(locale)

        val config = Configuration(context.resources.configuration)
        config.setLocale(locale)

        return context.createConfigurationContext(config)
    }
}
