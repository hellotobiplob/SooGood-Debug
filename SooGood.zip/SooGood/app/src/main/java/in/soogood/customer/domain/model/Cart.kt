package `in`.soogood.customer.domain.model

data class SelectedCustomization(
    val groupId: String,
    val groupTitle: String,
    val optionId: String,
    val optionName: String,
    val extraPricePaise: Long
)

data class CartItem(
    val id: String,
    val product: Product,
    val quantity: Int,
    val selectedWeightVariant: String? = null,
    val selectedCustomizations: List<SelectedCustomization> = emptyList(),
    val specialInstructions: String? = null
) {
    val unitPricePaise: Long
        get() {
            val customizationExtra = selectedCustomizations.sumOf { it.extraPricePaise }
            return product.pricePaise + customizationExtra
        }

    val totalItemPricePaise: Long
        get() = unitPricePaise * quantity
}

data class Cart(
    val cartType: CartType,
    val merchantId: String? = null,
    val merchantName: String? = null,
    val distanceKm: Double = 1.0,
    val items: List<CartItem> = emptyList()
) {
    val subtotalPaise: Long
        get() = items.sumOf { it.totalItemPricePaise }

    val itemCount: Int
        get() = items.sumOf { it.quantity }

    val isEmpty: Boolean
        get() = items.isEmpty()
}
