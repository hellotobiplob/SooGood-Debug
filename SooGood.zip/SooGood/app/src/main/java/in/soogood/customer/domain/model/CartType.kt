package `in`.soogood.customer.domain.model

enum class CartType {
    FOOD,
    HYPERMART
}
