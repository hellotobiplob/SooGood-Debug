package `in`.soogood.customer.data.repository

import android.content.Context
import android.util.Log
import `in`.soogood.customer.data.remote.SupabaseConfig
import `in`.soogood.customer.domain.model.User
import `in`.soogood.customer.domain.repository.AuthRepository
import io.github.jan.supabase.gotrue.auth
import io.github.jan.supabase.gotrue.providers.builtin.Email
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SupabaseAuthRepository(
    context: Context? = null
) : AuthRepository {

    private val authClient = SupabaseConfig.client.auth
    private val prefs = context?.getSharedPreferences("soogood_user_profile_prefs", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<User?>(loadSavedProfile())
    override val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    init {
        val supabaseUser = authClient.currentUserOrNull()
        if (supabaseUser != null) {
            val savedName = prefs?.getString("user_name", null)
            val savedMobile = prefs?.getString("user_mobile", null)

            _currentUser.value = User(
                id = supabaseUser.id,
                name = savedName ?: supabaseUser.email?.substringBefore("@") ?: "Customer",
                mobileNumber = savedMobile ?: supabaseUser.phone ?: "",
                email = supabaseUser.email,
                isGuest = false
            )
        }
    }

    private fun loadSavedProfile(): User? {
        val savedName = prefs?.getString("user_name", null) ?: return null
        val savedMobile = prefs?.getString("user_mobile", "") ?: ""
        val savedEmail = prefs?.getString("user_email", null)
        val savedId = prefs?.getString("user_id", "usr_saved") ?: "usr_saved"

        return User(
            id = savedId,
            name = savedName,
            mobileNumber = savedMobile,
            email = savedEmail,
            isGuest = false
        )
    }

    private fun persistProfile(user: User) {
        prefs?.edit()
            ?.putString("user_id", user.id)
            ?.putString("user_name", user.name)
            ?.putString("user_mobile", user.mobileNumber)
            ?.putString("user_email", user.email)
            ?.apply()
    }

    override suspend fun signUpWithEmail(
        email: String,
        password: String,
        name: String,
        mobileNumber: String
    ): Result<User> {
        return try {
            authClient.signUpWith(Email) {
                this.email = email
                this.password = password
            }
            val userInfo = authClient.currentUserOrNull()
            val user = User(
                id = userInfo?.id ?: "usr_${System.currentTimeMillis()}",
                name = if (name.isNotBlank()) name else email.substringBefore("@"),
                mobileNumber = mobileNumber,
                email = email,
                isGuest = false
            )
            _currentUser.value = user
            persistProfile(user)
            Log.d(TAG, "Successfully registered user with Supabase: ${user.email}")
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Error registering user with Supabase", e)
            Result.failure(e)
        }
    }

    override suspend fun signInWithEmail(email: String, password: String): Result<User> {
        return try {
            authClient.signInWith(Email) {
                this.email = email
                this.password = password
            }
            val userInfo = authClient.currentUserOrNull()
            val savedName = prefs?.getString("user_name", null)
            val savedMobile = prefs?.getString("user_mobile", null)

            val user = User(
                id = userInfo?.id ?: "usr_${System.currentTimeMillis()}",
                name = savedName ?: email.substringBefore("@"),
                mobileNumber = savedMobile ?: "",
                email = email,
                isGuest = false
            )
            _currentUser.value = user
            persistProfile(user)
            Log.d(TAG, "Successfully logged in user with Supabase: ${user.email}")
            Result.success(user)
        } catch (e: Exception) {
            Log.e(TAG, "Error logging in user with Supabase", e)
            Result.failure(e)
        }
    }

    override suspend fun updateProfile(name: String, mobileNumber: String): Result<User> {
        val current = _currentUser.value ?: User(
            id = "usr_${System.currentTimeMillis()}",
            name = name,
            mobileNumber = mobileNumber
        )
        val updated = current.copy(name = name, mobileNumber = mobileNumber)
        _currentUser.value = updated
        persistProfile(updated)
        return Result.success(updated)
    }

    override suspend fun signInWithGoogle(idToken: String, name: String, mobileNumber: String): Result<User> {
        val user = User(
            id = "usr_${System.currentTimeMillis()}",
            name = name,
            mobileNumber = mobileNumber,
            isGuest = false
        )
        _currentUser.value = user
        persistProfile(user)
        return Result.success(user)
    }

    override suspend fun checkAndSignInExistingGoogleUser(idToken: String): Result<User?> {
        return Result.success(null)
    }

    override suspend fun requestOtp(mobileNumber: String): Result<Boolean> {
        return Result.success(true)
    }

    override suspend fun verifyOtp(mobileNumber: String, otp: String): Result<User> {
        val user = User(
            id = "usr_${System.currentTimeMillis()}",
            name = "Customer",
            mobileNumber = mobileNumber,
            isGuest = false
        )
        _currentUser.value = user
        persistProfile(user)
        return Result.success(user)
    }

    override suspend fun logout() {
        try {
            authClient.signOut()
        } catch (_: Exception) {}
        _currentUser.value = null
    }

    companion object {
        private const val TAG = "SupabaseAuthRepository"
    }
}
