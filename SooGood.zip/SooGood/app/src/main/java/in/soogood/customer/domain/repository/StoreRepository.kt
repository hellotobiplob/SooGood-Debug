package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.Restaurant
import `in`.soogood.customer.domain.model.Store

interface StoreRepository {
    suspend fun getFoodRestaurants(): List<Restaurant>
    suspend fun getHypermartStores(): List<Store>
    suspend fun getRestaurantById(id: String): Restaurant?
    suspend fun getStoreById(id: String): Store?
}
