package `in`.soogood.customer.data.repository

import `in`.soogood.customer.domain.model.NotificationItem
import `in`.soogood.customer.domain.repository.NotificationRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class RealNotificationRepository : NotificationRepository {

    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    override val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    override suspend fun markAsRead(notificationId: String) {
        val updated = _notifications.value.map {
            if (it.id == notificationId) it.copy(isRead = true) else it
        }
        _notifications.value = updated
    }

    override suspend fun clearAll() {
        _notifications.value = emptyList()
    }
}
