package `in`.soogood.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Help
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Translate
import androidx.compose.ui.platform.LocalContext
import `in`.soogood.customer.util.LocaleHelper
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.customer.ui.theme.SooGoodBrand
import `in`.soogood.customer.ui.theme.SooGoodBrandDark
import `in`.soogood.customer.ui.theme.SooGoodPrimaryGreen
import `in`.soogood.customer.ui.viewmodel.AuthViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(
    authViewModel: AuthViewModel,
    onBackClick: () -> Unit,
    onOrdersClick: () -> Unit,
    onAddressesClick: () -> Unit,
    onLoginClick: () -> Unit
) {
    val currentUser by authViewModel.currentUser.collectAsState()
    val name = currentUser?.name ?: "Guest"

    var showEditProfileSheet by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var showTermsDialog by remember { mutableStateOf(false) }
    var showLanguageDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current

    if (showLanguageDialog) {
        AlertDialog(
            onDismissRequest = { showLanguageDialog = false },
            title = { Text("App Language / ভাষা নির্বাচন", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (LocaleHelper.currentLanguage.value == "en") SooGoodBrand.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                LocaleHelper.setLocale(context, "en")
                                showLanguageDialog = false
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🌐 English", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        if (LocaleHelper.currentLanguage.value == "en") {
                            Text("✓ Selected", color = SooGoodBrand, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (LocaleHelper.currentLanguage.value == "bn") SooGoodBrand.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                LocaleHelper.setLocale(context, "bn")
                                showLanguageDialog = false
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("🌐 বাংলা (Bengali)", fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.weight(1f))
                        if (LocaleHelper.currentLanguage.value == "bn") {
                            Text("✓ নির্বাচিত", color = SooGoodBrand, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showLanguageDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)) {
                    Text("Close")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    var editName by remember(currentUser) { mutableStateOf(currentUser?.name ?: "") }
    var editMobile by remember(currentUser) { mutableStateOf(currentUser?.mobileNumber ?: "") }

    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Customer Care & Help", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    Text("Need help with an order, refund, or app query? Reach SooGood Customer Support:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("✉️ Email: care@soogood.in", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp, color = SooGoodBrand)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("📞 Toll-Free Helpline: +91 1800-200-7664", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("💬 WhatsApp Care: +91 98765-00123", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showSupportDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)) {
                    Text("OK")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (showTermsDialog) {
        AlertDialog(
            onDismissRequest = { showTermsDialog = false },
            title = { Text("Terms, Conditions & Privacy Policy", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    Text("SooGood Terms of Service & Privacy Policy", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("1. Orders & Pricing: All prices include applicable taxes. Food GST 5% & Delivery Fee GST 18% apply as per Govt regulations.", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("2. Packaging Charges: Packaging fees charged by merchant partners are capped at a maximum of ₹35 per order.", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("3. Cancellation & Refunds: Orders can be cancelled prior to restaurant acceptance. Full refund issued for missed/cancelled orders.", fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("4. Customer Privacy: Your personal data and location are stored securely in compliance with IT laws.", fontSize = 12.sp)
                }
            },
            confirmButton = {
                Button(onClick = { showTermsDialog = false }, colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)) {
                    Text("I Agree")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Account", fontWeight = FontWeight.ExtraBold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) { Icon(Icons.Default.ArrowBack, "Back") }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            Modifier.fillMaxSize().padding(padding),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                        .background(Brush.linearGradient(listOf(SooGoodBrand, SooGoodBrandDark)))
                        .clickable(enabled = currentUser == null, onClick = onLoginClick)
                        .padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)), contentAlignment = Alignment.Center) {
                        Text(name.take(1).uppercase(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(2.dp))
                        Text(
                            currentUser?.mobileNumber?.ifBlank { currentUser?.email } ?: "Log in for faster checkout & offers",
                            color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp
                        )
                    }
                    if (currentUser != null) {
                        IconButton(onClick = { showEditProfileSheet = true }) {
                            Icon(Icons.Default.Edit, contentDescription = "Edit Profile", tint = Color.White)
                        }
                    }
                }
            }

            item {
                Card(
                    Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column {
                        if (currentUser != null) {
                            ProfileOptionRow("Edit profile details", Icons.Default.Edit, { showEditProfileSheet = true })
                            Divider()
                        }
                        ProfileOptionRow("Your orders", Icons.Default.History, onOrdersClick)
                        Divider()
                        ProfileOptionRow("Saved addresses", Icons.Default.LocationOn, onAddressesClick)
                        Divider()
                        ProfileOptionRow("App Language / ভাষা (EN / বাংলা)", Icons.Default.Translate, { showLanguageDialog = true })
                        Divider()
                        ProfileOptionRow("Help & support", Icons.Default.Help, { showSupportDialog = true })
                        Divider()
                        ProfileOptionRow("Privacy policy & terms", Icons.Default.Security, { showTermsDialog = true })
                    }
                }
            }

            item {
                Card(
                    Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    if (currentUser != null) {
                        ProfileOptionRow("Log out", Icons.Default.Logout, { authViewModel.logout() }, MaterialTheme.colorScheme.error, showChevron = false)
                    } else {
                        ProfileOptionRow("Log in / Sign up", Icons.Default.Person, onLoginClick, SooGoodBrand, showChevron = false)
                    }
                }
            }
        }

        // EDIT PROFILE BOTTOM SHEET
        if (showEditProfileSheet) {
            ModalBottomSheet(
                onDismissRequest = { showEditProfileSheet = false },
                sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("Edit Profile Details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

                    OutlinedTextField(
                        value = editName,
                        onValueChange = { editName = it },
                        label = { Text("Full Name") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    OutlinedTextField(
                        value = editMobile,
                        onValueChange = { editMobile = it },
                        label = { Text("Mobile Number") },
                        leadingIcon = { Icon(Icons.Default.Call, contentDescription = null) },
                        prefix = { Text("+91 ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = {
                            authViewModel.updateCustomerProfile(editName, editMobile) {
                                showEditProfileSheet = false
                            }
                        },
                        enabled = editName.isNotBlank() && editMobile.length >= 10,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SooGoodPrimaryGreen)
                    ) {
                        Text("SAVE CHANGES", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun Divider() = HorizontalDivider(Modifier.padding(start = 72.dp), color = MaterialTheme.colorScheme.outline)

@Composable
private fun ProfileOptionRow(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    tint: Color = Color.Unspecified,
    showChevron: Boolean = true
) {
    val color = if (tint != Color.Unspecified) tint else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (tint != Color.Unspecified) tint else SooGoodBrand)
        }
        Spacer(Modifier.width(16.dp))
        Text(title, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, color = color, modifier = Modifier.weight(1f))
        if (showChevron) Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
