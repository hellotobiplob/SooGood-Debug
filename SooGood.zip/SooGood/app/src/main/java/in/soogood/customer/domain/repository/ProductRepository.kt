package `in`.soogood.customer.domain.repository

import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Product

interface ProductRepository {
    suspend fun getProductsForRestaurant(restaurantId: String): List<Product>
    suspend fun getProductsForStore(storeId: String): List<Product>
    suspend fun getProductById(productId: String): Product?
    suspend fun searchProducts(query: String, cartType: CartType): List<Product>
    suspend fun getProductsUnderPrice(cartType: CartType, maxPricePaise: Long = 99_00L): List<Product>
}
