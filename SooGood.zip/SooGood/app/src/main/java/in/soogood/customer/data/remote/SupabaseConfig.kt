package `in`.soogood.customer.data.remote

import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.gotrue.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.realtime.Realtime

object SupabaseConfig {

    const val SUPABASE_URL = "https://wouixoquhtnqjpdnclpm.supabase.co"
    const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_gVUabkRTS1MSdIoeNp5myQ_tR8i0m1v"
    const val SUPABASE_ANON_KEY = SUPABASE_PUBLISHABLE_KEY

    val client: SupabaseClient by lazy {
        createSupabaseClient(
            supabaseUrl = SUPABASE_URL,
            supabaseKey = SUPABASE_ANON_KEY
        ) {
            install(Auth)
            install(Postgrest)
            install(Realtime)
        }
    }
}
