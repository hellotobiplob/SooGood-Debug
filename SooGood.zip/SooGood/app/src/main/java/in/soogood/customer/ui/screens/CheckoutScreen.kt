package `in`.soogood.customer.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Money
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.PaymentMethod
import `in`.soogood.customer.domain.repository.AddressRepository
import `in`.soogood.customer.ui.theme.SooGoodPrimaryGreen
import `in`.soogood.customer.ui.viewmodel.AuthViewModel
import `in`.soogood.customer.ui.viewmodel.CartViewModel
import `in`.soogood.customer.ui.viewmodel.OrderViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutScreen(
    cartType: CartType,
    cartViewModel: CartViewModel,
    orderViewModel: OrderViewModel,
    authViewModel: AuthViewModel,
    addressRepository: AddressRepository,
    onBackClick: () -> Unit,
    onLoginClick: () -> Unit,
    onAddAddressClick: () -> Unit,
    onOrderPlaced: (String) -> Unit
) {
    val scope = rememberCoroutineScope()
    val foodCart by cartViewModel.foodCart.collectAsState()
    val hypermartCart by cartViewModel.hypermartCart.collectAsState()
    val cart = if (cartType == CartType.FOOD) foodCart else hypermartCart

    val currentUser by authViewModel.currentUser.collectAsState()
    val isLoggedIn = currentUser != null

    val savedAddresses by addressRepository.addresses.collectAsState()
    val selectedAddress by addressRepository.selectedAddress.collectAsState()

    val deliveryFee = cartViewModel.getDeliveryFeePaise(cart)
    val platformFee = cartViewModel.getPlatformFeePaise(cart)
    val taxesAndPkg = cartViewModel.getTaxesAndPackagingPaise(cart)
    val grandTotal = cartViewModel.getTotalAmountPaise(cart)
    val isDeliverable = cartViewModel.isCartDeliverable(cart)

    var selectedPaymentMethod by remember { mutableStateOf(PaymentMethod.ONLINE_SIMULATED) }
    var deliveryInstructions by remember { mutableStateOf("") }
    val isPlacingOrder by orderViewModel.isPlacingOrder.collectAsState()

    val canPlaceOrder = isLoggedIn && selectedAddress != null && !cart.isEmpty && isDeliverable && !isPlacingOrder

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Checkout", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBackClick) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        },
        bottomBar = {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shadowElevation = 8.dp,
                color = MaterialTheme.colorScheme.surface
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (!isLoggedIn) {
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = "🔑 Login Required: You must be logged in to place an order.",
                                color = MaterialTheme.colorScheme.onTertiaryContainer,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    } else if (selectedAddress == null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = "📍 Address Required: Please select or add a delivery address below.",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    } else if (!isDeliverable) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 12.dp)
                        ) {
                            Text(
                                text = "⚠️ Cannot Place Order: Store is ${cart.distanceKm} km away. Maximum delivery radius is 8.9 km.",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(12.dp)
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Total: ₹${grandTotal / 100}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (selectedPaymentMethod == PaymentMethod.CASH_ON_DELIVERY) "Cash on Delivery" else "Online (Simulated)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = {
                                if (!isLoggedIn) {
                                    onLoginClick()
                                } else if (selectedAddress == null) {
                                    onAddAddressClick()
                                } else {
                                    orderViewModel.placeOrder(
                                        cartType = cartType,
                                        paymentMethod = selectedPaymentMethod,
                                        specialInstructions = deliveryInstructions,
                                        onSuccess = onOrderPlaced
                                    )
                                }
                            },
                            enabled = if (isLoggedIn && selectedAddress != null) canPlaceOrder else true,
                            modifier = Modifier.height(48.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isLoggedIn && selectedAddress != null) SooGoodPrimaryGreen else MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text(
                                text = if (!isLoggedIn) "LOG IN TO PLACE ORDER ➔" else if (selectedAddress == null) "+ ADD DELIVERY ADDRESS" else if (isPlacingOrder) "Placing Order..." else "PLACE ORDER 🎉",
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background),
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Saved Address Dropdown / Selector Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.LocationOn, contentDescription = "Address", tint = SooGoodPrimaryGreen)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Delivery Address", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = onAddAddressClick,
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Add New")
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (savedAddresses.isEmpty()) {
                            Text(
                                text = "No Saved Address Available",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.error
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Please add an address to deliver your order.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = onAddAddressClick,
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SooGoodPrimaryGreen)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("+ ADD DELIVERY ADDRESS", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            // Address Dropdown / Selection Chips
                            Text("Select Saved Address:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                savedAddresses.forEach { addr ->
                                    val isSelected = selectedAddress?.id == addr.id
                                    FilterChip(
                                        selected = isSelected,
                                        onClick = {
                                            scope.launch { addressRepository.selectAddress(addr.id) }
                                        },
                                        label = {
                                            Text(
                                                text = "${addr.title} (${addr.receiverName ?: "Address"})",
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            val current = selectedAddress
                            if (current != null) {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Column(modifier = Modifier.padding(12.dp)) {
                                        Text(
                                            text = "${current.title} · ${current.receiverName ?: "Customer"} (+91 ${current.receiverPhone ?: ""})",
                                            style = MaterialTheme.typography.titleSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = current.fullAddress,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Delivery Instructions
            item {
                OutlinedTextField(
                    value = deliveryInstructions,
                    onValueChange = { deliveryInstructions = it },
                    label = { Text("Delivery Instructions (Optional)") },
                    placeholder = { Text("e.g. Leave at door, avoid ringing bell") },
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            // Payment Options Selection
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Payment Method", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Online Payment
                        PaymentOptionRow(
                            title = "Online Payment (Simulated)",
                            subtitle = "UPI, Credit/Debit Card, Netbanking",
                            icon = Icons.Default.CreditCard,
                            isSelected = selectedPaymentMethod == PaymentMethod.ONLINE_SIMULATED,
                            onClick = { selectedPaymentMethod = PaymentMethod.ONLINE_SIMULATED }
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Cash On Delivery
                        PaymentOptionRow(
                            title = "Cash on Delivery (COD)",
                            subtitle = "Pay cash/UPI at doorstep upon delivery",
                            icon = Icons.Default.Money,
                            isSelected = selectedPaymentMethod == PaymentMethod.CASH_ON_DELIVERY,
                            onClick = { selectedPaymentMethod = PaymentMethod.CASH_ON_DELIVERY }
                        )
                    }
                }
            }

            // Order Total Summary Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Order Total Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Items Subtotal")
                            Text("₹${cart.subtotalPaise / 100}")
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Delivery Fee (${cart.distanceKm} km)")
                            Text(if (deliveryFee == 0L) "FREE 🎉" else "₹${deliveryFee / 100}", color = if (deliveryFee == 0L) SooGoodPrimaryGreen else MaterialTheme.colorScheme.onSurface)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Platform Fee")
                            Text("₹${platformFee / 100}")
                        }
                        val packagingFee = cartViewModel.getPackagingFeePaise(cart)
                        val govtGst = cartViewModel.getGovtGstPaise(cart)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Restaurant Packaging Charges (Max ₹35)")
                            Text("₹${packagingFee / 100}")
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Govt GST (5% Food + 18% Delivery)")
                            Text("₹${govtGst / 100}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PaymentOptionRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
        shape = RoundedCornerShape(12.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RadioButton(
                selected = isSelected,
                onClick = onClick,
                colors = RadioButtonDefaults.colors(selectedColor = SooGoodPrimaryGreen)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Icon(imageVector = icon, contentDescription = null, tint = SooGoodPrimaryGreen)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(text = title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                Text(text = subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
