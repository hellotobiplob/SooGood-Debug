package `in`.soogood.customer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.customer.domain.model.User
import `in`.soogood.customer.domain.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AuthViewModel(
    private val authRepository: AuthRepository
) : ViewModel() {

    val currentUser: StateFlow<User?> = authRepository.currentUser

    private val _email = MutableStateFlow("")
    val email: StateFlow<String> = _email.asStateFlow()

    private val _name = MutableStateFlow("")
    val name: StateFlow<String> = _name.asStateFlow()

    private val _mobileNumber = MutableStateFlow("")
    val mobileNumber: StateFlow<String> = _mobileNumber.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _isGoogleAuthPending = MutableStateFlow(false)
    val isGoogleAuthPending: StateFlow<Boolean> = _isGoogleAuthPending.asStateFlow()

    private val _googleIdToken = MutableStateFlow<String?>(null)

    fun updateName(value: String) {
        _name.value = value
        _errorMessage.value = null
    }

    fun updateMobileNumber(value: String) {
        _mobileNumber.value = value
        _errorMessage.value = null
    }

    fun updateCustomerProfile(newName: String, newMobile: String, onSuccess: () -> Unit = {}) {
        viewModelScope.launch {
            _isLoading.value = true
            val result = authRepository.updateProfile(newName.trim(), newMobile.trim())
            _isLoading.value = false
            if (result.isSuccess) {
                _name.value = newName.trim()
                _mobileNumber.value = newMobile.trim()
                onSuccess()
            }
        }
    }

    fun setErrorMessage(msg: String?) {
        _errorMessage.value = msg
    }

    fun handleGoogleAccountSelected(
        googleName: String,
        googleEmail: String,
        idToken: String,
        onAuthSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null

            val result = authRepository.checkAndSignInExistingGoogleUser(idToken)
            _isLoading.value = false

            if (result.isSuccess) {
                val existingUser = result.getOrNull()
                if (existingUser != null && existingUser.mobileNumber.isNotBlank()) {
                    // Existing registered user -> Auto-login directly to Homepage!
                    onAuthSuccess()
                } else {
                    // New user -> Show Complete Your Profile screen
                    _name.value = googleName.ifBlank { googleEmail.substringBefore("@") }
                    _email.value = googleEmail
                    _googleIdToken.value = idToken
                    _isGoogleAuthPending.value = true
                }
            } else {
                val err = result.exceptionOrNull()?.localizedMessage ?: "Google Sign-In failed. Please try again."
                _errorMessage.value = err
            }
        }
    }

    fun onGoogleAccountSelected(googleName: String, googleEmail: String, idToken: String? = null) {
        _name.value = googleName.ifBlank { googleEmail.substringBefore("@") }
        _email.value = googleEmail
        _googleIdToken.value = idToken
        _isGoogleAuthPending.value = true
        _errorMessage.value = null
    }

    fun triggerGoogleSignIn() {
        _errorMessage.value = "Unable to complete Google Sign-In. Please select a valid Google account."
    }

    fun cancelGoogleSignIn() {
        _isGoogleAuthPending.value = false
        _errorMessage.value = null
        _googleIdToken.value = null
    }

    fun completeGoogleSignIn(onSuccess: () -> Unit) {
        val nameInput = _name.value.trim()
        val mobileInput = _mobileNumber.value.trim()

        val indianMobileRegex = Regex("^[6-9]\\d{9}$")
        if (nameInput.isBlank()) {
            _errorMessage.value = "Please enter your name."
            return
        }
        if (!indianMobileRegex.matches(mobileInput)) {
            _errorMessage.value = "Please enter a valid 10-digit Indian mobile number (starting with 6-9)."
            return
        }

        val idToken = _googleIdToken.value

        viewModelScope.launch {
            _isLoading.value = true
            _errorMessage.value = null

            val result = if (!idToken.isNullOrBlank()) {
                authRepository.signInWithGoogle(idToken, nameInput, mobileInput)
            } else {
                authRepository.signUpWithEmail(_email.value, "google_oauth_secure", nameInput, mobileInput)
            }

            _isLoading.value = false

            if (result.isSuccess) {
                onSuccess()
            } else {
                val err = result.exceptionOrNull()?.localizedMessage ?: "Google Sign-In failed. Please try again."
                _errorMessage.value = err
            }
        }
    }

    fun logout() {
        viewModelScope.launch {
            authRepository.logout()
            _email.value = ""
            _name.value = ""
            _mobileNumber.value = ""
            _errorMessage.value = null
            _isGoogleAuthPending.value = false
        }
    }
}
