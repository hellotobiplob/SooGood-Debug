package `in`.soogood.customer.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.customer.data.repository.SupabaseOrderRepository
import `in`.soogood.customer.domain.model.Address
import `in`.soogood.customer.domain.model.CartType
import `in`.soogood.customer.domain.model.Order
import `in`.soogood.customer.domain.model.OrderStatus
import `in`.soogood.customer.domain.model.PaymentMethod
import `in`.soogood.customer.domain.repository.AddressRepository
import `in`.soogood.customer.domain.repository.CartRepository
import `in`.soogood.customer.domain.repository.OrderRepository
import `in`.soogood.customer.domain.usecase.DeliveryFeeCalculator
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

import `in`.soogood.customer.data.repository.FirebaseRealtimeRepository
import `in`.soogood.customer.data.repository.LiveOrderState

class OrderViewModel(
    private val orderRepository: OrderRepository,
    private val cartRepository: CartRepository,
    private val addressRepository: AddressRepository,
    private val firebaseRealtimeRepository: FirebaseRealtimeRepository = FirebaseRealtimeRepository()
) : ViewModel() {

    val orders: StateFlow<List<Order>> = orderRepository.orders

    private val _currentOrder = MutableStateFlow<Order?>(null)
    val currentOrder: StateFlow<Order?> = _currentOrder.asStateFlow()

    private val _isPlacingOrder = MutableStateFlow(false)
    val isPlacingOrder: StateFlow<Boolean> = _isPlacingOrder.asStateFlow()

    private var trackingJob: Job? = null
    private var firebaseJob: Job? = null

    fun loadOrderDetails(orderId: String) {
        trackingJob?.cancel()
        firebaseJob?.cancel()

        // Fetch initial database record
        viewModelScope.launch {
            val updated = orderRepository.getOrderById(orderId)
            _currentOrder.value = updated
        }

        // Real-time Firebase RTDB listener for zero-latency status and GPS tracking updates
        firebaseJob = viewModelScope.launch {
            firebaseRealtimeRepository.observeLiveOrder(orderId).collect { liveState ->
                if (liveState != null) {
                    val newStatus = try {
                        OrderStatus.valueOf(liveState.status.uppercase())
                    } catch (_: Exception) {
                        _currentOrder.value?.orderStatus ?: OrderStatus.ORDER_PLACED
                    }

                    _currentOrder.value = _currentOrder.value?.copy(
                        orderStatus = newStatus,
                        driverName = liveState.riderName.takeIf { !it.isNullOrBlank() } ?: _currentOrder.value?.driverName,
                        driverPhone = liveState.riderPhone.takeIf { !it.isNullOrBlank() } ?: _currentOrder.value?.driverPhone,
                        driverLat = liveState.riderLat ?: _currentOrder.value?.driverLat,
                        driverLng = liveState.riderLng ?: _currentOrder.value?.driverLng,
                        estimatedDeliveryMinutes = liveState.estimatedDeliveryMinutes
                    )
                }
            }
        }
    }

    fun fetchPastOrders(customerId: String = "") {
        viewModelScope.launch {
            // Orders are tracked in real-time via Firebase RTDB
        }
    }

    fun placeOrder(
        cartType: CartType,
        paymentMethod: PaymentMethod,
        specialInstructions: String? = null,
        onSuccess: (String) -> Unit
    ) {
        viewModelScope.launch {
            _isPlacingOrder.value = true
            val cart = if (cartType == CartType.FOOD) cartRepository.foodCart.value else cartRepository.hypermartCart.value
            val address = addressRepository.selectedAddress.value ?: Address(
                id = "addr_default",
                title = "Delivery Location",
                fullAddress = "Nazirpur, Nadia, West Bengal - 741165"
            )

            if (cart.isEmpty) {
                _isPlacingOrder.value = false
                return@launch
            }

            val deliveryFee = DeliveryFeeCalculator.calculateFinalFeePaise(cart.distanceKm, cart.subtotalPaise)
            val taxes = (cart.subtotalPaise * 0.05).toLong() + 10_00L
            val total = cart.subtotalPaise + deliveryFee + taxes

            val newOrder = Order(
                id = "ORD-${System.currentTimeMillis().toString().takeLast(8)}",
                cartType = cartType,
                merchantId = cart.merchantId ?: "merchant_01",
                merchantName = cart.merchantName ?: "SooGood Fulfillment Store",
                items = cart.items,
                subtotalPaise = cart.subtotalPaise,
                deliveryFeePaise = deliveryFee,
                taxesAndPackagingPaise = taxes,
                totalAmountPaise = total,
                deliveryAddress = address,
                paymentMethod = paymentMethod,
                orderStatus = OrderStatus.ORDER_PLACED,
                deliveryOtp = (1000..9999).random().toString(),
                createdAtMillis = System.currentTimeMillis()
            )

            val result = orderRepository.placeOrder(newOrder)
            _isPlacingOrder.value = false

            result.getOrNull()?.let { placedOrder ->
                _currentOrder.value = placedOrder
                cartRepository.clearCart(cartType)
                onSuccess(placedOrder.id)
            }
        }
    }

    fun cancelOrder(orderId: String) {
        viewModelScope.launch {
            orderRepository.cancelOrder(orderId)
            val updated = orderRepository.getOrderById(orderId)
            _currentOrder.value = updated
        }
    }
}
