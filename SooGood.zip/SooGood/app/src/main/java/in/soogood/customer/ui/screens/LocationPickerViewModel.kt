package `in`.soogood.customer.ui.screens

import android.app.Application
import android.location.Geocoder
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.maps.model.LatLng
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale

data class Suggestion(
    val placeId: String,
    val primary: String,
    val secondary: String,
    val lat: Double,
    val lng: Double
)

@OptIn(FlowPreview::class, ExperimentalCoroutinesApi::class)
class LocationPickerViewModel(app: Application) : AndroidViewModel(app) {

    private val query = MutableStateFlow("")

    private val _suggestions = MutableStateFlow<List<Suggestion>>(emptyList())
    val suggestions: StateFlow<List<Suggestion>> = _suggestions

    private val _error = MutableStateFlow<String?>(null)
    val error: StateFlow<String?> = _error

    private val _address = MutableStateFlow("")
    val address: StateFlow<String> = _address

    private val _moveTo = MutableStateFlow<LatLng?>(null)
    val moveTo: StateFlow<LatLng?> = _moveTo

    init {
        query.debounce(300).distinctUntilChanged().onEach { q ->
            val searchQuery = q.trim()
            if (searchQuery.length < 2) {
                _suggestions.value = emptyList()
                _error.value = null
                return@onEach
            }

            try {
                val results = fetchNominatimSuggestions(searchQuery)
                _suggestions.value = results
                _error.value = if (results.isEmpty()) "No places found for \"$searchQuery\"" else null
            } catch (e: Exception) {
                Log.e("LocationPickerVM", "Free Nominatim search error", e)
                _error.value = "Search failed: ${e.localizedMessage}"
                _suggestions.value = emptyList()
            }
        }.launchIn(viewModelScope)
    }

    fun onQueryChange(q: String) {
        query.value = q
    }

    fun pick(s: Suggestion) {
        _suggestions.value = emptyList()
        _moveTo.value = LatLng(s.lat, s.lng)
        _address.value = "${s.primary}, ${s.secondary}".trimEnd(',', ' ')
    }

    fun clearMoveTo() {
        _moveTo.value = null
    }

    @Suppress("DEPRECATION")
    fun reverseGeocode(p: LatLng) = viewModelScope.launch {
        val text = withContext(Dispatchers.IO) {
            try {
                val sysAddress = Geocoder(getApplication(), Locale.getDefault()).getFromLocation(p.latitude, p.longitude, 1)
                    ?.firstOrNull()?.getAddressLine(0)

                sysAddress ?: fetchNominatimReverseGeocode(p.latitude, p.longitude)
            } catch (_: Exception) {
                fetchNominatimReverseGeocode(p.latitude, p.longitude)
            }
        }
        _address.value = text ?: "%.5f, %.5f, Nazirpur, Nadia".format(p.latitude, p.longitude)
    }

    private suspend fun fetchNominatimSuggestions(searchQuery: String): List<Suggestion> = withContext(Dispatchers.IO) {
        val encodedQuery = URLEncoder.encode("$searchQuery Nazirpur India", "UTF-8")
        val urlString = "https://nominatim.openstreetmap.org/search?q=$encodedQuery&format=json&addressdetails=1&countrycodes=in&limit=8"

        val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("User-Agent", "SooGoodCustomerApp/1.0 (in.soogood.customer)")
            connectTimeout = 5000
            readTimeout = 5000
        }

        try {
            if (conn.responseCode == 200) {
                val jsonString = conn.inputStream.bufferedReader().use { it.readText() }
                val jsonArray = JSONArray(jsonString)
                val list = mutableListOf<Suggestion>()

                for (i in 0 until jsonArray.length()) {
                    val obj = jsonArray.getJSONObject(i)
                    val placeId = obj.optString("place_id", i.toString())
                    val displayName = obj.optString("display_name", searchQuery)
                    val lat = obj.optString("lat", "23.9922").toDoubleOrNull() ?: 23.9922
                    val lon = obj.optString("lon", "88.5833").toDoubleOrNull() ?: 88.5833

                    val parts = displayName.split(",")
                    val primary = parts.firstOrNull()?.trim() ?: searchQuery
                    val secondary = parts.drop(1).take(3).joinToString(", ") { it.trim() }

                    list.add(Suggestion(placeId, primary, secondary, lat, lon))
                }
                list
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.e("LocationPickerVM", "Nominatim fetch error", e)
            emptyList()
        } finally {
            conn.disconnect()
        }
    }

    private suspend fun fetchNominatimReverseGeocode(lat: Double, lon: Double): String? = withContext(Dispatchers.IO) {
        val urlString = "https://nominatim.openstreetmap.org/reverse?lat=$lat&lon=$lon&format=json"
        val conn = (URL(urlString).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            setRequestProperty("User-Agent", "SooGoodCustomerApp/1.0 (in.soogood.customer)")
            connectTimeout = 4000
            readTimeout = 4000
        }

        try {
            if (conn.responseCode == 200) {
                val jsonString = conn.inputStream.bufferedReader().use { it.readText() }
                val obj = JSONObject(jsonString)
                obj.optString("display_name", null)
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}
