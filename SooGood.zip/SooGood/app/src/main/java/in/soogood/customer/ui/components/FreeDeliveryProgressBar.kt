package `in`.soogood.customer.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import `in`.soogood.customer.domain.usecase.DeliveryFeeCalculator
import `in`.soogood.customer.ui.theme.SooGoodPrimaryGreen

@Composable
fun FreeDeliveryProgressBar(
    subtotalPaise: Long,
    modifier: Modifier = Modifier
) {
    val isFree = DeliveryFeeCalculator.qualifiesForFreeDelivery(subtotalPaise)
    val neededPaise = DeliveryFeeCalculator.amountNeededForFreeDelivery(subtotalPaise)
    val progress = (subtotalPaise.toFloat() / 800_00f).coerceIn(0f, 1f)
    val animatedProgress by animateFloatAsState(targetValue = progress, label = "Progress")

    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.primaryContainer,
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isFree) {
                    Text(
                        text = "🎉 You unlocked FREE Delivery!",
                        style = MaterialTheme.typography.labelLarge,
                        color = SooGoodPrimaryGreen,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    val rupeesNeeded = neededPaise / 100
                    Text(
                        text = "Add ₹$rupeesNeeded more to unlock FREE Delivery",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    text = "Subtotal: ₹${subtotalPaise / 100}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onPrimaryContainer
                )
            }

            LinearProgressIndicator(
                progress = { animatedProgress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp)),
                color = SooGoodPrimaryGreen,
                trackColor = MaterialTheme.colorScheme.surface
            )
        }
    }
}
