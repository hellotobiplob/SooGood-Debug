package `in`.soogood.customer.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val SooGoodBrand = Color(0xFF5B3DF5)
val SooGoodBrandDark = Color(0xFF3B22B8)
val SooGoodFood = Color(0xFFFF6B35)      // Food tab accent
val SooGoodMart = Color(0xFF12B886)      // Hypermart tab accent
val SooGoodInk = Color(0xFF14142B)
val SooGoodBackground = Color(0xFFF6F6FB)
val SooGoodTint = Color(0xFFEDEBFF)

// Legacy names so the rest of your code keeps compiling
val SooGoodPrimaryGreen = SooGoodBrand
val SooGoodPrimaryDark = SooGoodBrandDark
val SooGoodOrange = SooGoodFood
val SooGoodYellow = Color(0xFFFFB800)
val SooGoodVegGreen = Color(0xFF0F8A5F)
val SooGoodNonVegRed = Color(0xFFE53935)
