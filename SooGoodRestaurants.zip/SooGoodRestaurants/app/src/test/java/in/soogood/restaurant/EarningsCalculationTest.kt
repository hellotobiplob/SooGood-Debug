package `in`.soogood.restaurant

import `in`.soogood.restaurant.data.model.BarChartPoint
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderItem
import `in`.soogood.restaurant.data.model.OrderStatus
import org.junit.Assert.assertEquals
import org.junit.Test

class EarningsCalculationTest {

    @Test
    fun testTotalRevenueCalculationFromOrders() {
        val orders = listOf(
            Order("#1", "User A", listOf(OrderItem("Biryani", 1, 250)), OrderStatus.DELIVERED),
            Order("#2", "User B", listOf(OrderItem("Naan", 2, 50)), OrderStatus.DELIVERED),
            Order("#3", "User C", listOf(OrderItem("Paneer", 1, 300)), OrderStatus.CANCELLED) // Should be excluded
        )

        val totalDeliveredRevenue = orders
            .filter { it.status == OrderStatus.DELIVERED }
            .sumOf { it.total }

        assertEquals(350, totalDeliveredRevenue)
    }

    @Test
    fun testAverageOrderValueCalculation() {
        val totalRevenue = 4250.0
        val orderCount = 10

        val averageOrderValue = if (orderCount > 0) totalRevenue / orderCount else 0.0

        assertEquals(425.0, averageOrderValue, 0.01)
    }

    @Test
    fun testBarChartPointsTotalSum() {
        val points = listOf(
            BarChartPoint("Mon", 1000.0),
            BarChartPoint("Tue", 1500.0),
            BarChartPoint("Wed", 2000.0)
        )

        val totalSum = points.sumOf { it.amount }

        assertEquals(4500.0, totalSum, 0.01)
    }

    @Test
    fun testPercentageDiscountCalculation() {
        val orderTotal = 500
        val discountPercentage = 20
        val discountAmount = (orderTotal * discountPercentage) / 100
        val finalAmount = orderTotal - discountAmount

        assertEquals(100, discountAmount)
        assertEquals(400, finalAmount)
    }
}
