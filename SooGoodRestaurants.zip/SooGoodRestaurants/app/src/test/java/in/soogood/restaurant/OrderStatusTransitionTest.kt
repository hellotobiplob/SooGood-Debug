package `in`.soogood.restaurant

import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderItem
import `in`.soogood.restaurant.data.model.OrderStatus
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class OrderStatusTransitionTest {

    @Test
    fun testOrderTotalCalculation() {
        val items = listOf(
            OrderItem("Chicken Biryani", 2, 249), // 498
            OrderItem("Raita", 1, 40)             // 40
        )
        val order = Order(
            id = "#1001",
            customerName = "Rahul S.",
            items = items,
            status = OrderStatus.PLACED,
            minsAgo = 1
        )

        assertEquals(538, order.total)
    }

    @Test
    fun testCustomerFirstNameExtraction() {
        val order1 = Order(
            id = "#1001",
            customerName = "Rahul S.",
            items = emptyList(),
            status = OrderStatus.PLACED
        )
        val order2 = Order(
            id = "#1002",
            customerName = "Ananya",
            items = emptyList(),
            status = OrderStatus.PLACED
        )

        assertEquals("Rahul", order1.customerFirstName)
        assertEquals("Ananya", order2.customerFirstName)
    }

    @Test
    fun testValidStatusTransitionsFromPlaced() {
        // PLACED can only go to ACCEPTED or CANCELLED
        val initialStatus = OrderStatus.PLACED

        assertTrue(canTransition(initialStatus, OrderStatus.ACCEPTED))
        assertTrue(canTransition(initialStatus, OrderStatus.CANCELLED))
        assertFalse(canTransition(initialStatus, OrderStatus.PREPARING))
        assertFalse(canTransition(initialStatus, OrderStatus.READY))
        assertFalse(canTransition(initialStatus, OrderStatus.DELIVERED))
    }

    @Test
    fun testValidStatusTransitionsFromAccepted() {
        // ACCEPTED can go to PREPARING or CANCELLED
        val initialStatus = OrderStatus.ACCEPTED

        assertTrue(canTransition(initialStatus, OrderStatus.PREPARING))
        assertTrue(canTransition(initialStatus, OrderStatus.CANCELLED))
        assertFalse(canTransition(initialStatus, OrderStatus.READY))
        assertFalse(canTransition(initialStatus, OrderStatus.DELIVERED))
    }

    @Test
    fun testValidStatusTransitionsFromPreparing() {
        // PREPARING can go to READY or CANCELLED
        val initialStatus = OrderStatus.PREPARING

        assertTrue(canTransition(initialStatus, OrderStatus.READY))
        assertTrue(canTransition(initialStatus, OrderStatus.CANCELLED))
        assertFalse(canTransition(initialStatus, OrderStatus.PLACED))
    }

    @Test
    fun testTerminalStatesCannotTransition() {
        // DELIVERED and CANCELLED are terminal states
        assertFalse(canTransition(OrderStatus.DELIVERED, OrderStatus.ACCEPTED))
        assertFalse(canTransition(OrderStatus.DELIVERED, OrderStatus.CANCELLED))
        assertFalse(canTransition(OrderStatus.CANCELLED, OrderStatus.ACCEPTED))
    }

    private fun canTransition(from: OrderStatus, to: OrderStatus): Boolean {
        if (from == OrderStatus.DELIVERED || from == OrderStatus.CANCELLED) return false
        return when (from) {
            OrderStatus.PLACED -> to == OrderStatus.ACCEPTED || to == OrderStatus.CANCELLED
            OrderStatus.ACCEPTED -> to == OrderStatus.PREPARING || to == OrderStatus.CANCELLED
            OrderStatus.PREPARING -> to == OrderStatus.READY || to == OrderStatus.CANCELLED
            OrderStatus.READY -> to == OrderStatus.RIDER_ASSIGNED || to == OrderStatus.PICKED_UP || to == OrderStatus.DELIVERED || to == OrderStatus.CANCELLED
            OrderStatus.RIDER_ASSIGNED -> to == OrderStatus.PICKED_UP || to == OrderStatus.DELIVERED || to == OrderStatus.CANCELLED
            OrderStatus.PICKED_UP -> to == OrderStatus.DELIVERED || to == OrderStatus.CANCELLED
            else -> false
        }
    }
}
