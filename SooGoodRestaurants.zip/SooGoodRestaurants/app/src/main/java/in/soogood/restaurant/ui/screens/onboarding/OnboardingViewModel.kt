package `in`.soogood.restaurant.ui.screens.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.restaurant.data.model.AuthState
import `in`.soogood.restaurant.data.model.OnboardingData
import `in`.soogood.restaurant.data.repository.AuthRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class OnboardingUiState(
    val data: OnboardingData = OnboardingData(),
    val step: Int = 1, // 1: Details, 2: Documents, 3: Banking & Hours
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val statusMessage: String? = null
)

class OnboardingViewModel(private val authRepository: AuthRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(OnboardingUiState())
    val uiState: StateFlow<OnboardingUiState> = _uiState.asStateFlow()

    fun updateName(value: String) = _uiState.update { it.copy(data = it.data.copy(name = value), errorMessage = null) }
    fun updateOwnerName(value: String) = _uiState.update { it.copy(data = it.data.copy(ownerName = value), errorMessage = null) }
    fun updatePhone(value: String) = _uiState.update { it.copy(data = it.data.copy(phone = value), errorMessage = null) }
    fun updateEmail(value: String) = _uiState.update { it.copy(data = it.data.copy(email = value), errorMessage = null) }
    fun updateAddress(value: String) = _uiState.update { it.copy(data = it.data.copy(address = value), errorMessage = null) }
    fun updateCuisine(value: String) = _uiState.update { it.copy(data = it.data.copy(cuisine = value), errorMessage = null) }

    fun updateFssai(value: String) = _uiState.update { it.copy(data = it.data.copy(fssai = value), errorMessage = null) }
    fun updateGst(value: String) = _uiState.update { it.copy(data = it.data.copy(gst = value), errorMessage = null) }

    fun updateBankAccount(value: String) = _uiState.update { it.copy(data = it.data.copy(bankAccount = value), errorMessage = null) }
    fun updateIfsc(value: String) = _uiState.update { it.copy(data = it.data.copy(ifsc = value), errorMessage = null) }
    fun updateOpeningTime(value: String) = _uiState.update { it.copy(data = it.data.copy(openingTime = value), errorMessage = null) }
    fun updateClosingTime(value: String) = _uiState.update { it.copy(data = it.data.copy(closingTime = value), errorMessage = null) }

    fun nextStep() {
        val current = _uiState.value
        when (current.step) {
            1 -> {
                if (current.data.name.isBlank() || current.data.ownerName.isBlank() || current.data.phone.isBlank()) {
                    _uiState.update { it.copy(errorMessage = "Please fill in restaurant name, owner name and phone number.") }
                    return
                }
                _uiState.update { it.copy(step = 2, errorMessage = null) }
            }
            2 -> {
                if (current.data.fssai.isBlank()) {
                    _uiState.update { it.copy(errorMessage = "FSSAI License number is required.") }
                    return
                }
                _uiState.update { it.copy(step = 3, errorMessage = null) }
            }
        }
    }

    fun previousStep() {
        _uiState.update {
            if (it.step > 1) it.copy(step = it.step - 1, errorMessage = null) else it
        }
    }

    fun submitOnboarding(onSubmitted: () -> Unit) {
        val state = _uiState.value
        if (state.data.bankAccount.isBlank() || state.data.ifsc.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Bank account number and IFSC code are required.") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            val success = authRepository.submitOnboarding(state.data)
            if (success) {
                _uiState.update { it.copy(isLoading = false) }
                onSubmitted()
            } else {
                _uiState.update { it.copy(isLoading = false, errorMessage = "Failed to submit. Please try again.") }
            }
        }
    }

    fun checkStatus(onApproved: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, statusMessage = null) }
            val authState = authRepository.checkApprovalStatus()
            _uiState.update { it.copy(isLoading = false) }
            if (authState is AuthState.Authenticated) {
                onApproved()
            } else {
                _uiState.update {
                    it.copy(statusMessage = "Status Checked: Registration is still PENDING admin approval.")
                }
            }
        }
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            onLoggedOut()
        }
    }
}
