package `in`.soogood.restaurant.data.model

/**
 * Enum representing order state.
 * Shared across Customer, Rider, Admin, and Restaurant apps.
 * DO NOT change existing values.
 */
enum class OrderStatus(val displayLabel: String) {
    PLACED("New Order"),
    ACCEPTED("Accepted"),
    PREPARING("In Kitchen"),
    READY("Ready for Pickup"),
    RIDER_ASSIGNED("Rider Assigned"),
    PICKED_UP("Picked Up"),
    DELIVERED("Delivered"),
    CANCELLED("Cancelled")
}

data class OrderItem(
    val name: String,
    val qty: Int,
    val price: Int
)

data class Order(
    val id: String,
    val customerName: String,
    val items: List<OrderItem>,
    val status: OrderStatus,
    val minsAgo: Int = 0,
    val placedTimestamp: Long = System.currentTimeMillis() - (minsAgo * 60 * 1000L),
    val note: String? = null,
    val paymentType: String = "Online", // "COD" or "Online"
    val deliveryAddressSnippet: String = "Indiranagar, Stage 2",
    val prepTimeAdjustMins: Int = 0,
    val rejectionReason: String? = null,
    val isMissed: Boolean = false
) {
    val total: Int
        get() = items.sumOf { it.qty * it.price }

    val customerFirstName: String
        get() = customerName.split(" ").firstOrNull() ?: customerName
}

data class AddOn(
    val name: String,
    val price: Int
)

data class MenuItem(
    val id: String,
    val name: String,
    val category: String,
    val price: Int,
    val veg: Boolean,
    val inStock: Boolean,
    val description: String = "",
    val prepTimeMins: Int = 20,
    val quantityValue: String = "",
    val quantityUnit: String = "",
    val photoUrl: String? = null,
    val addOns: List<AddOn> = emptyList()
) {
    val displayPortion: String
        get() = if (quantityValue.isNotBlank() && quantityUnit.isNotBlank()) {
            "$quantityValue $quantityUnit"
        } else if (quantityUnit.isNotBlank()) {
            quantityUnit
        } else ""
}

enum class EarningsPeriod {
    TODAY, THIS_WEEK, THIS_MONTH
}

data class BarChartPoint(
    val label: String,
    val amount: Double
)

data class Payout(
    val id: String,
    val date: String,
    val amount: Int,
    val status: String, // "Settled", "Processing"
    val bankAccountSnippet: String
)

data class Review(
    val id: String,
    val customerName: String,
    val rating: Int, // 1 to 5
    val date: String,
    val comment: String,
    val itemNames: String,
    val reply: String? = null
)

data class Offer(
    val id: String,
    val code: String,
    val title: String,
    val discountType: String, // "PERCENTAGE" or "FLAT"
    val discountValue: Int,
    val minOrderValue: Int,
    val validUntil: String,
    val isActive: Boolean = true
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val isRead: Boolean = false,
    val type: String = "ORDER" // "ORDER", "PAYOUT", "SYSTEM"
)

data class WeeklyTiming(
    val day: String,
    val openTime: String,
    val closeTime: String,
    val isOpen: Boolean = true
)

data class User(
    val id: String,
    val name: String,
    val phone: String,
    val email: String,
    val restaurantId: String,
    val restaurantName: String
)

data class RestaurantInfo(
    val id: String = "rest_001",
    val parentStoreId: String? = null,
    val name: String,
    val ownerName: String,
    val phone: String,
    val email: String,
    val address: String,
    val cuisine: String,
    val fssai: String,
    val gst: String? = null,
    val bankAccount: String,
    val ifsc: String,
    val openingTime: String,
    val closingTime: String,
    val imageUrl: String? = null,
    val status: String = "PENDING" // PENDING, APPROVED, REJECTED
)

data class OnboardingData(
    val name: String = "",
    val ownerName: String = "",
    val phone: String = "",
    val email: String = "",
    val address: String = "",
    val cuisine: String = "",
    val fssai: String = "",
    val gst: String = "",
    val bankAccount: String = "",
    val ifsc: String = "",
    val openingTime: String = "10:00 AM",
    val closingTime: String = "11:00 PM"
)

sealed interface AuthState {
    object Unauthenticated : AuthState
    data class Authenticated(val user: User) : AuthState
    data class PendingApproval(val restaurantInfo: RestaurantInfo) : AuthState
}
