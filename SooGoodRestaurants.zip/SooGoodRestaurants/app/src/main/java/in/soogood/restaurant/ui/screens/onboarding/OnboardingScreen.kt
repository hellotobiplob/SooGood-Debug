package `in`.soogood.restaurant.ui.screens.onboarding

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.R
import `in`.soogood.restaurant.ui.components.SooGoodOutlinedButton
import `in`.soogood.restaurant.ui.components.SooGoodPrimaryButton
import `in`.soogood.restaurant.ui.components.SooGoodTextField
import `in`.soogood.restaurant.ui.theme.SooGoodBrand

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OnboardingScreen(
    viewModel: OnboardingViewModel,
    onSubmitted: () -> Unit,
    onBackToLogin: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        stringResource(R.string.onboarding_title),
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = {
                            if (state.step > 1) viewModel.previousStep() else onBackToLogin()
                        }
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = stringResource(R.string.onboarding_back),
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SooGoodBrand),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            LinearProgressIndicator(
                progress = { state.step / 3f },
                modifier = Modifier.fillMaxWidth(),
                color = SooGoodBrand,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StepIndicatorItem("1. Details", active = state.step >= 1)
                StepIndicatorItem("2. Docs", active = state.step >= 2)
                StepIndicatorItem("3. Bank & Hours", active = state.step >= 3)
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                if (state.errorMessage != null) {
                    Text(
                        text = state.errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                                RoundedCornerShape(12.dp)
                            )
                            .padding(12.dp)
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                }

                AnimatedContent(
                    targetState = state.step,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "OnboardingStep"
                ) { step ->
                    when (step) {
                        1 -> StepOneForm(viewModel, state)
                        2 -> StepTwoForm(viewModel, state)
                        else -> StepThreeForm(viewModel, state)
                    }
                }

                Spacer(modifier = Modifier.height(28.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    if (state.step > 1) {
                        SooGoodOutlinedButton(
                            text = stringResource(R.string.onboarding_back),
                            onClick = { viewModel.previousStep() },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    if (state.step < 3) {
                        SooGoodPrimaryButton(
                            text = stringResource(R.string.onboarding_next),
                            onClick = { viewModel.nextStep() },
                            modifier = Modifier.weight(1f)
                        )
                    } else {
                        SooGoodPrimaryButton(
                            text = stringResource(R.string.onboarding_submit),
                            onClick = { viewModel.submitOnboarding(onSubmitted) },
                            isLoading = state.isLoading,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StepIndicatorItem(label: String, active: Boolean) {
    Text(
        text = label,
        fontSize = 12.sp,
        fontWeight = if (active) FontWeight.Bold else FontWeight.Normal,
        color = if (active) SooGoodBrand else MaterialTheme.colorScheme.onSurfaceVariant
    )
}

@Composable
private fun StepOneForm(viewModel: OnboardingViewModel, state: OnboardingUiState) {
    Column {
        Text("Restaurant Details", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))

        SooGoodTextField(
            value = state.data.name,
            onValueChange = { viewModel.updateName(it) },
            label = stringResource(R.string.onboarding_restaurant_name),
            placeholder = "e.g. Biryani House",
            leadingIcon = { Icon(Icons.Default.Restaurant, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(12.dp))

        SooGoodTextField(
            value = state.data.ownerName,
            onValueChange = { viewModel.updateOwnerName(it) },
            label = stringResource(R.string.onboarding_owner_name),
            placeholder = "e.g. Rajesh Kumar",
            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(12.dp))

        SooGoodTextField(
            value = state.data.phone,
            onValueChange = { viewModel.updatePhone(it) },
            label = stringResource(R.string.onboarding_owner_phone),
            placeholder = "e.g. 9876543210",
            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(12.dp))

        SooGoodTextField(
            value = state.data.email,
            onValueChange = { viewModel.updateEmail(it) },
            label = stringResource(R.string.onboarding_owner_email),
            placeholder = "owner@restaurant.com",
            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(12.dp))

        SooGoodTextField(
            value = state.data.address,
            onValueChange = { viewModel.updateAddress(it) },
            label = stringResource(R.string.onboarding_address),
            placeholder = "Street, Area, Bengaluru",
            leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null, tint = SooGoodBrand) },
            singleLine = false
        )
        Spacer(modifier = Modifier.height(12.dp))

        SooGoodTextField(
            value = state.data.cuisine,
            onValueChange = { viewModel.updateCuisine(it) },
            label = stringResource(R.string.onboarding_cuisine),
            placeholder = "Biryani, North Indian",
            leadingIcon = { Icon(Icons.Default.Restaurant, contentDescription = null, tint = SooGoodBrand) }
        )
    }
}

@Composable
private fun StepTwoForm(viewModel: OnboardingViewModel, state: OnboardingUiState) {
    Column {
        Text("Legal & Documents", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))

        SooGoodTextField(
            value = state.data.fssai,
            onValueChange = { viewModel.updateFssai(it) },
            label = stringResource(R.string.onboarding_fssai),
            placeholder = "14-digit FSSAI Number",
            leadingIcon = { Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(16.dp))

        SooGoodTextField(
            value = state.data.gst,
            onValueChange = { viewModel.updateGst(it) },
            label = stringResource(R.string.onboarding_gst),
            placeholder = "GSTIN Number (Optional)",
            leadingIcon = { Icon(Icons.Default.Badge, contentDescription = null, tint = SooGoodBrand) }
        )
    }
}

@Composable
private fun StepThreeForm(viewModel: OnboardingViewModel, state: OnboardingUiState) {
    Column {
        Text("Banking & Operating Hours", fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Spacer(modifier = Modifier.height(16.dp))

        SooGoodTextField(
            value = state.data.bankAccount,
            onValueChange = { viewModel.updateBankAccount(it) },
            label = stringResource(R.string.onboarding_bank_account),
            placeholder = "Account Number",
            leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(12.dp))

        SooGoodTextField(
            value = state.data.ifsc,
            onValueChange = { viewModel.updateIfsc(it) },
            label = stringResource(R.string.onboarding_ifsc),
            placeholder = "e.g. SBIN0001234",
            leadingIcon = { Icon(Icons.Default.AccountBalance, contentDescription = null, tint = SooGoodBrand) }
        )
        Spacer(modifier = Modifier.height(12.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                SooGoodTextField(
                    value = state.data.openingTime,
                    onValueChange = { viewModel.updateOpeningTime(it) },
                    label = stringResource(R.string.onboarding_opening_time),
                    placeholder = "10:00 AM",
                    leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null, tint = SooGoodBrand) }
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                SooGoodTextField(
                    value = state.data.closingTime,
                    onValueChange = { viewModel.updateClosingTime(it) },
                    label = stringResource(R.string.onboarding_closing_time),
                    placeholder = "11:00 PM",
                    leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null, tint = SooGoodBrand) }
                )
            }
        }
    }
}
