package `in`.soogood.restaurant.ui.screens.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.restaurant.data.repository.AuthRepository
import `in`.soogood.restaurant.data.repository.LoginResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class LoginUiState(
    val loginId: String = "",
    val password: String = "",
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoMessage: String? = null
)

class LoginViewModel(private val authRepository: AuthRepository) : ViewModel() {
    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState: StateFlow<LoginUiState> = _uiState.asStateFlow()

    fun onLoginIdChange(loginId: String) {
        _uiState.update { it.copy(loginId = loginId, errorMessage = null) }
    }

    fun onPasswordChange(password: String) {
        _uiState.update { it.copy(password = password, errorMessage = null) }
    }

    fun login(onSuccess: () -> Unit, onPendingApproval: () -> Unit) {
        val state = _uiState.value
        if (state.loginId.isBlank() || state.password.isBlank()) {
            _uiState.update { it.copy(errorMessage = "Invalid login ID or password") }
            return
        }

        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            when (val result = authRepository.loginWithLoginId(state.loginId, state.password)) {
                is LoginResult.Success -> {
                    _uiState.update { it.copy(isLoading = false) }
                    onSuccess()
                }
                is LoginResult.PendingApproval -> {
                    _uiState.update { it.copy(isLoading = false) }
                    onPendingApproval()
                }
                is LoginResult.NotFound -> {
                    _uiState.update {
                        it.copy(isLoading = false, errorMessage = result.message)
                    }
                }
                is LoginResult.Rejected -> {
                    _uiState.update {
                        it.copy(isLoading = false, errorMessage = result.message)
                    }
                }
                is LoginResult.Error -> {
                    _uiState.update {
                        it.copy(isLoading = false, errorMessage = result.message)
                    }
                }
            }
        }
    }

    fun loginAsDemo(onSuccess: () -> Unit) {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoading = true, errorMessage = null) }
            authRepository.loginDemoUser()
            _uiState.update { it.copy(isLoading = false) }
            onSuccess()
        }
    }
}
