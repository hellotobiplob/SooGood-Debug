package `in`.soogood.restaurant.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import `in`.soogood.restaurant.di.AppContainer
import `in`.soogood.restaurant.ui.screens.auth.LoginScreen
import `in`.soogood.restaurant.ui.screens.auth.LoginViewModel
import `in`.soogood.restaurant.ui.screens.main.MainShellScreen
import `in`.soogood.restaurant.ui.screens.main.RestaurantViewModel
import `in`.soogood.restaurant.ui.screens.notifications.NotificationsScreen
import `in`.soogood.restaurant.ui.screens.offers.OffersScreen
import `in`.soogood.restaurant.ui.screens.onboarding.OnboardingScreen
import `in`.soogood.restaurant.ui.screens.onboarding.OnboardingViewModel
import `in`.soogood.restaurant.ui.screens.onboarding.PendingApprovalScreen
import `in`.soogood.restaurant.ui.screens.orders.OrderDetailsScreen
import `in`.soogood.restaurant.ui.screens.reviews.ReviewsScreen
import `in`.soogood.restaurant.ui.screens.splash.SplashScreen

@Composable
fun SooGoodNavGraph(
    navController: NavHostController,
    appContainer: AppContainer
) {
    val loginViewModel = remember { LoginViewModel(appContainer.authRepository) }
    val onboardingViewModel = remember { OnboardingViewModel(appContainer.authRepository) }
    val restaurantViewModel = remember { RestaurantViewModel(appContainer.restaurantRepository) }

    NavHost(
        navController = navController,
        startDestination = Screen.Splash.route
    ) {
        composable(Screen.Splash.route) {
            SplashScreen(
                authRepository = appContainer.authRepository,
                onNavigate = { route ->
                    navController.navigate(route) {
                        popUpTo(Screen.Splash.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.Login.route) {
            LoginScreen(
                viewModel = loginViewModel,
                onLoginSuccess = {
                    navController.navigate(Screen.MainShell.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onPendingApproval = {
                    navController.navigate(Screen.PendingApproval.route) {
                        popUpTo(Screen.Login.route) { inclusive = true }
                    }
                },
                onNavigateToRegister = {
                    navController.navigate(Screen.Onboarding.route)
                }
            )
        }

        composable(Screen.Onboarding.route) {
            OnboardingScreen(
                viewModel = onboardingViewModel,
                onSubmitted = {
                    navController.navigate(Screen.PendingApproval.route) {
                        popUpTo(Screen.Onboarding.route) { inclusive = true }
                    }
                },
                onBackToLogin = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.PendingApproval.route) {
            PendingApprovalScreen(
                viewModel = onboardingViewModel,
                onApproved = {
                    navController.navigate(Screen.MainShell.route) {
                        popUpTo(Screen.PendingApproval.route) { inclusive = true }
                    }
                },
                onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.PendingApproval.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.MainShell.route) {
            MainShellScreen(
                viewModel = restaurantViewModel,
                onOrderClick = { orderId ->
                    navController.navigate(Screen.OrderDetails.createRoute(orderId))
                },
                onNavigateToReviews = {
                    navController.navigate(Screen.Reviews.route)
                },
                onNavigateToOffers = {
                    navController.navigate(Screen.Offers.route)
                },
                onNavigateToNotifications = {
                    navController.navigate(Screen.Notifications.route)
                },
                onLogout = {
                    navController.navigate(Screen.Login.route) {
                        popUpTo(Screen.MainShell.route) { inclusive = true }
                    }
                }
            )
        }

        composable(Screen.OrderDetails.route) { backStackEntry ->
            val orderId = backStackEntry.arguments?.getString("orderId") ?: ""
            OrderDetailsScreen(
                orderId = orderId,
                viewModel = restaurantViewModel,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.Reviews.route) {
            ReviewsScreen(
                viewModel = restaurantViewModel,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.Offers.route) {
            OffersScreen(
                viewModel = restaurantViewModel,
                onBack = {
                    navController.popBackStack()
                }
            )
        }

        composable(Screen.Notifications.route) {
            NotificationsScreen(
                viewModel = restaurantViewModel,
                onBack = {
                    navController.popBackStack()
                }
            )
        }
    }
}
