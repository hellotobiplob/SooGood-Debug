package `in`.soogood.restaurant.data.repository

import `in`.soogood.restaurant.data.model.AuthState
import `in`.soogood.restaurant.data.model.OnboardingData
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.User
import kotlinx.coroutines.flow.StateFlow

sealed interface LoginResult {
    data class Success(val user: User) : LoginResult
    data class PendingApproval(val restaurantInfo: RestaurantInfo) : LoginResult
    data class Rejected(val message: String = "Your restaurant registration was rejected by admin. Please contact support.") : LoginResult
    data class NotFound(val message: String = "No restaurant found registered with these details. Please register first.") : LoginResult
    data class Error(val message: String) : LoginResult
}

interface AuthRepository {
    val authState: StateFlow<AuthState>
    val ownedStores: StateFlow<List<RestaurantInfo>>
    suspend fun sendOtp(phone: String): Boolean
    suspend fun loginWithOtp(phone: String, otp: String): LoginResult
    suspend fun loginWithEmail(email: String, password: String): LoginResult
    suspend fun loginWithLoginId(loginId: String, password: String): LoginResult
    suspend fun loginDemoUser(): LoginResult
    suspend fun submitOnboarding(data: OnboardingData): Boolean
    suspend fun checkApprovalStatus(): AuthState
    suspend fun logout()
}
