package `in`.soogood.restaurant.data.repository

import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.data.model.NotificationItem
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderItem
import `in`.soogood.restaurant.data.model.OrderStatus
import `in`.soogood.restaurant.data.model.Payout
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.Review
import `in`.soogood.restaurant.data.model.WeeklyTiming
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlin.random.Random

class FirebaseRestaurantRepository(
    private val defaultStoreId: String = "37c623c9-8459-457c-9605-2af3c097141a"
) : RestaurantRepository {

    private val database = FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com")
    
    private val _currentStore = MutableStateFlow<RestaurantInfo?>(
        RestaurantInfo(
            id = defaultStoreId,
            name = "Bake N Bite (Firebase)",
            ownerName = "Partner Owner",
            email = "partner@soogood.in",
            phone = "9091938712",
            cuisine = "Bakery & Sweets",
            address = "Nazirpur, Nadia",
            fssai = "12345678901234",
            bankAccount = "1234567890",
            ifsc = "SBIN0001234",
            openingTime = "10:00 AM",
            closingTime = "11:00 PM"
        )
    )
    override val currentStore: StateFlow<RestaurantInfo?> = _currentStore.asStateFlow()

    private val _restaurantName = MutableStateFlow("Bake N Bite")
    override val restaurantName: StateFlow<String> = _restaurantName.asStateFlow()

    private val _open = MutableStateFlow(true)
    override val isOpen: StateFlow<Boolean> = _open.asStateFlow()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    override val orders: StateFlow<List<Order>> = _orders.asStateFlow()

    private val _menu = MutableStateFlow<List<MenuItem>>(emptyList())
    override val menu: StateFlow<List<MenuItem>> = _menu.asStateFlow()

    private val _newOrderAlertFlow = MutableSharedFlow<Order>()
    override val newOrderAlertFlow: SharedFlow<Order> = _newOrderAlertFlow.asSharedFlow()

    private val _payouts = MutableStateFlow<List<Payout>>(emptyList())
    override val payouts: StateFlow<List<Payout>> = _payouts.asStateFlow()

    private val _reviews = MutableStateFlow<List<Review>>(emptyList())
    override val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()

    private val _offers = MutableStateFlow<List<Offer>>(emptyList())
    override val offers: StateFlow<List<Offer>> = _offers.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    override val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _weeklyTimings = MutableStateFlow<List<WeeklyTiming>>(emptyList())
    override val weeklyTimings: StateFlow<List<WeeklyTiming>> = _weeklyTimings.asStateFlow()

    private val firebaseRealtimeRepository = FirebaseRealtimeRepository()

    init {
        listenToFirebaseData()
    }

    private fun listenToFirebaseData() {
        database.getReference("orders").addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Order>()
                for (child in snapshot.children) {
                    try {
                        val id = child.child("id").getValue(String::class.java) ?: child.key ?: ""
                        val customerName = child.child("customerName").getValue(String::class.java) ?: child.child("customer_name").getValue(String::class.java) ?: "Customer"
                        val statusStr = child.child("status").getValue(String::class.java) ?: "PLACED"
                        val status = try { OrderStatus.valueOf(statusStr.uppercase()) } catch (_: Exception) { OrderStatus.PLACED }
                        
                        list.add(
                            Order(
                                id = id,
                                customerName = customerName,
                                items = listOf(OrderItem("Special Item", 1, 399)),
                                status = status,
                                deliveryAddressSnippet = "Nazirpur, Nadia",
                                paymentType = "Online"
                            )
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing order", e)
                    }
                }
                _orders.value = list.sortedByDescending { it.id }
            }
            override fun onCancelled(error: DatabaseError) {}
        })

        database.getReference("restaurant_menu").child(defaultStoreId).addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<MenuItem>()
                for (child in snapshot.children) {
                    try {
                        val id = child.child("id").getValue(String::class.java) ?: child.key ?: ""
                        val name = child.child("name").getValue(String::class.java) ?: "Item"
                        val price = child.child("price").getValue(Long::class.java)?.toInt() ?: (child.child("price").getValue(Double::class.java)?.toInt() ?: 100)
                        val category = child.child("category").getValue(String::class.java) ?: "General"
                        val inStock = child.child("inStock").getValue(Boolean::class.java) ?: child.child("is_available").getValue(Boolean::class.java) ?: true
                        val isVeg = child.child("veg").getValue(Boolean::class.java) ?: child.child("is_veg").getValue(Boolean::class.java) ?: true

                        list.add(
                            MenuItem(
                                id = id,
                                name = name,
                                price = price,
                                category = category,
                                inStock = inStock,
                                veg = isVeg
                            )
                        )
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing menu item", e)
                    }
                }
                _menu.value = list
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    override suspend fun updateOrderStatus(orderId: String, status: OrderStatus) {
        _orders.update { list -> list.map { if (it.id == orderId) it.copy(status = status) else it } }
        database.getReference("orders").child(orderId).child("status").setValue(status.name)
        firebaseRealtimeRepository.broadcastStatusUpdate(orderId, status.name)
    }

    override suspend fun rejectOrder(orderId: String, reason: String) {
        _orders.update { list -> list.map { if (it.id == orderId) it.copy(status = OrderStatus.CANCELLED, rejectionReason = reason) else it } }
        database.getReference("orders").child(orderId).child("status").setValue(OrderStatus.CANCELLED.name)
        database.getReference("orders").child(orderId).child("rejectionReason").setValue(reason)
        firebaseRealtimeRepository.broadcastStatusUpdate(orderId, OrderStatus.CANCELLED.name, rejectionReason = reason)
    }

    override suspend fun adjustPrepTime(orderId: String, addMinutes: Int) {
        _orders.update { list ->
            list.map { if (it.id == orderId) it.copy(prepTimeAdjustMins = maxOf(0, it.prepTimeAdjustMins + addMinutes)) else it }
        }
    }

    override suspend fun markOrderAsMissed(orderId: String) {
        rejectOrder(orderId, "Missed acceptance window")
    }

    override suspend fun setItemStock(itemId: String, inStock: Boolean) {
        _menu.update { list -> list.map { if (it.id == itemId) it.copy(inStock = inStock) else it } }
        database.getReference("restaurant_menu").child(defaultStoreId).child(itemId).child("inStock").setValue(inStock)
    }

    override suspend fun setOpen(open: Boolean) {
        _open.value = open
        database.getReference("restaurants").child(defaultStoreId).child("is_open").setValue(open)
    }

    override suspend fun addMenuItem(item: MenuItem) {
        _menu.update { it + item }
        database.getReference("restaurant_menu").child(defaultStoreId).child(item.id).setValue(item)
    }

    override suspend fun editMenuItem(item: MenuItem) {
        _menu.update { list -> list.map { if (it.id == item.id) item else it } }
        database.getReference("restaurant_menu").child(defaultStoreId).child(item.id).setValue(item)
    }

    override suspend fun deleteMenuItem(itemId: String) {
        _menu.update { list -> list.filterNot { it.id == itemId } }
        database.getReference("restaurant_menu").child(defaultStoreId).child(itemId).removeValue()
    }

    override suspend fun setCategoryStock(category: String, inStock: Boolean) {
        _menu.update { list -> list.map { if (it.category == category) it.copy(inStock = inStock) else it } }
    }

    override suspend fun setAllOutOfStockToday() {
        _menu.update { list -> list.map { it.copy(inStock = false) } }
    }

    override suspend fun replyToReview(reviewId: String, replyText: String) {}
    override suspend fun addOffer(offer: Offer) {}
    override suspend fun toggleOfferActive(offerId: String, isActive: Boolean) {}
    override suspend fun markNotificationRead(id: String) {}
    override suspend fun markAllNotificationsRead() {}
    override suspend fun updateWeeklyTiming(day: String, openTime: String, closeTime: String, isOpen: Boolean) {}
    override suspend fun updateRestaurantImage(imageUrl: String) {
        _currentStore.update { it?.copy(imageUrl = imageUrl) }
    }
    override suspend fun switchActiveStore(storeId: String) {}

    override suspend fun simulateIncomingOrder(): Order {
        val orderNum = Random.nextInt(3001, 3999)
        val newOrder = Order(
            id = "ORD_$orderNum",
            customerName = "Test Customer #$orderNum",
            items = listOf(OrderItem("Special Biryani", 1, 350)),
            status = OrderStatus.PLACED,
            deliveryAddressSnippet = "Nazirpur, Nadia",
            paymentType = "Online"
        )
        database.getReference("orders").child(newOrder.id).setValue(newOrder)
        _orders.update { listOf(newOrder) + it }
        _newOrderAlertFlow.emit(newOrder)
        return newOrder
    }

    override suspend fun refreshData() {}

    companion object {
        private const val TAG = "FirebaseRestaurantRepo"
    }
}
