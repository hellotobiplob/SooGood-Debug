package `in`.soogood.restaurant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun StatCard(
    label: String,
    value: String,
    modifier: Modifier = Modifier,
    containerColor: Color = Color.White.copy(alpha = 0.16f),
    contentColor: Color = Color.White
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(containerColor)
            .padding(14.dp)
    ) {
        Text(
            text = value,
            color = contentColor,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 20.sp
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = label,
            color = contentColor.copy(alpha = 0.85f),
            fontWeight = FontWeight.Medium,
            fontSize = 12.sp
        )
    }
}
