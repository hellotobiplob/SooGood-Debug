package `in`.soogood.restaurant.ui.theme

import androidx.compose.ui.graphics.Color

val SooGoodBrand = Color(0xFF5B3DF5)
val SooGoodBrandDark = Color(0xFF3B22B8)
val SooGoodBrandLight = Color(0xFF7B62F7)
val SooGoodFood = Color(0xFFFF6B35)
val SooGoodMart = Color(0xFF12B886)

val BackgroundLight = Color(0xFFF6F6FB)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFEDEDF5)
val OnBackgroundLight = Color(0xFF181824)
val OnSurfaceLight = Color(0xFF181824)
val OnSurfaceVariantLight = Color(0xFF6B6B80)
val OutlineLight = Color(0xFFE0E0EC)

val BackgroundDark = Color(0xFF12121A)
val SurfaceDark = Color(0xFF1C1C26)
val SurfaceVariantDark = Color(0xFF282838)
val OnBackgroundDark = Color(0xFFE8E8F2)
val OnSurfaceDark = Color(0xFFE8E8F2)
val OnSurfaceVariantDark = Color(0xFFA0A0B8)
val OutlineDark = Color(0xFF323246)

val NonVegRed = Color(0xFFE53935)
val VegGreen = Color(0xFF12B886)
val WarningOrange = Color(0xFFFF9800)
val InfoBlue = Color(0xFF2196F3)
