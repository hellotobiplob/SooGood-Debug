package `in`.soogood.restaurant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.data.model.OrderStatus
import `in`.soogood.restaurant.ui.theme.NonVegRed
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.SooGoodFood
import `in`.soogood.restaurant.ui.theme.SooGoodMart

@Composable
fun StatusChip(
    status: OrderStatus,
    modifier: Modifier = Modifier
) {
    val (bgColor, textColor) = when (status) {
        OrderStatus.PLACED -> SooGoodFood.copy(alpha = 0.15f) to SooGoodFood
        OrderStatus.ACCEPTED -> SooGoodBrand.copy(alpha = 0.15f) to SooGoodBrand
        OrderStatus.PREPARING -> Color(0xFFFF9800).copy(alpha = 0.15f) to Color(0xFFE65100)
        OrderStatus.READY -> SooGoodMart.copy(alpha = 0.15f) to SooGoodMart
        OrderStatus.RIDER_ASSIGNED -> Color(0xFF2196F3).copy(alpha = 0.15f) to Color(0xFF0D47A1)
        OrderStatus.PICKED_UP -> Color(0xFF9C27B0).copy(alpha = 0.15f) to Color(0xFF4A148C)
        OrderStatus.DELIVERED -> SooGoodMart.copy(alpha = 0.15f) to SooGoodMart
        OrderStatus.CANCELLED -> NonVegRed.copy(alpha = 0.15f) to NonVegRed
    }

    Text(
        text = status.displayLabel,
        color = textColor,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(bgColor)
            .padding(horizontal = 12.dp, vertical = 6.dp)
    )
}
