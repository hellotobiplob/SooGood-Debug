package `in`.soogood.restaurant.util

import java.text.NumberFormat
import java.util.Locale

object Formatters {
    private val indianLocale = Locale.Builder().setLanguage("en").setRegion("IN").build()
    private val currencyFormatter = NumberFormat.getCurrencyInstance(indianLocale).apply {
        maximumFractionDigits = 0
    }

    fun formatRupee(amount: Int): String {
        return "₹${currencyFormatter.format(amount).replace("₹", "").replace("INR", "").trim()}"
    }

    fun formatRupee(amount: Double): String {
        return "₹${currencyFormatter.format(amount).replace("₹", "").replace("INR", "").trim()}"
    }
}
