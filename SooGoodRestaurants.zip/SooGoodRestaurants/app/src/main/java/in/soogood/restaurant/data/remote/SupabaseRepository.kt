package `in`.soogood.restaurant.data.remote

import android.util.Log
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns

class SupabaseRepository {

    private val client = SupabaseConfig.client

    suspend fun fetchOrdersForRestaurant(storeId: String): List<DbOrder> {
        return try {
            client.postgrest["orders"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", storeId)
                    }
                }
                .decodeList<DbOrder>()
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching restaurant orders from Supabase", e)
            emptyList()
        }
    }

    suspend fun updateOrderStatus(orderId: String, status: String): Boolean {
        return try {
            client.postgrest["orders"].update(
                {
                    set("status", status)
                }
            ) {
                filter {
                    eq("id", orderId)
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status in restaurant app", e)
            false
        }
    }

    suspend fun addMenuItem(item: DbMenuItem): Boolean {
        return try {
            client.postgrest["menu_items"].insert(item)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error adding menu item", e)
            false
        }
    }

    companion object {
        private const val TAG = "RestaurantSupabaseRepo"
    }
}
