package `in`.soogood.restaurant.data.repository

import `in`.soogood.restaurant.data.model.AuthState
import `in`.soogood.restaurant.data.model.OnboardingData
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.User
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class FirebaseAuthRepository : AuthRepository {
    private val _authState = MutableStateFlow<AuthState>(
        AuthState.Authenticated(
            User(
                id = "demo_user",
                name = "Bake N Bite Owner",
                phone = "9091938712",
                email = "partner@soogood.in",
                restaurantId = "37c623c9-8459-457c-9605-2af3c097141a",
                restaurantName = "Bake N Bite"
            )
        )
    )
    override val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _ownedStores = MutableStateFlow<List<RestaurantInfo>>(
        listOf(
            RestaurantInfo(
                id = "37c623c9-8459-457c-9605-2af3c097141a",
                name = "Bake N Bite",
                ownerName = "Partner Owner",
                phone = "9091938712",
                email = "partner@soogood.in",
                address = "Nazirpur, Nadia",
                cuisine = "Bakery & Sweets",
                fssai = "12345678901234",
                bankAccount = "1234567890",
                ifsc = "SBIN0001234",
                openingTime = "10:00 AM",
                closingTime = "11:00 PM"
            )
        )
    )
    override val ownedStores: StateFlow<List<RestaurantInfo>> = _ownedStores.asStateFlow()

    override suspend fun sendOtp(phone: String): Boolean = true
    override suspend fun loginWithOtp(phone: String, otp: String) = LoginResult.Success((_authState.value as AuthState.Authenticated).user)
    override suspend fun loginWithEmail(email: String, password: String) = LoginResult.Success((_authState.value as AuthState.Authenticated).user)
    override suspend fun loginWithLoginId(loginId: String, password: String) = LoginResult.Success((_authState.value as AuthState.Authenticated).user)
    override suspend fun loginDemoUser() = LoginResult.Success((_authState.value as AuthState.Authenticated).user)
    override suspend fun submitOnboarding(data: OnboardingData) = true
    override suspend fun checkApprovalStatus() = _authState.value
    override suspend fun logout() {
        _authState.value = AuthState.Unauthenticated
    }
}
