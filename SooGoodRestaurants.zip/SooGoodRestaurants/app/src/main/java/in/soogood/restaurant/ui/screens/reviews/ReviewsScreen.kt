package `in`.soogood.restaurant.ui.screens.reviews

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.data.model.Review
import `in`.soogood.restaurant.ui.components.EmptyState
import `in`.soogood.restaurant.ui.components.SooGoodPrimaryButton
import `in`.soogood.restaurant.ui.components.SooGoodTextField
import `in`.soogood.restaurant.ui.screens.main.RestaurantViewModel
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.WarningOrange

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReviewsScreen(
    viewModel: RestaurantViewModel,
    onBack: () -> Unit
) {
    val reviews by viewModel.reviews.collectAsState()
    var selectedReviewForReply by remember { mutableStateOf<Review?>(null) }
    var replyText by remember { mutableStateOf("") }

    if (selectedReviewForReply != null) {
        AlertDialog(
            onDismissRequest = { selectedReviewForReply = null },
            title = { Text("Reply to ${selectedReviewForReply!!.customerName}") },
            text = {
                Column {
                    Text(
                        text = "\"${selectedReviewForReply!!.comment}\"",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    SooGoodTextField(
                        value = replyText,
                        onValueChange = { replyText = it },
                        label = "Your Reply",
                        placeholder = "Thank customer for feedback...",
                        singleLine = false
                    )
                }
            },
            confirmButton = {
                SooGoodPrimaryButton(
                    text = "Submit Reply",
                    onClick = {
                        if (replyText.isNotBlank()) {
                            viewModel.replyToReview(selectedReviewForReply!!.id, replyText)
                            selectedReviewForReply = null
                            replyText = ""
                        }
                    }
                )
            },
            dismissButton = {
                TextButton(onClick = { selectedReviewForReply = null }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Customer Reviews & Ratings", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SooGoodBrand),
                modifier = Modifier.statusBarsPadding()
            )
        }
    ) { padding ->
        if (reviews.isEmpty()) {
            EmptyState(title = "No reviews yet", subtitle = "Customer reviews will appear here.", modifier = Modifier.padding(padding))
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // Header rating summary
                item {
                    val avgRating = reviews.map { it.rating }.average()
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = String.format("%.1f", avgRating),
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 32.sp,
                                    color = WarningOrange
                                )
                                Row {
                                    repeat(5) {
                                        Icon(Icons.Default.Star, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.width(20.dp))
                            Column {
                                Text("Overall Rating", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                Text("Based on ${reviews.size} customer reviews", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                items(reviews, key = { it.id }) { review ->
                    ReviewCardItem(
                        review = review,
                        onReplyClick = {
                            selectedReviewForReply = review
                            replyText = review.reply ?: ""
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ReviewCardItem(
    review: Review,
    onReplyClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(review.customerName, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text(review.date, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                repeat(review.rating) {
                    Icon(Icons.Default.Star, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text("Ordered: ${review.itemNames}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(review.comment, fontSize = 14.sp)

            review.reply?.let { reply ->
                Spacer(modifier = Modifier.height(10.dp))
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SooGoodBrand.copy(alpha = 0.1f))
                        .padding(12.dp)
                ) {
                    Column {
                        Text("Restaurant Reply:", fontWeight = FontWeight.Bold, fontSize = 12.sp, color = SooGoodBrand)
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(reply, fontSize = 13.sp)
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedButton(
                onClick = onReplyClick,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.align(Alignment.End)
            ) {
                Text(if (review.reply == null) "Reply" else "Edit Reply", fontSize = 12.sp)
            }
        }
    }
}
