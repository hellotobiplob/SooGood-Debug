package `in`.soogood.restaurant.ui.screens.offers

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.ui.components.CreateOfferDialog
import `in`.soogood.restaurant.ui.components.EmptyState
import `in`.soogood.restaurant.ui.screens.main.RestaurantViewModel
import `in`.soogood.restaurant.ui.theme.NonVegRed
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.SooGoodMart

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun OffersScreen(
    viewModel: RestaurantViewModel,
    onBack: () -> Unit
) {
    val offers by viewModel.offers.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    if (showCreateDialog) {
        CreateOfferDialog(
            onDismiss = { showCreateDialog = false },
            onCreateOffer = { newOffer ->
                viewModel.addOffer(newOffer)
                showCreateDialog = false
            }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Discounts & Offers", fontWeight = FontWeight.Bold, color = Color.White) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = SooGoodBrand),
                modifier = Modifier.statusBarsPadding()
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showCreateDialog = true },
                containerColor = SooGoodBrand,
                contentColor = Color.White
            ) {
                Icon(Icons.Default.Add, contentDescription = "Create Offer")
            }
        }
    ) { padding ->
        if (offers.isEmpty()) {
            EmptyState(title = "No active offers", subtitle = "Tap + to create discount offers for your customers.", modifier = Modifier.padding(padding))
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                items(offers, key = { it.id }) { offer ->
                    OfferCardItem(
                        offer = offer,
                        onToggleActive = { isActive ->
                            viewModel.toggleOfferActive(offer.id, isActive)
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun OfferCardItem(
    offer: Offer,
    onToggleActive: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = offer.code,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 18.sp,
                    color = SooGoodBrand,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(SooGoodBrand.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                )
                Spacer(modifier = Modifier.weight(1f))
                Text(
                    text = if (offer.isActive) "Active" else "Inactive",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (offer.isActive) SooGoodMart else NonVegRed,
                    modifier = Modifier.padding(end = 8.dp)
                )
                Switch(
                    checked = offer.isActive,
                    onCheckedChange = onToggleActive,
                    colors = SwitchDefaults.colors(checkedTrackColor = SooGoodMart)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(offer.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Min order value: ₹${offer.minOrderValue}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("Valid until: ${offer.validUntil}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
