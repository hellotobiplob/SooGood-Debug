package `in`.soogood.restaurant.util

import android.content.Context
import android.net.Uri
import android.util.Log
import `in`.soogood.restaurant.data.remote.SupabaseConfig
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object StorageUtils {
    private const val TAG = "StorageUtils"

    suspend fun uploadImageToSupabase(
        context: Context,
        imageUri: Uri,
        bucketName: String = "public",
        filePrefix: String = "img"
    ): String? = withContext(Dispatchers.IO) {
        val uriStr = imageUri.toString()
        if (uriStr.startsWith("http://") || uriStr.startsWith("https://")) {
            return@withContext uriStr
        }

        return@withContext try {
            val bytes = context.contentResolver.openInputStream(imageUri)?.use { it.readBytes() }
                ?: return@withContext null

            val fileName = "${filePrefix}_${System.currentTimeMillis()}.jpg"
            val bucket = SupabaseConfig.client.storage[bucketName]

            try {
                bucket.upload(fileName, bytes) {
                    upsert = true
                }
                bucket.publicUrl(fileName)
            } catch (e: Exception) {
                Log.w(TAG, "Upload to bucket '$bucketName' failed, trying bucket 'images'", e)
                try {
                    val fallbackBucket = SupabaseConfig.client.storage["images"]
                    fallbackBucket.upload(fileName, bytes) {
                        upsert = true
                    }
                    fallbackBucket.publicUrl(fileName)
                } catch (e2: Exception) {
                    Log.e(TAG, "Fallback upload also failed", e2)
                    null
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error reading or uploading image", e)
            null
        }
    }
}
