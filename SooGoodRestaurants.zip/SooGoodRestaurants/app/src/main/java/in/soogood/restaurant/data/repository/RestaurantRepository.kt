package `in`.soogood.restaurant.data.repository

import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.data.model.NotificationItem
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderStatus
import `in`.soogood.restaurant.data.model.Payout
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.Review
import `in`.soogood.restaurant.data.model.WeeklyTiming
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Interface for restaurant operations.
 * Connected to live Supabase backend operations.
 */
interface RestaurantRepository {
    val currentStore: StateFlow<RestaurantInfo?>
    val orders: StateFlow<List<Order>>
    val menu: StateFlow<List<MenuItem>>
    val isOpen: StateFlow<Boolean>
    val restaurantName: StateFlow<String>
    val newOrderAlertFlow: SharedFlow<Order>

    val payouts: StateFlow<List<Payout>>
    val reviews: StateFlow<List<Review>>
    val offers: StateFlow<List<Offer>>
    val notifications: StateFlow<List<NotificationItem>>
    val weeklyTimings: StateFlow<List<WeeklyTiming>>

    suspend fun updateOrderStatus(orderId: String, status: OrderStatus)
    suspend fun rejectOrder(orderId: String, reason: String)
    suspend fun adjustPrepTime(orderId: String, addMinutes: Int)
    suspend fun markOrderAsMissed(orderId: String)
    suspend fun setItemStock(itemId: String, inStock: Boolean)
    suspend fun setOpen(open: Boolean)
    suspend fun addMenuItem(item: MenuItem)
    suspend fun editMenuItem(item: MenuItem)
    suspend fun deleteMenuItem(itemId: String)
    suspend fun setCategoryStock(category: String, inStock: Boolean)
    suspend fun setAllOutOfStockToday()
    suspend fun replyToReview(reviewId: String, replyText: String)
    suspend fun addOffer(offer: Offer)
    suspend fun toggleOfferActive(offerId: String, isActive: Boolean)
    suspend fun markNotificationRead(id: String)
    suspend fun markAllNotificationsRead()
    suspend fun updateWeeklyTiming(day: String, openTime: String, closeTime: String, isOpen: Boolean)
    suspend fun updateRestaurantImage(imageUrl: String)
    suspend fun switchActiveStore(storeId: String)
    suspend fun simulateIncomingOrder(): Order
    suspend fun refreshData()
}
