package `in`.soogood.restaurant.ui.screens.main

import android.app.Activity
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Help
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import `in`.soogood.restaurant.R
import `in`.soogood.restaurant.data.model.BarChartPoint
import `in`.soogood.restaurant.data.model.EarningsPeriod
import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderStatus
import androidx.compose.material.icons.filled.PhoneInTalk
import `in`.soogood.restaurant.ui.components.AddEditMenuItemDialog
import `in`.soogood.restaurant.ui.components.InAppCallOverlay
import `in`.soogood.restaurant.ui.components.EarningsBarChart
import `in`.soogood.restaurant.ui.components.EmptyState
import `in`.soogood.restaurant.ui.components.NewOrderAlertDialog
import `in`.soogood.restaurant.ui.components.RejectReasonDialog
import `in`.soogood.restaurant.ui.components.SooGoodPrimaryButton
import `in`.soogood.restaurant.ui.components.SooGoodTextField
import `in`.soogood.restaurant.ui.components.StatCard
import `in`.soogood.restaurant.ui.components.StatusChip
import `in`.soogood.restaurant.ui.theme.NonVegRed
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.SooGoodBrandDark
import `in`.soogood.restaurant.ui.theme.SooGoodFood
import `in`.soogood.restaurant.ui.theme.SooGoodMart
import `in`.soogood.restaurant.ui.theme.VegGreen
import `in`.soogood.restaurant.util.AlertSoundManager
import `in`.soogood.restaurant.util.Formatters
import `in`.soogood.restaurant.util.StorageUtils
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class OrderGroup(val label: String, val statuses: Set<OrderStatus>) {
    ALL("All Orders", OrderStatus.entries.toSet()),
    NEW("New", setOf(OrderStatus.PLACED)),
    KITCHEN("Kitchen", setOf(OrderStatus.ACCEPTED, OrderStatus.PREPARING)),
    READY("Ready", setOf(OrderStatus.READY, OrderStatus.RIDER_ASSIGNED, OrderStatus.PICKED_UP)),
    DONE("History", setOf(OrderStatus.DELIVERED, OrderStatus.CANCELLED))
}

@Composable
fun MainShellScreen(
    viewModel: RestaurantViewModel,
    onOrderClick: (String) -> Unit,
    onNavigateToReviews: () -> Unit,
    onNavigateToOffers: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onLogout: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    val activeAlert by viewModel.activeNewOrderAlert.collectAsState()
    val selectedToneUri by viewModel.selectedOrderAlertToneUri.collectAsState()

    LaunchedEffect(selectedTab) {
        viewModel.refreshData()
    }

    var showAddEditDialog by remember { mutableStateOf(false) }
    var editingItem by remember { mutableStateOf<MenuItem?>(null) }

    if (showAddEditDialog || editingItem != null) {
        AddEditMenuItemDialog(
            initialItem = editingItem,
            onDismiss = {
                showAddEditDialog = false
                editingItem = null
            },
            onSaveItem = { item ->
                if (editingItem == null) {
                    viewModel.addMenuItem(item)
                } else {
                    viewModel.editMenuItem(item)
                }
                showAddEditDialog = false
                editingItem = null
            }
        )
    }

    // Real-time Full Screen New Order Alert Dialog Overlay
    activeAlert?.let { alertOrder ->
        NewOrderAlertDialog(
            order = alertOrder,
            selectedToneUri = selectedToneUri,
            onAdjustPrepTime = { minutes ->
                viewModel.adjustPrepTime(alertOrder.id, minutes)
            },
            onAccept = {
                viewModel.setOrderStatus(alertOrder.id, OrderStatus.ACCEPTED)
            },
            onReject = {
                viewModel.rejectOrder(alertOrder.id, "Rejected by restaurant")
            },
            onDismiss = {
                viewModel.dismissNewOrderAlert()
            }
        )
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.onSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Receipt, contentDescription = null) },
                    label = { Text(stringResource(R.string.nav_orders)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SooGoodBrand,
                        selectedTextColor = SooGoodBrand,
                        indicatorColor = SooGoodBrand.copy(alpha = 0.12f)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = null) },
                    label = { Text(stringResource(R.string.nav_menu)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SooGoodBrand,
                        selectedTextColor = SooGoodBrand,
                        indicatorColor = SooGoodBrand.copy(alpha = 0.12f)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = null) },
                    label = { Text(stringResource(R.string.nav_earnings)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SooGoodBrand,
                        selectedTextColor = SooGoodBrand,
                        indicatorColor = SooGoodBrand.copy(alpha = 0.12f)
                    )
                )
                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    icon = { Icon(Icons.Default.Person, contentDescription = null) },
                    label = { Text(stringResource(R.string.nav_account)) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = SooGoodBrand,
                        selectedTextColor = SooGoodBrand,
                        indicatorColor = SooGoodBrand.copy(alpha = 0.12f)
                    )
                )
            }
        },
        floatingActionButton = {
            if (selectedTab == 1) {
                FloatingActionButton(
                    onClick = { showAddEditDialog = true },
                    containerColor = SooGoodBrand,
                    contentColor = Color.White
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Add New Item")
                }
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.padding(innerPadding)) {
            when (selectedTab) {
                0 -> OrdersTab(viewModel, onOrderClick)
                1 -> MenuTab(
                    vm = viewModel,
                    onEditItem = { item -> editingItem = item },
                    onAddNewItem = { showAddEditDialog = true }
                )
                2 -> EarningsTab(viewModel)
                3 -> AccountTab(
                    vm = viewModel,
                    onNavigateToReviews = onNavigateToReviews,
                    onNavigateToOffers = onNavigateToOffers,
                    onNavigateToNotifications = onNavigateToNotifications,
                    onLogout = onLogout
                )
            }
        }
    }
}

// ───────────── Orders Tab ─────────────

@Composable
private fun OrdersTab(vm: RestaurantViewModel, onOrderClick: (String) -> Unit) {
    val orders by vm.orders.collectAsState()
    val isOpen by vm.isOpen.collectAsState()
    val restaurantName by vm.restaurantName.collectAsState()
    var selectedGroup by remember { mutableStateOf(OrderGroup.NEW) }
    val todaySales = orders.filter { it.status != OrderStatus.CANCELLED && it.status != OrderStatus.PLACED }.sumOf { it.total }

    var rejectTargetOrderId by remember { mutableStateOf<String?>(null) }

    rejectTargetOrderId?.let { orderId ->
        RejectReasonDialog(
            orderId = orderId,
            onDismiss = { rejectTargetOrderId = null },
            onConfirmReject = { reason ->
                vm.rejectOrder(orderId, reason)
                rejectTargetOrderId = null
            }
        )
    }

    Column(Modifier.fillMaxSize()) {
        Column(
            Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(listOf(SooGoodBrand, SooGoodBrandDark)))
                .statusBarsPadding()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(
                        text = restaurantName,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = if (isOpen) stringResource(R.string.status_open) else stringResource(R.string.status_closed),
                        color = Color.White.copy(alpha = 0.85f),
                        fontSize = 13.sp
                    )
                }
                Switch(
                    checked = isOpen,
                    onCheckedChange = { vm.setOpen(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = SooGoodMart)
                )
            }
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("New", orders.count { it.status == OrderStatus.PLACED }.toString(), Modifier.weight(1f))
                StatCard("In kitchen", orders.count { it.status in OrderGroup.KITCHEN.statuses }.toString(), Modifier.weight(1f))
                StatCard("Sales today", Formatters.formatRupee(todaySales), Modifier.weight(1.3f))
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OrderGroup.entries.forEach { g ->
                val count = orders.count { it.status in g.statuses }
                val selected = g == selectedGroup
                val labelText = if (g == OrderGroup.DONE) g.label else "${g.label} ($count)"
                Text(
                    text = labelText,
                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 13.sp,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (selected) SooGoodBrand else MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { selectedGroup = g }
                        .padding(horizontal = 14.dp, vertical = 8.dp)
                )
            }
        }

        val shownOrders = orders.filter { it.status in selectedGroup.statuses }
        if (shownOrders.isEmpty()) {
            EmptyState(
                title = "No orders in ${selectedGroup.label}",
                subtitle = "New orders will appear here automatically."
            )
        } else {
            LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(shownOrders, key = { it.id }) { order ->
                    OrderCardItem(
                        order = order,
                        vm = vm,
                        onOrderClick = { onOrderClick(order.id) },
                        onRejectClick = { rejectTargetOrderId = order.id }
                    )
                }
            }
        }
    }
}

@Composable
private fun OrderCardItem(
    order: Order,
    vm: RestaurantViewModel,
    onOrderClick: () -> Unit,
    onRejectClick: () -> Unit
) {
    var secondsRemaining by remember(order.id, order.status) { mutableIntStateOf(180) }

    if (order.status == OrderStatus.PLACED) {
        LaunchedEffect(order.id, secondsRemaining) {
            if (secondsRemaining > 0) {
                delay(1000)
                secondsRemaining--
            } else {
                vm.markOrderAsMissed(order.id)
            }
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOrderClick() },
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(order.id, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                StatusChip(status = order.status)
                Spacer(Modifier.width(8.dp))
                Text("${order.minsAgo} min ago", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 12.sp)
            }
            Spacer(Modifier.height(4.dp))
            Text("Customer: ${order.customerFirstName}", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))

            if (order.status == OrderStatus.PLACED) {
                val mins = secondsRemaining / 60
                val secs = secondsRemaining % 60
                val timeStr = String.format("%02d:%02d", mins, secs)

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(NonVegRed.copy(alpha = 0.12f))
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Timer, contentDescription = null, tint = NonVegRed, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "Accept within $timeStr",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = NonVegRed
                    )
                }
                Spacer(Modifier.height(10.dp))
            }

            order.items.forEach { item ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${item.qty} ×", fontWeight = FontWeight.Bold, color = SooGoodFood, modifier = Modifier.width(32.dp))
                    Text(item.name, modifier = Modifier.weight(1f), fontSize = 14.sp)
                    Text(Formatters.formatRupee(item.qty * item.price), fontSize = 14.sp)
                }
                Spacer(Modifier.height(4.dp))
            }

            order.note?.let { note ->
                Spacer(Modifier.height(6.dp))
                Text(
                    text = "📝 $note",
                    fontSize = 13.sp,
                    color = Color(0xFF8A4B00),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFFFF4E5))
                        .padding(10.dp)
                )
            }

            HorizontalDivider(Modifier.padding(vertical = 10.dp), color = MaterialTheme.colorScheme.outline)

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Payment: ${order.paymentType}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
                Text("Total: ", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(Formatters.formatRupee(order.total), fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = SooGoodBrand)
            }

            Spacer(Modifier.height(10.dp))

            var activeCallTargetLabel by remember { mutableStateOf<String?>(null) }

            activeCallTargetLabel?.let { targetLabel ->
                InAppCallOverlay(
                    orderId = order.id,
                    targetRoleLabel = targetLabel,
                    onEndCall = { activeCallTargetLabel = null }
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { activeCallTargetLabel = "Customer (${order.customerFirstName})" },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(vertical = 4.dp)
                ) {
                    Icon(Icons.Default.PhoneInTalk, contentDescription = null, tint = SooGoodBrand, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("In-App Call Customer (Masked)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(10.dp))

            when (order.status) {
                OrderStatus.PLACED -> {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Est. Prep: ${20 + order.prepTimeAdjustMins} min",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { vm.adjustPrepTime(order.id, -5) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("-5 min", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                            OutlinedButton(
                                onClick = { vm.adjustPrepTime(order.id, 5) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                            ) {
                                Text("+5 min", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(
                            onClick = onRejectClick,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        ) { Text("Reject") }

                        Button(
                            onClick = { vm.setOrderStatus(order.id, OrderStatus.ACCEPTED) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)
                        ) { Text("Accept") }
                    }
                }
                OrderStatus.ACCEPTED -> {
                    Button(
                        onClick = { vm.setOrderStatus(order.id, OrderStatus.PREPARING) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand)
                    ) { Text("Start Preparing") }
                }
                OrderStatus.PREPARING -> {
                    Button(
                        onClick = { vm.setOrderStatus(order.id, OrderStatus.READY) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SooGoodMart)
                    ) { Text("Mark Ready for Pickup") }
                }
                OrderStatus.READY -> StatusBanner("Waiting for delivery partner arrival…")
                OrderStatus.RIDER_ASSIGNED -> StatusBanner("Rider assigned — arriving soon")
                OrderStatus.PICKED_UP -> StatusBanner("Picked up — out for delivery")
                OrderStatus.DELIVERED -> StatusBanner("Delivered successfully ✓")
                OrderStatus.CANCELLED -> StatusBanner(if (order.isMissed) "MISSED — Auto Flagged" else "Order Cancelled")
            }
        }
    }
}

@Composable
private fun StatusBanner(text: String) {
    Text(
        text = text,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(12.dp)
    )
}

// ───────────── Menu Tab (Enhanced Phase 3) ─────────────

@Composable
private fun MenuTab(
    vm: RestaurantViewModel,
    onEditItem: (MenuItem) -> Unit,
    onAddNewItem: () -> Unit
) {
    val menu by vm.menu.collectAsState()
    val searchQuery by vm.menuQuery.collectAsState()

    var deleteConfirmItem by remember { mutableStateOf<MenuItem?>(null) }

    deleteConfirmItem?.let { item ->
        AlertDialog(
            onDismissRequest = { deleteConfirmItem = null },
            title = { Text("Delete Menu Item") },
            text = { Text("Are you sure you want to remove \"${item.name}\" from your menu?") },
            confirmButton = {
                Button(
                    onClick = {
                        vm.deleteMenuItem(item.id)
                        deleteConfirmItem = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = NonVegRed)
                ) { Text("Delete") }
            },
            dismissButton = {
                TextButton(onClick = { deleteConfirmItem = null }) { Text("Cancel") }
            }
        )
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Column(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("Menu & Stock Management", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                    Text("Manage items, prices, and stock status", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }

                Button(
                    onClick = onAddNewItem,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SooGoodBrand),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Add Item", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(12.dp))

            // Search Bar
            SooGoodTextField(
                value = searchQuery,
                onValueChange = { vm.setMenuQuery(it) },
                label = "Search Menu Items",
                placeholder = "Search by name or category...",
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = SooGoodBrand) }
            )

            Spacer(Modifier.height(12.dp))

            // Bulk Out Of Stock Today Button
            OutlinedButton(
                onClick = { vm.setAllOutOfStockToday() },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Block, contentDescription = null, tint = NonVegRed, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Mark All Items Out of Stock Today", color = NonVegRed, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        val filteredMenu = if (searchQuery.isBlank()) {
            menu
        } else {
            menu.filter {
                it.name.contains(searchQuery, ignoreCase = true) ||
                        it.category.contains(searchQuery, ignoreCase = true) ||
                        it.description.contains(searchQuery, ignoreCase = true)
            }
        }

        if (filteredMenu.isEmpty()) {
            EmptyState(title = "No menu items found", subtitle = "Try adjusting your search query or add a new item.")
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                filteredMenu.groupBy { it.category }.forEach { (category, items) ->
                    item {
                        val categoryAllInStock = items.all { it.inStock }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = category,
                                fontWeight = FontWeight.Bold,
                                color = SooGoodBrand,
                                fontSize = 16.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = if (categoryAllInStock) "Category In Stock" else "Category Out",
                                fontSize = 11.sp,
                                color = if (categoryAllInStock) SooGoodMart else NonVegRed,
                                modifier = Modifier.padding(end = 6.dp)
                            )
                            Switch(
                                checked = categoryAllInStock,
                                onCheckedChange = { inStock ->
                                    vm.setCategoryStock(category, inStock)
                                },
                                colors = SwitchDefaults.colors(checkedTrackColor = SooGoodMart)
                            )
                        }
                    }

                    items(items, key = { it.id }) { menuItem ->
                        MenuItemRow(
                            item = menuItem,
                            onToggleStock = { vm.setItemStock(menuItem.id, !menuItem.inStock) },
                            onEdit = { onEditItem(menuItem) },
                            onDelete = { deleteConfirmItem = menuItem }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MenuItemRow(
    item: MenuItem,
    onToggleStock: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (!item.photoUrl.isNullOrBlank()) {
            AsyncImage(
                model = item.photoUrl,
                contentDescription = item.name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(52.dp)
                    .clip(RoundedCornerShape(10.dp))
            )
            Spacer(Modifier.width(10.dp))
        }

        Box(
            modifier = Modifier
                .size(16.dp)
                .border(1.5.dp, if (item.veg) VegGreen else NonVegRed, RoundedCornerShape(3.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .size(7.dp)
                    .clip(CircleShape)
                    .background(if (item.veg) VegGreen else NonVegRed)
            )
        }

        Spacer(Modifier.width(10.dp))

        Column(Modifier.weight(1f)) {
            Text(item.name, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Formatters.formatRupee(item.price), fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (item.displayPortion.isNotBlank()) {
                    Text(" • ${item.displayPortion}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = SooGoodBrand)
                }
                Text(" • ${item.prepTimeMins} min prep", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (item.description.isNotBlank()) {
                Text(item.description, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
            }
        }

        Switch(
            checked = item.inStock,
            onCheckedChange = { onToggleStock() },
            colors = SwitchDefaults.colors(checkedTrackColor = SooGoodMart)
        )

        IconButton(onClick = onEdit) {
            Icon(Icons.Default.Edit, contentDescription = "Edit", tint = SooGoodBrand, modifier = Modifier.size(20.dp))
        }

        IconButton(onClick = onDelete) {
            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = NonVegRed, modifier = Modifier.size(20.dp))
        }
    }
}

// ───────────── Earnings Tab (Phase 4) ─────────────

@Composable
private fun EarningsTab(vm: RestaurantViewModel) {
    val period by vm.earningsPeriod.collectAsState()
    val orders by vm.orders.collectAsState()
    val store by vm.currentStore.collectAsState()
    val payouts by vm.payouts.collectAsState()

    val nonCancelledOrders = remember(orders) {
        orders.filter { it.status != OrderStatus.CANCELLED }
    }

    val totalRevenue = remember(nonCancelledOrders) {
        nonCancelledOrders.sumOf { it.total.toDouble() }
    }

    val orderCount = nonCancelledOrders.size
    val avgOrderValue = if (orderCount > 0) (totalRevenue / orderCount).toInt() else 0

    val points = remember(nonCancelledOrders, period, totalRevenue) {
        when (period) {
            EarningsPeriod.TODAY -> {
                val timeLabels = listOf("6 AM", "9 AM", "12 PM", "3 PM", "6 PM", "9 PM")
                if (totalRevenue > 0) {
                    val share = totalRevenue / timeLabels.size
                    timeLabels.mapIndexed { idx, label ->
                        BarChartPoint(label, share * (0.6 + (idx * 0.15)))
                    }
                } else {
                    timeLabels.map { BarChartPoint(it, 0.0) }
                }
            }
            EarningsPeriod.THIS_WEEK -> {
                val days = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
                if (totalRevenue > 0) {
                    val share = totalRevenue / days.size
                    days.mapIndexed { idx, day ->
                        BarChartPoint(day, share * (0.7 + (idx * 0.1)))
                    }
                } else {
                    days.map { BarChartPoint(it, 0.0) }
                }
            }
            EarningsPeriod.THIS_MONTH -> {
                val weeks = listOf("Wk 1", "Wk 2", "Wk 3", "Wk 4")
                if (totalRevenue > 0) {
                    val share = totalRevenue / weeks.size
                    weeks.mapIndexed { idx, wk ->
                        BarChartPoint(wk, share * (0.8 + (idx * 0.1)))
                    }
                } else {
                    weeks.map { BarChartPoint(it, 0.0) }
                }
            }
        }
    }

    val bankSnippet = store?.bankAccount?.takeLast(4)?.let { "ending in $it" } ?: "linked account"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Earnings & Settlements", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)

        // Period Tab Selector
        TabRow(
            selectedTabIndex = period.ordinal,
            containerColor = Color.Transparent,
            contentColor = SooGoodBrand
        ) {
            Tab(selected = period == EarningsPeriod.TODAY, onClick = { vm.setEarningsPeriod(EarningsPeriod.TODAY) }) {
                Text("Today", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = period == EarningsPeriod.THIS_WEEK, onClick = { vm.setEarningsPeriod(EarningsPeriod.THIS_WEEK) }) {
                Text("This Week", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
            Tab(selected = period == EarningsPeriod.THIS_MONTH, onClick = { vm.setEarningsPeriod(EarningsPeriod.THIS_MONTH) }) {
                Text("This Month", fontWeight = FontWeight.Bold, modifier = Modifier.padding(12.dp))
            }
        }

        // Summary Cards
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            StatCard("Total Revenue", Formatters.formatRupee(totalRevenue.toInt()), Modifier.weight(1.2f), containerColor = SooGoodBrand, contentColor = Color.White)
            StatCard("Orders", orderCount.toString(), Modifier.weight(0.8f), containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)
            StatCard("Avg Order", Formatters.formatRupee(avgOrderValue), Modifier.weight(1f), containerColor = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface)
        }

        // Canvas Bar Chart
        EarningsBarChart(points = points)

        // Settlement Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(SooGoodMart.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.AccountBalance, contentDescription = null, tint = SooGoodMart)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Text("Daily Auto-Settlement Active", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Direct transfer to A/c $bankSnippet", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text("Settled ✓", fontWeight = FontWeight.Bold, color = SooGoodMart, fontSize = 13.sp)
            }
        }

        // Payout History List
        Text("Payout History", fontWeight = FontWeight.Bold, fontSize = 16.sp)

        if (payouts.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Today's Settlement", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                        Text("Ref: auto_settle (${bankSnippet})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Text(Formatters.formatRupee(totalRevenue.toInt()), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = SooGoodBrand)
                }
            }
        } else {
            payouts.forEach { payout ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(payout.date, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                            Text("Ref: ${payout.id} (${payout.bankAccountSnippet})", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(Formatters.formatRupee(payout.amount), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = SooGoodBrand)
                    }
                }
            }
        }
    }
}

// ───────────── Account Tab (Phase 5) ─────────────

@Composable
private fun AccountTab(
    vm: RestaurantViewModel,
    onNavigateToReviews: () -> Unit,
    onNavigateToOffers: () -> Unit,
    onNavigateToNotifications: () -> Unit,
    onLogout: () -> Unit
) {
    val context = LocalContext.current
    val alertSoundManager = remember { AlertSoundManager(context) }
    val isOpen by vm.isOpen.collectAsState()
    val restaurantName by vm.restaurantName.collectAsState()
    val store by vm.currentStore.collectAsState()
    val timings by vm.weeklyTimings.collectAsState()
    val selectedToneUri by vm.selectedOrderAlertToneUri.collectAsState()

    var showTimingsDialog by remember { mutableStateOf(false) }
    var showSupportDialog by remember { mutableStateOf(false) }
    var showTonePickerDialog by remember { mutableStateOf(false) }

    var isUploadingStoreImage by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    val storeImagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { pickedUri ->
            coroutineScope.launch {
                isUploadingStoreImage = true
                val uploadedUrl = StorageUtils.uploadImageToSupabase(
                    context = context,
                    imageUri = pickedUri,
                    bucketName = "public",
                    filePrefix = "store"
                )
                isUploadingStoreImage = false
                if (uploadedUrl != null) {
                    vm.updateRestaurantImage(uploadedUrl)
                }
            }
        }
    }

    val ringtonePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val uri: Uri? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                @Suppress("DEPRECATION")
                result.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            uri?.let {
                vm.setSelectedOrderAlertToneUri(it.toString())
            }
        }
    }

    if (showTonePickerDialog) {
        val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)?.toString() ?: ""
        val notifUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)?.toString() ?: ""
        val ringtoneUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)?.toString() ?: ""

        AlertDialog(
            onDismissRequest = {
                alertSoundManager.stopAlert()
                showTonePickerDialog = false
            },
            title = { Text("Select Order Alert Tone") },
            text = {
                Column {
                    ToneOptionRow("Default Loud Alarm Tone", alarmUri, selectedToneUri) { uri ->
                        vm.setSelectedOrderAlertToneUri(uri)
                        alertSoundManager.previewTone(uri)
                    }
                    ToneOptionRow("Notification Chime", notifUri, selectedToneUri) { uri ->
                        vm.setSelectedOrderAlertToneUri(uri)
                        alertSoundManager.previewTone(uri)
                    }
                    ToneOptionRow("Standard Ringtone", ringtoneUri, selectedToneUri) { uri ->
                        vm.setSelectedOrderAlertToneUri(uri)
                        alertSoundManager.previewTone(uri)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedButton(
                        onClick = {
                            alertSoundManager.stopAlert()
                            showTonePickerDialog = false
                            val intent = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALARM or RingtoneManager.TYPE_RINGTONE)
                                putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Select Custom Order Alert Tone")
                            }
                            ringtonePickerLauncher.launch(intent)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Browse System Ringtones...")
                    }
                }
            },
            confirmButton = {
                SooGoodPrimaryButton(
                    text = "Done",
                    onClick = {
                        alertSoundManager.stopAlert()
                        showTonePickerDialog = false
                    }
                )
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (showTimingsDialog) {
        AlertDialog(
            onDismissRequest = { showTimingsDialog = false },
            title = { Text("Weekly Operating Hours") },
            text = {
                Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                    if (store != null) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Daily Hours", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${store?.openingTime} - ${store?.closingTime}", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    timings.forEach { timing ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(timing.day, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("${timing.openTime} - ${timing.closeTime}", fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {
                SooGoodPrimaryButton(text = "Close", onClick = { showTimingsDialog = false })
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    if (showSupportDialog) {
        AlertDialog(
            onDismissRequest = { showSupportDialog = false },
            title = { Text("Help & Partner Support") },
            text = {
                Column {
                    Text("Need help with an order or settlement? Contact SooGood Partner Care:", fontSize = 13.sp)
                    Spacer(modifier = Modifier.height(12.dp))
                    Text("📞 Partner Helpline: +91 1800-200-7664", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("💬 WhatsApp Support: +91 98765-00123", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("✉️ Email: partner-support@soogood.in", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            },
            confirmButton = {
                SooGoodPrimaryButton(text = "OK", onClick = { showSupportDialog = false })
            },
            shape = RoundedCornerShape(20.dp)
        )
    }

    val storeDisplayName = store?.name?.ifBlank { restaurantName } ?: restaurantName
    val storeDisplayAddress = store?.address?.ifBlank { "Location not set" } ?: "Location not set"
    val storeFssaiSubtitle = if (store?.fssai.isNullOrBlank()) "FSSAI License Verification Pending" else "FSSAI Lic #${store?.fssai} (Verified ✓)"
    val storeHoursSubtitle = if (store == null) "Configure operating hours" else "Daily: ${store?.openingTime} - ${store?.closingTime}"

    Column(
        modifier = Modifier
            .fillMaxSize()
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Text("Account & Settings", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)

        // Restaurant Card with Profile Photo Picker
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
        ) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable {
                                if (!isUploadingStoreImage) {
                                    storeImagePickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isUploadingStoreImage) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = SooGoodBrand)
                        } else if (!store?.imageUrl.isNullOrBlank()) {
                            AsyncImage(
                                model = store?.imageUrl,
                                contentDescription = "Restaurant Cover Photo",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                        } else {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = "Upload Restaurant Image",
                                    tint = SooGoodBrand,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text("Upload Photo", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = SooGoodBrand)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(storeDisplayName, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text(storeDisplayAddress, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp)
                    }
                }

                Spacer(Modifier.height(12.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Accepting Online Orders", modifier = Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                    Switch(checked = isOpen, onCheckedChange = { vm.setOpen(it) })
                }
            }
        }

        // Quick Navigation Links
        Text("Business Management", fontWeight = FontWeight.Bold, fontSize = 15.sp)

        AccountMenuItem(
            title = "Order Alert Sound Tone",
            subtitle = if (selectedToneUri.isNullOrBlank()) "Default Alarm Tone" else "Custom Tone Configured ✓",
            icon = Icons.Default.MusicNote,
            onClick = { showTonePickerDialog = true }
        )

        AccountMenuItem(
            title = "Discounts & Offers",
            subtitle = "Create coupons and promotional discounts",
            icon = Icons.Default.LocalOffer,
            onClick = onNavigateToOffers
        )

        AccountMenuItem(
            title = "Reviews & Ratings",
            subtitle = "View customer feedback and reply to reviews",
            icon = Icons.Default.Star,
            onClick = onNavigateToReviews
        )

        AccountMenuItem(
            title = "Notifications",
            subtitle = "View payouts and system alerts",
            icon = Icons.Default.Notifications,
            onClick = onNavigateToNotifications
        )

        AccountMenuItem(
            title = "Weekly Operating Hours",
            subtitle = storeHoursSubtitle,
            icon = Icons.Default.Timer,
            onClick = { showTimingsDialog = true }
        )

        AccountMenuItem(
            title = "FSSAI & GST Verification",
            subtitle = storeFssaiSubtitle,
            icon = Icons.Default.VerifiedUser,
            onClick = {}
        )

        AccountMenuItem(
            title = "Help & Support",
            subtitle = "Partner helpline & WhatsApp care",
            icon = Icons.AutoMirrored.Filled.Help,
            onClick = { showSupportDialog = true }
        )

        Spacer(Modifier.height(12.dp))

        Button(
            onClick = onLogout,
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = NonVegRed)
        ) {
            Text("Logout", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        }
    }
}

@Composable
private fun ToneOptionRow(
    label: String,
    uri: String,
    currentSelectedUri: String?,
    onSelect: (String) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect(uri) }
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(
            selected = (currentSelectedUri == uri || (currentSelectedUri.isNullOrBlank() && uri.contains("alarm"))),
            onClick = { onSelect(uri) },
            colors = RadioButtonDefaults.colors(selectedColor = SooGoodBrand)
        )
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(start = 8.dp)
        )
    }
}

@Composable
private fun AccountMenuItem(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(SooGoodBrand.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon, contentDescription = null, tint = SooGoodBrand)
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Text(subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
