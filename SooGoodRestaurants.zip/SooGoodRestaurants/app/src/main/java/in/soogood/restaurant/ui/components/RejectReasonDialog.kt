package `in`.soogood.restaurant.ui.components

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.R
import `in`.soogood.restaurant.ui.theme.SooGoodBrand

@Composable
fun RejectReasonDialog(
    orderId: String,
    onDismiss: () -> Unit,
    onConfirmReject: (reason: String) -> Unit
) {
    val stockReason = stringResource(R.string.order_reject_reason_stock)
    val busyReason = stringResource(R.string.order_reject_reason_busy)
    val closingReason = stringResource(R.string.order_reject_reason_closing)
    val otherReason = stringResource(R.string.order_reject_reason_other)

    val predefinedReasons = remember(stockReason, busyReason, closingReason, otherReason) {
        listOf(stockReason, busyReason, closingReason, otherReason)
    }

    var selectedReason by remember { mutableStateOf(predefinedReasons.first()) }
    var customReasonText by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "${stringResource(R.string.order_reject_dialog_title)} ($orderId)",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .selectableGroup()
            ) {
                predefinedReasons.forEach { reason ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .selectable(
                                selected = (reason == selectedReason),
                                onClick = { selectedReason = reason }
                            )
                            .padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = (reason == selectedReason),
                            onClick = { selectedReason = reason },
                            colors = RadioButtonDefaults.colors(selectedColor = SooGoodBrand)
                        )
                        Text(
                            text = reason,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(start = 8.dp)
                        )
                    }
                }

                if (selectedReason == otherReason) {
                    Spacer(modifier = Modifier.height(8.dp))
                    SooGoodTextField(
                        value = customReasonText,
                        onValueChange = { customReasonText = it },
                        label = stringResource(R.string.order_reject_custom_hint),
                        singleLine = false
                    )
                }
            }
        },
        confirmButton = {
            SooGoodPrimaryButton(
                text = stringResource(R.string.order_confirm_reject),
                onClick = {
                    val finalReason = if (selectedReason == otherReason) {
                        customReasonText.ifBlank { "Rejected by restaurant" }
                    } else {
                        selectedReason
                    }
                    onConfirmReject(finalReason)
                },
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(stringResource(R.string.cancel), color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        shape = RoundedCornerShape(20.dp)
    )
}
