package `in`.soogood.restaurant.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.SooGoodBrandDark

/**
 * Custom Brand Logo Composable: White shopping bag with a smile on violet gradient background.
 */
@Composable
fun SooGoodBrandLogo(
    modifier: Modifier = Modifier,
    size: Dp = 80.dp,
    animated: Boolean = false
) {
    val transition = rememberInfiniteTransition(label = "LogoScaleTransition")
    val animatedScale by transition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "LogoScale"
    )

    val scale = if (animated) animatedScale else 1.0f

    Box(
        modifier = modifier
            .scale(scale)
            .size(size)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(SooGoodBrand, SooGoodBrandDark))),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size * 0.55f)) {
            val canvasWidth = size.toPx() * 0.55f
            val canvasHeight = size.toPx() * 0.55f

            // Bag dimensions
            val bagWidth = canvasWidth * 0.7f
            val bagHeight = canvasHeight * 0.65f
            val bagLeft = (canvasWidth - bagWidth) / 2f
            val bagTop = canvasHeight * 0.3f

            // Draw bag handle (curved top)
            val handleWidth = bagWidth * 0.45f
            val handleLeft = (canvasWidth - handleWidth) / 2f
            val handleTop = canvasHeight * 0.12f

            drawPath(
                path = Path().apply {
                    moveTo(handleLeft, bagTop)
                    cubicTo(
                        handleLeft, handleTop,
                        handleLeft + handleWidth, handleTop,
                        handleLeft + handleWidth, bagTop
                    )
                },
                color = Color.White,
                style = Stroke(width = canvasWidth * 0.08f)
            )

            // Draw Bag Body
            drawRoundRect(
                color = Color.White,
                topLeft = Offset(bagLeft, bagTop),
                size = Size(bagWidth, bagHeight),
                cornerRadius = CornerRadius(canvasWidth * 0.12f, canvasWidth * 0.12f)
            )

            // Draw Smile inside bag
            val smileWidth = bagWidth * 0.45f
            val smileLeft = (canvasWidth - smileWidth) / 2f
            val smileY = bagTop + bagHeight * 0.45f
            val smileHeight = bagHeight * 0.3f

            drawPath(
                path = Path().apply {
                    moveTo(smileLeft, smileY)
                    quadraticTo(
                        canvasWidth / 2f, smileY + smileHeight,
                        smileLeft + smileWidth, smileY
                    )
                },
                color = SooGoodBrand,
                style = Stroke(width = canvasWidth * 0.08f)
            )
        }
    }
}

@Composable
fun BrandHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    logoSize: Dp = 72.dp,
    animatedLogo: Boolean = false
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(SooGoodBrand, SooGoodBrandDark)))
            .padding(top = 28.dp, bottom = 28.dp, start = 20.dp, end = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        SooGoodBrandLogo(size = logoSize, animated = animatedLogo)
        Spacer(modifier = Modifier.height(16.dp))
        Text(
            text = title,
            color = Color.White,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 24.sp,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = subtitle,
            color = Color.White.copy(alpha = 0.85f),
            fontWeight = FontWeight.Normal,
            fontSize = 14.sp,
            textAlign = TextAlign.Center
        )
    }
}
