package `in`.soogood.restaurant.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Category
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Scale
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import `in`.soogood.restaurant.data.model.AddOn
import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.ui.theme.NonVegRed
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.SooGoodMart
import `in`.soogood.restaurant.ui.theme.VegGreen
import `in`.soogood.restaurant.util.StorageUtils
import kotlinx.coroutines.launch

@Composable
fun AddEditMenuItemDialog(
    initialItem: MenuItem? = null,
    existingCategories: List<String> = listOf("Biryani", "Main Course", "Breads", "Desserts", "Beverages"),
    onDismiss: () -> Unit,
    onSaveItem: (MenuItem) -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var name by remember { mutableStateOf(initialItem?.name ?: "") }
    var category by remember { mutableStateOf(initialItem?.category ?: existingCategories.firstOrNull() ?: "Biryani") }
    var priceStr by remember { mutableStateOf(initialItem?.price?.toString() ?: "") }
    var prepTimeStr by remember { mutableStateOf(initialItem?.prepTimeMins?.toString() ?: "20") }
    var quantityValue by remember { mutableStateOf(initialItem?.quantityValue ?: "") }
    var quantityUnit by remember { mutableStateOf(initialItem?.quantityUnit ?: "pcs") }
    var description by remember { mutableStateOf(initialItem?.description ?: "") }
    var isVeg by remember { mutableStateOf(initialItem?.veg ?: true) }
    var inStock by remember { mutableStateOf(initialItem?.inStock ?: true) }
    var photoUrl by remember { mutableStateOf(initialItem?.photoUrl ?: "") }
    var isUploadingImage by remember { mutableStateOf(false) }

    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        uri?.let { pickedUri ->
            coroutineScope.launch {
                isUploadingImage = true
                val uploadedUrl = StorageUtils.uploadImageToSupabase(
                    context = context,
                    imageUri = pickedUri,
                    bucketName = "public",
                    filePrefix = "menu"
                )
                isUploadingImage = false
                photoUrl = uploadedUrl ?: pickedUri.toString()
            }
        }
    }

    val addOnsList = remember {
        mutableStateListOf<AddOn>().apply {
            initialItem?.addOns?.let { addAll(it) }
        }
    }

    var newAddOnName by remember { mutableStateOf("") }
    var newAddOnPriceStr by remember { mutableStateOf("") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val unitOptions = listOf("pcs", "gm", "kg", "ml", "portion", "half", "full")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialItem == null) "Add New Menu Item" else "Edit Menu Item",
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Photo Picker Container
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(130.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .clickable {
                            if (!isUploadingImage) {
                                imagePickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    if (isUploadingImage) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = SooGoodBrand, modifier = Modifier.size(32.dp))
                            Spacer(modifier = Modifier.height(8.dp))
                            Text("Uploading photo to cloud...", fontSize = 12.sp, color = SooGoodBrand, fontWeight = FontWeight.Bold)
                        }
                    } else if (!photoUrl.isBlank()) {
                        AsyncImage(
                            model = photoUrl,
                            contentDescription = "Selected Item Photo",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = SooGoodBrand,
                                modifier = Modifier.size(36.dp)
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Choose Photo from Gallery",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = SooGoodBrand
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Item Name
                SooGoodTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = "Item Name",
                    placeholder = "e.g. Special Chicken Biryani",
                    leadingIcon = { Icon(Icons.Default.Fastfood, contentDescription = null, tint = SooGoodBrand) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Portion & Quantity Unit Selector
                Text("Quantity & Portion Unit", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        SooGoodTextField(
                            value = quantityValue,
                            onValueChange = { quantityValue = it },
                            label = "Portion Size",
                            placeholder = "e.g. 500, 1, 2",
                            leadingIcon = { Icon(Icons.Default.Scale, contentDescription = null, tint = SooGoodBrand) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Unit Chips
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    unitOptions.forEach { unit ->
                        val selected = quantityUnit.equals(unit, ignoreCase = true)
                        Text(
                            text = unit,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier
                                .clip(RoundedCornerShape(16.dp))
                                .background(if (selected) SooGoodBrand else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { quantityUnit = unit }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Category & Veg/Non-Veg Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        SooGoodTextField(
                            value = category,
                            onValueChange = { category = it },
                            label = "Category",
                            placeholder = "e.g. Biryani",
                            leadingIcon = { Icon(Icons.Default.Category, contentDescription = null, tint = SooGoodBrand) }
                        )
                    }

                    Row(
                        modifier = Modifier
                            .weight(0.8f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(16.dp)
                                .border(1.5.dp, if (isVeg) VegGreen else NonVegRed, RoundedCornerShape(3.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(if (isVeg) VegGreen else NonVegRed)
                            )
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isVeg) "VEG" else "NON-VEG",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (isVeg) VegGreen else NonVegRed
                        )
                        Switch(
                            checked = isVeg,
                            onCheckedChange = { isVeg = it },
                            colors = SwitchDefaults.colors(checkedTrackColor = VegGreen)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Price & Prep Time Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        SooGoodTextField(
                            value = priceStr,
                            onValueChange = { priceStr = it },
                            label = "Price (₹)",
                            placeholder = "249",
                            leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, tint = SooGoodBrand) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        SooGoodTextField(
                            value = prepTimeStr,
                            onValueChange = { prepTimeStr = it },
                            label = "Prep Time (min)",
                            placeholder = "20",
                            leadingIcon = { Icon(Icons.Default.Schedule, contentDescription = null, tint = SooGoodBrand) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Description
                SooGoodTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = "Description (Optional)",
                    placeholder = "Short description of ingredients or taste",
                    singleLine = false
                )

                Spacer(modifier = Modifier.height(16.dp))

                // In Stock Switch
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (inStock) "Item Available In Stock" else "Item Currently Out of Stock",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp,
                        color = if (inStock) SooGoodMart else NonVegRed,
                        modifier = Modifier.weight(1f)
                    )
                    Switch(
                        checked = inStock,
                        onCheckedChange = { inStock = it },
                        colors = SwitchDefaults.colors(checkedTrackColor = SooGoodMart)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Add-ons Section
                Text("Add-ons / Customizations", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))

                addOnsList.forEachIndexed { index, addOn ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("• ${addOn.name} (+₹${addOn.price})", fontSize = 13.sp, modifier = Modifier.weight(1f))
                        IconButton(onClick = { addOnsList.removeAt(index) }) {
                            Icon(Icons.Default.Close, contentDescription = "Remove", tint = MaterialTheme.colorScheme.error)
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1.3f)) {
                        SooGoodTextField(
                            value = newAddOnName,
                            onValueChange = { newAddOnName = it },
                            label = "Add-on Name",
                            placeholder = "e.g. Extra Cheese"
                        )
                    }
                    Column(modifier = Modifier.weight(0.9f)) {
                        SooGoodTextField(
                            value = newAddOnPriceStr,
                            onValueChange = { newAddOnPriceStr = it },
                            label = "Price (₹)",
                            placeholder = "30",
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                    IconButton(
                        onClick = {
                            val priceVal = newAddOnPriceStr.toIntOrNull() ?: 0
                            if (newAddOnName.isNotBlank() && priceVal > 0) {
                                addOnsList.add(AddOn(newAddOnName, priceVal))
                                newAddOnName = ""
                                newAddOnPriceStr = ""
                            }
                        }
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Add Add-on", tint = SooGoodBrand)
                    }
                }
            }
        },
        confirmButton = {
            SooGoodPrimaryButton(
                text = "Save Menu Item",
                onClick = {
                    val priceVal = priceStr.toIntOrNull()
                    val prepVal = prepTimeStr.toIntOrNull() ?: 20

                    if (name.isBlank()) {
                        errorMessage = "Please enter an item name."
                        return@SooGoodPrimaryButton
                    }
                    if (priceVal == null || priceVal <= 0) {
                        errorMessage = "Please enter a valid price."
                        return@SooGoodPrimaryButton
                    }

                    val savedItem = MenuItem(
                        id = initialItem?.id ?: ("m_" + System.currentTimeMillis()),
                        name = name,
                        category = category.ifBlank { "General" },
                        price = priceVal,
                        veg = isVeg,
                        inStock = inStock,
                        description = description,
                        prepTimeMins = prepVal,
                        quantityValue = quantityValue,
                        quantityUnit = quantityUnit,
                        photoUrl = photoUrl,
                        addOns = addOnsList.toList()
                    )

                    onSaveItem(savedItem)
                },
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        shape = RoundedCornerShape(24.dp)
    )
}
