package `in`.soogood.restaurant.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.CurrencyRupee
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.Percent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.ui.theme.SooGoodBrand

@Composable
fun CreateOfferDialog(
    onDismiss: () -> Unit,
    onCreateOffer: (Offer) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var discountType by remember { mutableStateOf("PERCENTAGE") } // PERCENTAGE or FLAT
    var discountValueStr by remember { mutableStateOf("") }
    var minOrderStr by remember { mutableStateOf("199") }
    var validityStr by remember { mutableStateOf("31 Dec 2026") }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = "Create Discount Offer",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                if (errorMessage != null) {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f),
                                RoundedCornerShape(10.dp)
                            )
                            .padding(10.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }

                SooGoodTextField(
                    value = code,
                    onValueChange = { code = it.uppercase() },
                    label = "Offer Promo Code",
                    placeholder = "e.g. WELCOME50",
                    leadingIcon = { Icon(Icons.Default.LocalOffer, contentDescription = null, tint = SooGoodBrand) }
                )

                Spacer(modifier = Modifier.height(12.dp))

                SooGoodTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = "Offer Title",
                    placeholder = "e.g. 50% OFF up to ₹100"
                )

                Spacer(modifier = Modifier.height(12.dp))

                Text("Discount Type", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .padding(end = 16.dp)
                    ) {
                        RadioButton(
                            selected = discountType == "PERCENTAGE",
                            onClick = { discountType = "PERCENTAGE" },
                            colors = RadioButtonDefaults.colors(selectedColor = SooGoodBrand)
                        )
                        Text("Percentage (%)", fontSize = 14.sp)
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(
                            selected = discountType == "FLAT",
                            onClick = { discountType = "FLAT" },
                            colors = RadioButtonDefaults.colors(selectedColor = SooGoodBrand)
                        )
                        Text("Flat Amount (₹)", fontSize = 14.sp)
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        SooGoodTextField(
                            value = discountValueStr,
                            onValueChange = { discountValueStr = it },
                            label = if (discountType == "PERCENTAGE") "Discount %" else "Discount ₹",
                            placeholder = if (discountType == "PERCENTAGE") "20" else "50",
                            leadingIcon = {
                                Icon(
                                    imageVector = if (discountType == "PERCENTAGE") Icons.Default.Percent else Icons.Default.CurrencyRupee,
                                    contentDescription = null,
                                    tint = SooGoodBrand
                                )
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        SooGoodTextField(
                            value = minOrderStr,
                            onValueChange = { minOrderStr = it },
                            label = "Min Order (₹)",
                            placeholder = "199",
                            leadingIcon = { Icon(Icons.Default.CurrencyRupee, contentDescription = null, tint = SooGoodBrand) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                SooGoodTextField(
                    value = validityStr,
                    onValueChange = { validityStr = it },
                    label = "Valid Until Date",
                    placeholder = "31 Dec 2026",
                    leadingIcon = { Icon(Icons.Default.CalendarMonth, contentDescription = null, tint = SooGoodBrand) }
                )
            }
        },
        confirmButton = {
            SooGoodPrimaryButton(
                text = "Create Offer",
                onClick = {
                    val discVal = discountValueStr.toIntOrNull()
                    val minVal = minOrderStr.toIntOrNull() ?: 0

                    if (code.isBlank()) {
                        errorMessage = "Enter promo code."
                        return@SooGoodPrimaryButton
                    }
                    if (discVal == null || discVal <= 0) {
                        errorMessage = "Enter valid discount value."
                        return@SooGoodPrimaryButton
                    }

                    val newOffer = Offer(
                        id = "off_" + System.currentTimeMillis(),
                        code = code.trim(),
                        title = title.ifBlank { if (discountType == "PERCENTAGE") "$discVal% OFF" else "Flat ₹$discVal OFF" },
                        discountType = discountType,
                        discountValue = discVal,
                        minOrderValue = minVal,
                        validUntil = validityStr.ifBlank { "31 Dec 2026" },
                        isActive = true
                    )

                    onCreateOffer(newOffer)
                },
                modifier = Modifier.padding(horizontal = 8.dp)
            )
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        shape = RoundedCornerShape(24.dp)
    )
}
