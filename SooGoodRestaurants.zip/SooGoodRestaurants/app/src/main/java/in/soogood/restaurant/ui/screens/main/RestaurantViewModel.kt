package `in`.soogood.restaurant.ui.screens.main

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.restaurant.data.model.EarningsPeriod
import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.data.model.NotificationItem
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderStatus
import `in`.soogood.restaurant.data.model.Payout
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.Review
import `in`.soogood.restaurant.data.model.WeeklyTiming
import `in`.soogood.restaurant.data.repository.RestaurantRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RestaurantViewModel(private val repository: RestaurantRepository) : ViewModel() {
    val currentStore: StateFlow<RestaurantInfo?> = repository.currentStore.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), null
    )

    val orders: StateFlow<List<Order>> = repository.orders.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val menu: StateFlow<List<MenuItem>> = repository.menu.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val isOpen: StateFlow<Boolean> = repository.isOpen.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), true
    )

    val restaurantName: StateFlow<String> = repository.restaurantName.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), "Biryani House"
    )

    val payouts: StateFlow<List<Payout>> = repository.payouts.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val reviews: StateFlow<List<Review>> = repository.reviews.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val offers: StateFlow<List<Offer>> = repository.offers.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val notifications: StateFlow<List<NotificationItem>> = repository.notifications.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    val weeklyTimings: StateFlow<List<WeeklyTiming>> = repository.weeklyTimings.stateIn(
        viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList()
    )

    private val _earningsPeriod = MutableStateFlow(EarningsPeriod.TODAY)
    val earningsPeriod: StateFlow<EarningsPeriod> = _earningsPeriod.asStateFlow()

    private val _menuQuery = MutableStateFlow("")
    val menuQuery: StateFlow<String> = _menuQuery.asStateFlow()

    private val _activeNewOrderAlert = MutableStateFlow<Order?>(null)
    val activeNewOrderAlert: StateFlow<Order?> = _activeNewOrderAlert.asStateFlow()

    private val _selectedOrderAlertToneUri = MutableStateFlow<String?>(null)
    val selectedOrderAlertToneUri: StateFlow<String?> = _selectedOrderAlertToneUri.asStateFlow()

    init {
        viewModelScope.launch {
            repository.newOrderAlertFlow.collect { newOrder ->
                _activeNewOrderAlert.value = newOrder
            }
        }
    }

    fun refreshData() {
        viewModelScope.launch {
            repository.refreshData()
        }
    }

    fun setSelectedOrderAlertToneUri(uri: String?) {
        _selectedOrderAlertToneUri.value = uri
    }

    fun setEarningsPeriod(period: EarningsPeriod) {
        _earningsPeriod.value = period
    }

    fun setMenuQuery(query: String) {
        _menuQuery.value = query
    }

    fun dismissNewOrderAlert() {
        _activeNewOrderAlert.value = null
    }

    fun setOrderStatus(orderId: String, status: OrderStatus) {
        viewModelScope.launch {
            repository.updateOrderStatus(orderId, status)
            if (_activeNewOrderAlert.value?.id == orderId) {
                _activeNewOrderAlert.value = null
            }
        }
    }

    fun rejectOrder(orderId: String, reason: String) {
        viewModelScope.launch {
            repository.rejectOrder(orderId, reason)
            if (_activeNewOrderAlert.value?.id == orderId) {
                _activeNewOrderAlert.value = null
            }
        }
    }

    fun adjustPrepTime(orderId: String, addMinutes: Int) {
        viewModelScope.launch {
            repository.adjustPrepTime(orderId, addMinutes)
        }
    }

    fun markOrderAsMissed(orderId: String) {
        viewModelScope.launch {
            repository.markOrderAsMissed(orderId)
        }
    }

    fun setItemStock(itemId: String, inStock: Boolean) {
        viewModelScope.launch {
            repository.setItemStock(itemId, inStock)
        }
    }

    fun addMenuItem(item: MenuItem) {
        viewModelScope.launch {
            repository.addMenuItem(item)
        }
    }

    fun editMenuItem(item: MenuItem) {
        viewModelScope.launch {
            repository.editMenuItem(item)
        }
    }

    fun deleteMenuItem(itemId: String) {
        viewModelScope.launch {
            repository.deleteMenuItem(itemId)
        }
    }

    fun setCategoryStock(category: String, inStock: Boolean) {
        viewModelScope.launch {
            repository.setCategoryStock(category, inStock)
        }
    }

    fun setAllOutOfStockToday() {
        viewModelScope.launch {
            repository.setAllOutOfStockToday()
        }
    }

    fun replyToReview(reviewId: String, replyText: String) {
        viewModelScope.launch {
            repository.replyToReview(reviewId, replyText)
        }
    }

    fun addOffer(offer: Offer) {
        viewModelScope.launch {
            repository.addOffer(offer)
        }
    }

    fun toggleOfferActive(offerId: String, isActive: Boolean) {
        viewModelScope.launch {
            repository.toggleOfferActive(offerId, isActive)
        }
    }

    fun markNotificationRead(id: String) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun markAllNotificationsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsRead()
        }
    }

    fun updateWeeklyTiming(day: String, openTime: String, closeTime: String, isOpen: Boolean) {
        viewModelScope.launch {
            repository.updateWeeklyTiming(day, openTime, closeTime, isOpen)
        }
    }

    fun setOpen(open: Boolean) {
        viewModelScope.launch {
            repository.setOpen(open)
        }
    }

    fun switchActiveStore(storeId: String) {
        viewModelScope.launch {
            repository.switchActiveStore(storeId)
        }
    }

    fun updateRestaurantImage(imageUrl: String) {
        viewModelScope.launch {
            repository.updateRestaurantImage(imageUrl)
        }
    }
}
