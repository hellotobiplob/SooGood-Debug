package `in`.soogood.restaurant.data.repository

import android.util.Log
import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.data.model.NotificationItem
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderStatus
import `in`.soogood.restaurant.data.model.Payout
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.Review
import `in`.soogood.restaurant.data.model.WeeklyTiming
import `in`.soogood.restaurant.data.remote.DbMenuItem
import `in`.soogood.restaurant.data.remote.DbNotification
import `in`.soogood.restaurant.data.remote.DbOffer
import `in`.soogood.restaurant.data.remote.DbOrder
import `in`.soogood.restaurant.data.remote.DbOrderItem
import `in`.soogood.restaurant.data.remote.DbPayout
import `in`.soogood.restaurant.data.remote.DbReview
import `in`.soogood.restaurant.data.remote.DbStore
import `in`.soogood.restaurant.data.remote.DbWeeklyTiming
import `in`.soogood.restaurant.data.remote.SupabaseConfig
import `in`.soogood.restaurant.data.remote.toDb
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.realtime.PostgresAction
import io.github.jan.supabase.realtime.channel
import io.github.jan.supabase.realtime.postgresChangeFlow
import io.github.jan.supabase.realtime.realtime
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

class SupabaseRestaurantRepository(
    private val defaultStoreId: String = "37c623c9-8459-457c-9605-2af3c097141a",
    private val firebaseRealtimeRepository: FirebaseRealtimeRepository = FirebaseRealtimeRepository()
) : RestaurantRepository {

    private val scope = CoroutineScope(Dispatchers.IO)
    private val client = SupabaseConfig.client

    private val activeStoreId: String
        get() = SupabaseAuthRepository.activeStoreId ?: defaultStoreId

    private val _currentStore = MutableStateFlow<RestaurantInfo?>(null)
    override val currentStore: StateFlow<RestaurantInfo?> = _currentStore.asStateFlow()

    private val _restaurantName = MutableStateFlow("SooGood Restaurant Partner")
    private val _open = MutableStateFlow(true)
    private val _newOrderAlertFlow = MutableSharedFlow<Order>()

    private val _orders = MutableStateFlow<List<Order>>(emptyList())
    private val _menu = MutableStateFlow<List<MenuItem>>(emptyList())
    private val _payouts = MutableStateFlow<List<Payout>>(emptyList())
    private val _reviews = MutableStateFlow<List<Review>>(emptyList())
    private val _offers = MutableStateFlow<List<Offer>>(emptyList())
    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    private val _weeklyTimings = MutableStateFlow<List<WeeklyTiming>>(emptyList())

    override val orders: StateFlow<List<Order>> = _orders.asStateFlow()
    override val menu: StateFlow<List<MenuItem>> = _menu.asStateFlow()
    override val isOpen: StateFlow<Boolean> = _open.asStateFlow()
    override val restaurantName: StateFlow<String> = _restaurantName.asStateFlow()
    override val newOrderAlertFlow: SharedFlow<Order> = _newOrderAlertFlow.asSharedFlow()

    override val payouts: StateFlow<List<Payout>> = _payouts.asStateFlow()
    override val reviews: StateFlow<List<Review>> = _reviews.asStateFlow()
    override val offers: StateFlow<List<Offer>> = _offers.asStateFlow()
    override val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()
    override val weeklyTimings: StateFlow<List<WeeklyTiming>> = _weeklyTimings.asStateFlow()

    init {
        scope.launch {
            fetchAllRemoteData()
            setupRealtimeSubscriptions()
        }
    }

    override suspend fun refreshData() {
        fetchAllRemoteData()
    }

    private suspend fun fetchAllRemoteData() {
        fetchStoreDetails()
        fetchOrders()
        fetchMenu()
        fetchOffers()
        fetchReviews()
        fetchPayouts()
        fetchNotifications()
        fetchWeeklyTimings()
    }

    private suspend fun fetchStoreDetails() {
        try {
            val stores = client.postgrest["stores"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("id", activeStoreId)
                    }
                }
                .decodeList<DbStore>()

            val store = stores.firstOrNull()
            if (store != null) {
                val domainInfo = store.toDomainRestaurantInfo()
                _currentStore.value = domainInfo
                _restaurantName.value = domainInfo.name
                _open.value = store.isOpen
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching store details from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchOrders() {
        try {
            val dbOrders = client.postgrest["orders"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbOrder>()

            val mapped = dbOrders.map { it.toDomain() }
            val previousPlacedIds = _orders.value.filter { it.status == OrderStatus.PLACED }.map { it.id }.toSet()
            val isFirstFetch = _orders.value.isEmpty()
            _orders.value = mapped

            val placedOrders = mapped.filter { it.status == OrderStatus.PLACED }
            placedOrders.forEach { newPlacedOrder ->
                if (isFirstFetch || !previousPlacedIds.contains(newPlacedOrder.id)) {
                    _newOrderAlertFlow.emit(newPlacedOrder)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching orders from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchMenu() {
        try {
            val dbMenuItems = client.postgrest["menu_items"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbMenuItem>()

            if (dbMenuItems.isNotEmpty()) {
                _menu.value = dbMenuItems.map { it.toDomain() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching menu items from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchOffers() {
        try {
            val dbOffers = client.postgrest["offers"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbOffer>()

            if (dbOffers.isNotEmpty()) {
                _offers.value = dbOffers.map { it.toDomain() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching offers from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchReviews() {
        try {
            val dbReviews = client.postgrest["reviews"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbReview>()

            if (dbReviews.isNotEmpty()) {
                _reviews.value = dbReviews.map { it.toDomain() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching reviews from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchPayouts() {
        try {
            val dbPayouts = client.postgrest["payouts"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbPayout>()

            if (dbPayouts.isNotEmpty()) {
                _payouts.value = dbPayouts.map { it.toDomain() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching payouts from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchNotifications() {
        try {
            val dbNotifs = client.postgrest["notifications"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbNotification>()

            if (dbNotifs.isNotEmpty()) {
                _notifications.value = dbNotifs.map { it.toDomain() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching notifications from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun fetchWeeklyTimings() {
        try {
            val dbTimings = client.postgrest["weekly_timings"]
                .select(columns = Columns.ALL) {
                    filter {
                        eq("store_id", activeStoreId)
                    }
                }
                .decodeList<DbWeeklyTiming>()

            if (dbTimings.isNotEmpty()) {
                _weeklyTimings.value = dbTimings.map { it.toDomain() }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching weekly timings from Supabase for storeId '$activeStoreId'", e)
        }
    }

    private suspend fun setupRealtimeSubscriptions() {
        try {
            val channel = client.channel("restaurant-orders-channel-$activeStoreId")
            val orderChangeFlow = channel.postgresChangeFlow<PostgresAction>(schema = "public") {
                table = "orders"
            }

            channel.subscribe()

            orderChangeFlow.collect { _ ->
                Log.d(TAG, "Realtime order change detected! Refreshing orders...")
                fetchOrders()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Supabase Realtime channel for orders", e)
        }
    }

    override suspend fun updateOrderStatus(orderId: String, status: OrderStatus) {
        _orders.update { list ->
            list.map { if (it.id == orderId) it.copy(status = status) else it }
        }
        firebaseRealtimeRepository.broadcastStatusUpdate(orderId, status.name)
        try {
            client.postgrest["orders"].update(
                {
                    set("status", status.name)
                }
            ) {
                filter {
                    or {
                        eq("id", orderId)
                        eq("order_number", orderId)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status on Supabase", e)
        }
    }

    override suspend fun rejectOrder(orderId: String, reason: String) {
        _orders.update { list ->
            list.map {
                if (it.id == orderId) it.copy(status = OrderStatus.CANCELLED, rejectionReason = reason) else it
            }
        }
        firebaseRealtimeRepository.broadcastStatusUpdate(orderId, OrderStatus.CANCELLED.name, rejectionReason = reason)
        try {
            client.postgrest["orders"].update(
                {
                    set("status", OrderStatus.CANCELLED.name)
                    set("rejection_reason", reason)
                }
            ) {
                filter {
                    or {
                        eq("id", orderId)
                        eq("order_number", orderId)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error rejecting order on Supabase", e)
        }
    }

    override suspend fun adjustPrepTime(orderId: String, addMinutes: Int) {
        var calculatedPrep = 0
        var currentOrderStatus = OrderStatus.PLACED.name

        _orders.update { list ->
            list.map {
                if (it.id == orderId) {
                    val newPrep = maxOf(0, it.prepTimeAdjustMins + addMinutes)
                    calculatedPrep = newPrep
                    currentOrderStatus = it.status.name
                    scope.launch {
                        try {
                            client.postgrest["orders"].update(
                                {
                                    set("prep_time_adjust_mins", newPrep)
                                }
                            ) {
                                filter {
                                    or {
                                        eq("id", orderId)
                                        eq("order_number", orderId)
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error adjusting prep time on Supabase", e)
                        }
                    }
                    it.copy(prepTimeAdjustMins = newPrep)
                } else it
            }
        }

        firebaseRealtimeRepository.broadcastStatusUpdate(orderId, currentOrderStatus, prepTimeMins = calculatedPrep)
    }

    override suspend fun markOrderAsMissed(orderId: String) {
        val missedReason = "Auto-flagged: Missed 3-minute acceptance window"
        _orders.update { list ->
            list.map {
                if (it.id == orderId && it.status == OrderStatus.PLACED) {
                    it.copy(
                        status = OrderStatus.CANCELLED,
                        isMissed = true,
                        rejectionReason = missedReason
                    )
                } else it
            }
        }
        firebaseRealtimeRepository.broadcastStatusUpdate(orderId, OrderStatus.CANCELLED.name, rejectionReason = missedReason)
        try {
            client.postgrest["orders"].update(
                {
                    set("status", OrderStatus.CANCELLED.name)
                    set("is_missed", true)
                    set("rejection_reason", missedReason)
                }
            ) {
                filter {
                    or {
                        eq("id", orderId)
                        eq("order_number", orderId)
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error marking order missed on Supabase", e)
        }
    }

    override suspend fun setItemStock(itemId: String, inStock: Boolean) {
        _menu.update { list ->
            list.map { if (it.id == itemId) it.copy(inStock = inStock) else it }
        }
        try {
            client.postgrest["menu_items"].update(
                {
                    set("is_available", inStock)
                }
            ) {
                filter {
                    eq("id", itemId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting item stock on Supabase", e)
        }
    }

    override suspend fun setOpen(open: Boolean) {
        _open.value = open
        try {
            client.postgrest["stores"].update(
                {
                    set("is_open", open)
                }
            ) {
                filter {
                    eq("id", activeStoreId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating store open status on Supabase", e)
        }
    }

    override suspend fun switchActiveStore(storeId: String) {
        SupabaseAuthRepository.activeStoreId = storeId
        fetchAllRemoteData()
    }

    override suspend fun updateRestaurantImage(imageUrl: String) {
        _currentStore.update { it?.copy(imageUrl = imageUrl) }
        try {
            client.postgrest["stores"].update(
                {
                    set("image_url", imageUrl)
                }
            ) {
                filter {
                    eq("id", activeStoreId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating restaurant image_url on Supabase", e)
        }
    }

    override suspend fun addMenuItem(item: MenuItem) {
        _menu.update { it + item }
        try {
            client.postgrest["menu_items"].insert(item.toDb(activeStoreId))
        } catch (e: Exception) {
            Log.e(TAG, "Error inserting menu item on Supabase", e)
        }
    }

    override suspend fun editMenuItem(item: MenuItem) {
        _menu.update { list ->
            list.map { if (it.id == item.id) item else it }
        }
        try {
            client.postgrest["menu_items"].update(item.toDb(activeStoreId)) {
                filter {
                    eq("id", item.id)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating menu item on Supabase", e)
        }
    }

    override suspend fun deleteMenuItem(itemId: String) {
        _menu.update { list ->
            list.filterNot { it.id == itemId }
        }
        try {
            client.postgrest["menu_items"].delete {
                filter {
                    eq("id", itemId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting menu item on Supabase", e)
        }
    }

    override suspend fun setCategoryStock(category: String, inStock: Boolean) {
        _menu.update { list ->
            list.map { if (it.category == category) it.copy(inStock = inStock) else it }
        }
        try {
            client.postgrest["menu_items"].update(
                {
                    set("is_available", inStock)
                }
            ) {
                filter {
                    eq("store_id", activeStoreId)
                    eq("category", category)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting category stock on Supabase", e)
        }
    }

    override suspend fun setAllOutOfStockToday() {
        _menu.update { list ->
            list.map { it.copy(inStock = false) }
        }
        try {
            client.postgrest["menu_items"].update(
                {
                    set("is_available", false)
                }
            ) {
                filter {
                    eq("store_id", activeStoreId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting all out of stock on Supabase", e)
        }
    }

    override suspend fun replyToReview(reviewId: String, replyText: String) {
        _reviews.update { list ->
            list.map { if (it.id == reviewId) it.copy(reply = replyText) else it }
        }
        try {
            client.postgrest["reviews"].update(
                {
                    set("reply", replyText)
                }
            ) {
                filter {
                    eq("id", reviewId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error replying to review on Supabase", e)
        }
    }

    override suspend fun addOffer(offer: Offer) {
        _offers.update { listOf(offer) + it }
        try {
            client.postgrest["offers"].insert(offer.toDb(activeStoreId))
        } catch (e: Exception) {
            Log.e(TAG, "Error adding offer on Supabase", e)
        }
    }

    override suspend fun toggleOfferActive(offerId: String, isActive: Boolean) {
        _offers.update { list ->
            list.map { if (it.id == offerId) it.copy(isActive = isActive) else it }
        }
        try {
            client.postgrest["offers"].update(
                {
                    set("is_active", isActive)
                }
            ) {
                filter {
                    eq("id", offerId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling offer on Supabase", e)
        }
    }

    override suspend fun markNotificationRead(id: String) {
        _notifications.update { list ->
            list.map { if (it.id == id) it.copy(isRead = true) else it }
        }
        try {
            client.postgrest["notifications"].update(
                {
                    set("is_read", true)
                }
            ) {
                filter {
                    eq("id", id)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error marking notification read on Supabase", e)
        }
    }

    override suspend fun markAllNotificationsRead() {
        _notifications.update { list ->
            list.map { it.copy(isRead = true) }
        }
        try {
            client.postgrest["notifications"].update(
                {
                    set("is_read", true)
                }
            ) {
                filter {
                    eq("store_id", activeStoreId)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error marking all notifications read on Supabase", e)
        }
    }

    override suspend fun updateWeeklyTiming(day: String, openTime: String, closeTime: String, isOpen: Boolean) {
        _weeklyTimings.update { list ->
            list.map { if (it.day == day) it.copy(openTime = openTime, closeTime = closeTime, isOpen = isOpen) else it }
        }
        try {
            client.postgrest["weekly_timings"].update(
                {
                    set("open_time", openTime)
                    set("close_time", closeTime)
                    set("is_open", isOpen)
                }
            ) {
                filter {
                    eq("store_id", activeStoreId)
                    eq("day", day)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating weekly timing on Supabase", e)
        }
    }

    override suspend fun simulateIncomingOrder(): Order {
        val orderNum = Random.nextInt(2001, 2999)
        val dbOrder = DbOrder(
            orderNumber = "#$orderNum",
            storeId = activeStoreId,
            customerName = "Live Customer #${orderNum % 100}",
            status = "PLACED",
            totalAmount = 399.0,
            deliveryAddress = "Indiranagar, Block 3",
            paymentType = "Online",
            items = listOf(
                DbOrderItem("Special Biryani", 1, 299),
                DbOrderItem("Fresh Lime Soda", 2, 50)
            )
        )

        try {
            client.postgrest["orders"].insert(dbOrder)
        } catch (e: Exception) {
            Log.e(TAG, "Error inserting simulated order to Supabase", e)
        }

        val newOrder = dbOrder.toDomain()
        firebaseRealtimeRepository.broadcastOrderState(
            LiveOrderState(
                orderId = newOrder.id,
                status = "PLACED"
            )
        )
        _orders.update { listOf(newOrder) + it }
        _newOrderAlertFlow.emit(newOrder)
        return newOrder
    }

    companion object {
        private const val TAG = "SupabaseRestaurantRepo"
    }
}
