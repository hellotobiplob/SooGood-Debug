package `in`.soogood.restaurant.data.remote

import `in`.soogood.restaurant.data.model.MenuItem
import `in`.soogood.restaurant.data.model.NotificationItem
import `in`.soogood.restaurant.data.model.Offer
import `in`.soogood.restaurant.data.model.Order
import `in`.soogood.restaurant.data.model.OrderItem
import `in`.soogood.restaurant.data.model.OrderStatus
import `in`.soogood.restaurant.data.model.Payout
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.Review
import `in`.soogood.restaurant.data.model.WeeklyTiming
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class DbStore(
    val id: String? = null,
    @SerialName("parent_store_id") val parentStoreId: String? = null,
    @SerialName("owner_user_id") val ownerUserId: String? = null,
    @SerialName("login_id") val loginId: String? = null,
    val name: String = "",
    @SerialName("store_type") val storeType: String = "RESTAURANT",
    val address: String = "",
    val area: String? = null,
    val city: String? = null,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val phone: String = "",
    val email: String? = null,
    @SerialName("owner_name") val ownerName: String? = null,
    val cuisine: String? = null,
    val fssai: String? = null,
    @SerialName("fssai_number") val fssaiNumber: String? = null,
    val gst: String? = null,
    @SerialName("bank_account") val bankAccount: String? = null,
    @SerialName("bank_account_number") val bankAccountNumber: String? = null,
    val ifsc: String? = null,
    @SerialName("ifsc_code") val ifscCode: String? = null,
    @SerialName("bank_holder") val bankHolder: String? = null,
    @SerialName("open_time") val openTime: String? = null,
    @SerialName("close_time") val closeTime: String? = null,
    @SerialName("opening_time") val openingTime: String? = "10:00 AM",
    @SerialName("closing_time") val closingTime: String? = "11:00 PM",
    @SerialName("image_url") val imageUrl: String? = null,
    val status: String = "APPROVED",
    @SerialName("is_open") val isOpen: Boolean = true
) {
    fun toDomainRestaurantInfo(): RestaurantInfo {
        val effectiveAddress = buildString {
            if (address.isNotBlank()) append(address)
            if (!area.isNullOrBlank()) {
                if (isNotEmpty()) append(", ")
                append(area)
            }
            if (!city.isNullOrBlank() && city != area) {
                if (isNotEmpty()) append(", ")
                append(city)
            }
        }.ifBlank { "Location not set" }

        val effectiveFssai = fssaiNumber?.ifBlank { null } ?: fssai ?: ""
        val effectiveBankAccount = bankAccountNumber?.ifBlank { null } ?: bankAccount ?: ""
        val effectiveIfsc = ifscCode?.ifBlank { null } ?: ifsc ?: ""
        val effectiveOpening = openTime?.ifBlank { null } ?: openingTime ?: "10:00 AM"
        val effectiveClosing = closeTime?.ifBlank { null } ?: closingTime ?: "11:00 PM"

        return RestaurantInfo(
            id = id ?: "rest_001",
            parentStoreId = parentStoreId,
            name = name.ifBlank { "Bake N Bite" },
            ownerName = ownerName ?: "Store Manager",
            phone = phone,
            email = email ?: "",
            address = effectiveAddress,
            cuisine = cuisine ?: "Restaurant",
            fssai = effectiveFssai,
            gst = gst,
            bankAccount = effectiveBankAccount,
            ifsc = effectiveIfsc,
            openingTime = effectiveOpening,
            closingTime = effectiveClosing,
            imageUrl = imageUrl,
            status = status
        )
    }
}

@Serializable
data class DbMenuItem(
    val id: String? = null,
    @SerialName("store_id") val storeId: String,
    val name: String,
    val description: String? = null,
    val price: Double,
    val category: String,
    @SerialName("is_available") val isAvailable: Boolean = true,
    @SerialName("is_veg") val isVeg: Boolean = true,
    @SerialName("prep_time_mins") val prepTimeMins: Int = 20,
    @SerialName("quantity_value") val quantityValue: String? = null,
    @SerialName("quantity_unit") val quantityUnit: String? = null,
    @SerialName("photo_url") val photoUrl: String? = null,
    @SerialName("image_url") val imageUrl: String? = null
) {
    fun toDomain(): MenuItem {
        return MenuItem(
            id = id ?: "",
            name = name,
            category = category,
            price = price.toInt(),
            veg = isVeg,
            inStock = isAvailable,
            description = description ?: "",
            prepTimeMins = prepTimeMins,
            quantityValue = quantityValue ?: "",
            quantityUnit = quantityUnit ?: "",
            photoUrl = photoUrl ?: imageUrl
        )
    }
}

fun MenuItem.toDb(storeId: String): DbMenuItem {
    return DbMenuItem(
        id = id.ifEmpty { null },
        storeId = storeId,
        name = name,
        description = description,
        price = price.toDouble(),
        category = category,
        isAvailable = inStock,
        isVeg = veg,
        prepTimeMins = prepTimeMins,
        quantityValue = quantityValue.ifBlank { null },
        quantityUnit = quantityUnit.ifBlank { null },
        photoUrl = photoUrl,
        imageUrl = photoUrl
    )
}

@Serializable
data class DbOrderItem(
    val name: String = "",
    val qty: Int = 1,
    val price: Int = 0
)

@Serializable
data class DbOrder(
    val id: String? = null,
    @SerialName("order_number") val orderNumber: String? = null,
    @SerialName("store_id") val storeId: String? = null,
    @SerialName("customer_name") val customerName: String? = null,
    val status: String? = "PLACED",
    @SerialName("total_amount") val totalAmount: Double? = null,
    val total: Double? = null,
    @SerialName("grand_total") val grandTotal: Double? = null,
    @SerialName("delivery_address") val deliveryAddress: String? = null,
    @SerialName("payment_type") val paymentType: String? = "Online",
    val note: String? = null,
    @SerialName("prep_time_adjust_mins") val prepTimeAdjustMins: Int? = 0,
    @SerialName("rejection_reason") val rejectionReason: String? = null,
    @SerialName("is_missed") val isMissed: Boolean? = false,
    @SerialName("created_at") val createdAt: String? = null,
    val items: List<DbOrderItem>? = null
) {
    fun toDomain(): Order {
        val rawStatus = status ?: "PLACED"
        val domainStatus = try {
            OrderStatus.valueOf(rawStatus.uppercase())
        } catch (e: Exception) {
            OrderStatus.PLACED
        }

        val effectiveItems = items?.map { OrderItem(it.name, it.qty, it.price) } ?: emptyList()

        val displayId = if (!orderNumber.isNullOrBlank()) orderNumber else (id ?: "#1001")

        return Order(
            id = displayId,
            customerName = customerName ?: "Customer",
            items = effectiveItems,
            status = domainStatus,
            minsAgo = 0,
            note = note,
            paymentType = paymentType ?: "Online",
            deliveryAddressSnippet = deliveryAddress ?: "Delivery Address",
            prepTimeAdjustMins = prepTimeAdjustMins ?: 0,
            rejectionReason = rejectionReason,
            isMissed = isMissed ?: false
        )
    }
}

@Serializable
data class DbOffer(
    val id: String? = null,
    @SerialName("store_id") val storeId: String,
    val code: String,
    val title: String,
    @SerialName("discount_type") val discountType: String = "PERCENTAGE",
    @SerialName("discount_value") val discountValue: Int,
    @SerialName("min_order_value") val minOrderValue: Int,
    @SerialName("valid_until") val validUntil: String,
    @SerialName("is_active") val isActive: Boolean = true
) {
    fun toDomain(): Offer {
        return Offer(
            id = id ?: "",
            code = code,
            title = title,
            discountType = discountType,
            discountValue = discountValue,
            minOrderValue = minOrderValue,
            validUntil = validUntil,
            isActive = isActive
        )
    }
}

fun Offer.toDb(storeId: String): DbOffer {
    return DbOffer(
        id = id.ifEmpty { null },
        storeId = storeId,
        code = code,
        title = title,
        discountType = discountType,
        discountValue = discountValue,
        minOrderValue = minOrderValue,
        validUntil = validUntil,
        isActive = isActive
    )
}

@Serializable
data class DbReview(
    val id: String? = null,
    @SerialName("store_id") val storeId: String = "",
    @SerialName("customer_name") val customerName: String,
    val rating: Int,
    val date: String = "",
    val comment: String = "",
    @SerialName("item_names") val itemNames: String = "",
    val reply: String? = null
) {
    fun toDomain(): Review {
        return Review(
            id = id ?: "",
            customerName = customerName,
            rating = rating,
            date = date,
            comment = comment,
            itemNames = itemNames,
            reply = reply
        )
    }
}

@Serializable
data class DbPayout(
    val id: String? = null,
    @SerialName("store_id") val storeId: String = "",
    val date: String,
    val amount: Int,
    val status: String = "Settled",
    @SerialName("bank_account_snippet") val bankAccountSnippet: String = "•••• 4829"
) {
    fun toDomain(): Payout {
        return Payout(
            id = id ?: "",
            date = date,
            amount = amount,
            status = status,
            bankAccountSnippet = bankAccountSnippet
        )
    }
}

@Serializable
data class DbNotification(
    val id: String? = null,
    @SerialName("store_id") val storeId: String = "",
    val title: String,
    val message: String,
    val timestamp: String,
    @SerialName("is_read") val isRead: Boolean = false,
    val type: String = "ORDER"
) {
    fun toDomain(): NotificationItem {
        return NotificationItem(
            id = id ?: "",
            title = title,
            message = message,
            timestamp = timestamp,
            isRead = isRead,
            type = type
        )
    }
}

@Serializable
data class DbWeeklyTiming(
    val id: String? = null,
    @SerialName("store_id") val storeId: String = "",
    val day: String,
    @SerialName("open_time") val openTime: String,
    @SerialName("close_time") val closeTime: String,
    @SerialName("is_open") val isOpen: Boolean = true
) {
    fun toDomain(): WeeklyTiming {
        return WeeklyTiming(
            day = day,
            openTime = openTime,
            closeTime = closeTime,
            isOpen = isOpen
        )
    }
}

@Serializable
data class DbCallSignal(
    val id: String? = null,
    @SerialName("order_id") val orderId: String,
    @SerialName("caller_role") val callerRole: String,
    @SerialName("receiver_role") val receiverRole: String,
    @SerialName("sdp_offer") val sdpOffer: String? = null,
    @SerialName("sdp_answer") val sdpAnswer: String? = null,
    @SerialName("call_status") val callStatus: String = "RINGING",
    @SerialName("created_at") val createdAt: String? = null
)
