package `in`.soogood.restaurant.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.restaurant.data.model.BarChartPoint
import `in`.soogood.restaurant.ui.theme.SooGoodBrand
import `in`.soogood.restaurant.ui.theme.SooGoodBrandDark

@Composable
fun EarningsBarChart(
    points: List<BarChartPoint>,
    modifier: Modifier = Modifier
) {
    if (points.isEmpty()) return

    val maxAmount = points.maxOfOrNull { it.amount }?.takeIf { it > 0 } ?: 1.0

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) {
        Text(
            text = "Revenue Overview",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = MaterialTheme.colorScheme.onSurface
        )

        Spacer(modifier = Modifier.height(16.dp))

        Canvas(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
        ) {
            val canvasWidth = size.width
            val canvasHeight = size.height
            val bottomPadding = 40f
            val topPadding = 30f
            val availableHeight = canvasHeight - bottomPadding - topPadding

            val barCount = points.size
            val barSpacing = canvasWidth / (barCount * 1.8f)
            val barWidth = (canvasWidth - (barSpacing * (barCount + 1))) / barCount

            // Draw gridline background
            val gridColor = Color.Gray.copy(alpha = 0.2f)
            drawLine(
                color = gridColor,
                start = Offset(0f, topPadding),
                end = Offset(canvasWidth, topPadding),
                strokeWidth = 1f
            )
            drawLine(
                color = gridColor,
                start = Offset(0f, topPadding + availableHeight / 2f),
                end = Offset(canvasWidth, topPadding + availableHeight / 2f),
                strokeWidth = 1f
            )
            drawLine(
                color = gridColor,
                start = Offset(0f, canvasHeight - bottomPadding),
                end = Offset(canvasWidth, canvasHeight - bottomPadding),
                strokeWidth = 1.5f
            )

            // Draw Bars and Labels
            points.forEachIndexed { index, point ->
                val barHeight = ((point.amount / maxAmount) * availableHeight).toFloat()
                val left = barSpacing + index * (barWidth + barSpacing)
                val top = canvasHeight - bottomPadding - barHeight

                // Gradient bar
                drawRoundRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(SooGoodBrand, SooGoodBrandDark)
                    ),
                    topLeft = Offset(left, top),
                    size = Size(barWidth, barHeight),
                    cornerRadius = CornerRadius(12f, 12f)
                )

                // Label below bar
                drawContext.canvas.nativeCanvas.apply {
                    val paint = android.graphics.Paint().apply {
                        color = android.graphics.Color.GRAY
                        textSize = 28f
                        textAlign = android.graphics.Paint.Align.CENTER
                    }
                    drawText(
                        point.label,
                        left + barWidth / 2f,
                        canvasHeight - 8f,
                        paint
                    )

                    if (point.amount > 0) {
                        val valPaint = android.graphics.Paint().apply {
                            color = android.graphics.Color.DKGRAY
                            textSize = 24f
                            textAlign = android.graphics.Paint.Align.CENTER
                            isFakeBoldText = true
                        }
                        drawText(
                            "₹${point.amount.toInt()}",
                            left + barWidth / 2f,
                            top - 8f,
                            valPaint
                        )
                    }
                }
            }
        }
    }
}
