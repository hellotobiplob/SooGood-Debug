package `in`.soogood.restaurant.di

import `in`.soogood.restaurant.data.repository.AuthRepository
import `in`.soogood.restaurant.data.repository.FirebaseAuthRepository
import `in`.soogood.restaurant.data.repository.FirebaseRestaurantRepository
import `in`.soogood.restaurant.data.repository.RestaurantRepository

/**
 * Simple Manual AppContainer for Dependency Wiring.
 * Connects Google Firebase RTDB Repositories.
 */
class AppContainer {
    val authRepository: AuthRepository by lazy {
        FirebaseAuthRepository()
    }

    val restaurantRepository: RestaurantRepository by lazy {
        FirebaseRestaurantRepository()
    }
}
