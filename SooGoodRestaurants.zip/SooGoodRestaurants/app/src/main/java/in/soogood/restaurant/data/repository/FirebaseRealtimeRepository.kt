package `in`.soogood.restaurant.data.repository

import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

data class LiveOrderState(
    val orderId: String = "",
    val status: String = "PLACED",
    val riderId: String? = null,
    val riderName: String? = null,
    val riderPhone: String? = null,
    val riderLat: Double? = null,
    val riderLng: Double? = null,
    val estimatedDeliveryMinutes: Int = 30,
    val deliveryOtp: String = "",
    val rejectionReason: String? = null,
    val updatedAt: Long = System.currentTimeMillis()
)

class FirebaseRealtimeRepository {

    private fun getDbRef(): DatabaseReference {
        return FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com")
            .getReference("live_orders")
    }

    fun broadcastOrderState(state: LiveOrderState) {
        if (state.orderId.isBlank()) return
        val updates = mutableMapOf<String, Any>(
            "orderId" to state.orderId,
            "status" to state.status,
            "estimatedDeliveryMinutes" to state.estimatedDeliveryMinutes,
            "updatedAt" to System.currentTimeMillis()
        )
        if (!state.riderId.isNullOrBlank()) updates["riderId"] = state.riderId
        if (!state.riderName.isNullOrBlank()) updates["riderName"] = state.riderName
        if (!state.riderPhone.isNullOrBlank()) updates["riderPhone"] = state.riderPhone
        if (state.riderLat != null) updates["riderLat"] = state.riderLat
        if (state.riderLng != null) updates["riderLng"] = state.riderLng
        if (state.deliveryOtp.isNotBlank()) updates["deliveryOtp"] = state.deliveryOtp
        if (!state.rejectionReason.isNullOrBlank()) updates["rejectionReason"] = state.rejectionReason

        getDbRef().child(state.orderId).updateChildren(updates)
            .addOnSuccessListener {
                Log.d(TAG, "Successfully broadcasted live order state for ${state.orderId}: ${state.status}")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to broadcast live order state for ${state.orderId}", e)
            }
    }

    fun broadcastStatusUpdate(
        orderId: String,
        status: String,
        rejectionReason: String? = null,
        prepTimeMins: Int? = null
    ) {
        if (orderId.isBlank()) return
        val updates = mutableMapOf<String, Any>(
            "status" to status,
            "updatedAt" to System.currentTimeMillis()
        )
        if (!rejectionReason.isNullOrBlank()) {
            updates["rejectionReason"] = rejectionReason
        }
        if (prepTimeMins != null) {
            updates["estimatedDeliveryMinutes"] = prepTimeMins
        }

        getDbRef().child(orderId).updateChildren(updates)
            .addOnSuccessListener {
                Log.d(TAG, "Successfully updated live order status for $orderId to $status")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Failed to update live order status for $orderId", e)
            }
    }

    fun observeLiveOrder(orderId: String): Flow<LiveOrderState?> = callbackFlow {
        if (orderId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    trySend(null)
                    return
                }

                try {
                    val status = snapshot.child("status").getValue(String::class.java) ?: "PLACED"
                    val riderId = snapshot.child("riderId").getValue(String::class.java)
                    val riderName = snapshot.child("riderName").getValue(String::class.java)
                    val riderPhone = snapshot.child("riderPhone").getValue(String::class.java)
                    val riderLat = snapshot.child("riderLat").getValue(Double::class.java)
                    val riderLng = snapshot.child("riderLng").getValue(Double::class.java)
                    val eta = snapshot.child("estimatedDeliveryMinutes").getValue(Int::class.java) ?: 30
                    val otp = snapshot.child("deliveryOtp").getValue(String::class.java) ?: ""
                    val rej = snapshot.child("rejectionReason").getValue(String::class.java)
                    val time = snapshot.child("updatedAt").getValue(Long::class.java) ?: System.currentTimeMillis()

                    val liveState = LiveOrderState(
                        orderId = orderId,
                        status = status,
                        riderId = riderId,
                        riderName = riderName,
                        riderPhone = riderPhone,
                        riderLat = riderLat,
                        riderLng = riderLng,
                        estimatedDeliveryMinutes = eta,
                        deliveryOtp = otp,
                        rejectionReason = rej,
                        updatedAt = time
                    )
                    trySend(liveState)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing live order snapshot", e)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Live order listener cancelled: ${error.message}")
            }
        }

        getDbRef().child(orderId).addValueEventListener(listener)

        awaitClose {
            getDbRef().child(orderId).removeEventListener(listener)
        }
    }

    companion object {
        private const val TAG = "FirebaseRealtimeRepo"
    }
}
