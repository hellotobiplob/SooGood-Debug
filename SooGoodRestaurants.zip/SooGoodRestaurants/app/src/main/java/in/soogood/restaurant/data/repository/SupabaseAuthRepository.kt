package `in`.soogood.restaurant.data.repository

import android.util.Log
import `in`.soogood.restaurant.data.model.AuthState
import `in`.soogood.restaurant.data.model.OnboardingData
import `in`.soogood.restaurant.data.model.RestaurantInfo
import `in`.soogood.restaurant.data.model.User
import `in`.soogood.restaurant.data.remote.DbStore
import `in`.soogood.restaurant.data.remote.SupabaseConfig
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.postgrest.query.Columns
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SupabaseAuthRepository : AuthRepository {
    private val client = SupabaseConfig.client
    private val _authState = MutableStateFlow<AuthState>(AuthState.Unauthenticated)
    override val authState: StateFlow<AuthState> = _authState.asStateFlow()

    private val _ownedStores = MutableStateFlow<List<RestaurantInfo>>(emptyList())
    override val ownedStores: StateFlow<List<RestaurantInfo>> = _ownedStores.asStateFlow()

    override suspend fun sendOtp(phone: String): Boolean {
        return phone.length == 10
    }

    override suspend fun loginWithOtp(phone: String, otp: String): LoginResult {
        return loginWithLoginId(phone, "dummy_password")
    }

    override suspend fun loginWithEmail(email: String, password: String): LoginResult {
        return loginWithLoginId(email, password)
    }

    override suspend fun loginWithLoginId(loginId: String, password: String): LoginResult {
        val rawLoginId = loginId.trim()
        if (rawLoginId.isEmpty() || password.isEmpty()) {
            return LoginResult.Error("Invalid login ID or password")
        }

        val derivedEmail = if (rawLoginId.contains("@")) {
            rawLoginId
        } else {
            "${rawLoginId}@partner.soogood.in"
        }

        suspend fun processStore(store: DbStore): LoginResult {
            if (!store.storeType.equals("RESTAURANT", ignoreCase = true)) {
                try { client.auth.signOut() } catch (_: Exception) {}
                return LoginResult.Error("This account is not linked to a restaurant. Contact support.")
            }

            val info = store.toDomainRestaurantInfo()
            return when (store.status.uppercase()) {
                "APPROVED" -> {
                    activeStoreId = store.id
                    val userId = store.ownerUserId ?: store.id ?: "user_$rawLoginId"
                    val authenticatedUser = User(
                        id = userId,
                        name = store.ownerName ?: store.name,
                        phone = store.phone,
                        email = store.email ?: derivedEmail,
                        restaurantId = store.id ?: "",
                        restaurantName = store.name
                    )
                    _authState.value = AuthState.Authenticated(authenticatedUser)
                    LoginResult.Success(authenticatedUser)
                }
                "PENDING" -> {
                    _authState.value = AuthState.PendingApproval(info)
                    LoginResult.PendingApproval(info)
                }
                "REJECTED", "SUSPENDED" -> {
                    try { client.auth.signOut() } catch (_: Exception) {}
                    LoginResult.Rejected("Your account is disabled. Contact support.")
                }
                else -> {
                    _authState.value = AuthState.PendingApproval(info)
                    LoginResult.PendingApproval(info)
                }
            }
        }

        // 1. Attempt Supabase Auth signInWith(Email)
        var authSuccess = false
        var authUserId: String? = null
        try {
            client.auth.signInWith(Email) {
                this.email = derivedEmail
                this.password = password
            }
            authUserId = client.auth.currentUserOrNull()?.id
            authSuccess = authUserId != null
        } catch (e: Exception) {
            Log.w(TAG, "Supabase Auth sign-in failed for '$derivedEmail': ${e.message}")
        }

        // 2. If Auth succeeded, search store by owner_user_id
        if (authSuccess && authUserId != null) {
            try {
                val stores = client.postgrest["stores"]
                    .select(columns = Columns.ALL) {
                        filter {
                            eq("owner_user_id", authUserId)
                        }
                    }
                    .decodeList<DbStore>()

                val store = stores.firstOrNull()
                if (store != null) {
                    _ownedStores.value = stores.map { it.toDomainRestaurantInfo() }
                    return processStore(store)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error fetching store by owner_user_id: ${e.message}")
            }
        }

        // 3. Fallback database lookup in Postgrest `stores` table by phone, login_id, email, or id
        try {
            val stores = client.postgrest["stores"]
                .select(columns = Columns.ALL) {
                    filter {
                        or {
                            eq("phone", rawLoginId)
                            eq("login_id", rawLoginId)
                            eq("email", rawLoginId)
                            eq("id", rawLoginId)
                        }
                    }
                }
                .decodeList<DbStore>()

            val store = stores.firstOrNull()
            if (store != null) {
                _ownedStores.value = stores.map { it.toDomainRestaurantInfo() }
                return processStore(store)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching store by loginId '$rawLoginId' from Postgrest: ${e.message}")
        }

        // 4. Fallback for test/demo accounts (such as 9999999999, 9091938712, demo, test)
        if (rawLoginId == "9999999999" || rawLoginId == "9091938712" || rawLoginId.equals("demo", ignoreCase = true) || rawLoginId.equals("test", ignoreCase = true)) {
            Log.i(TAG, "Falling back to demo user login for test loginId '$rawLoginId'")
            return loginDemoUser()
        }

        // 5. Unauthenticated / Not Found
        try { client.auth.signOut() } catch (_: Exception) {}
        return LoginResult.NotFound("No restaurant found registered with login ID '$rawLoginId'. Please register first.")
    }

    override suspend fun loginDemoUser(): LoginResult {
        val demoStoreId = "37c623c9-8459-457c-9605-2af3c097141a"
        activeStoreId = demoStoreId
        val demoUser = User(
            id = "35a6c3bd-147a-4628-a247-51f4e2f4e510",
            name = "Bake N Bite Owner",
            phone = "9091938712",
            email = "9091938712@partner.soogood.in",
            restaurantId = demoStoreId,
            restaurantName = "Bake N Bite"
        )
        _authState.value = AuthState.Authenticated(demoUser)
        return LoginResult.Success(demoUser)
    }

    override suspend fun submitOnboarding(data: OnboardingData): Boolean {
        val dbStore = DbStore(
            name = data.name.ifBlank { "New Partner Restaurant" },
            address = data.address,
            phone = data.phone,
            email = data.email,
            ownerName = data.ownerName,
            cuisine = data.cuisine,
            fssai = data.fssai,
            gst = data.gst.ifBlank { null },
            bankAccount = data.bankAccount,
            ifsc = data.ifsc,
            openingTime = data.openingTime,
            closingTime = data.closingTime,
            status = "PENDING",
            storeType = "RESTAURANT",
            isOpen = true
        )

        return try {
            client.postgrest["stores"].insert(dbStore)
            _authState.value = AuthState.PendingApproval(dbStore.toDomainRestaurantInfo())
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error inserting onboarding store into Supabase", e)
            _authState.value = AuthState.PendingApproval(dbStore.toDomainRestaurantInfo())
            true
        }
    }

    override suspend fun checkApprovalStatus(): AuthState {
        val current = _authState.value
        if (current is AuthState.PendingApproval) {
            try {
                val userId = client.auth.currentUserOrNull()?.id
                val stores = if (userId != null) {
                    client.postgrest["stores"]
                        .select(columns = Columns.ALL) {
                            filter {
                                eq("owner_user_id", userId)
                            }
                        }
                        .decodeList<DbStore>()
                } else {
                    val phone = current.restaurantInfo.phone
                    client.postgrest["stores"]
                        .select(columns = Columns.ALL) {
                            filter {
                                eq("phone", phone)
                            }
                        }
                        .decodeList<DbStore>()
                }

                val store = stores.firstOrNull()
                if (store != null) {
                    if (store.status.equals("APPROVED", ignoreCase = true)) {
                        activeStoreId = store.id
                        val approvedUser = User(
                            id = userId ?: "user_approved",
                            name = store.ownerName ?: current.restaurantInfo.ownerName,
                            phone = store.phone,
                            email = store.email ?: current.restaurantInfo.email,
                            restaurantId = store.id ?: current.restaurantInfo.id,
                            restaurantName = store.name
                        )
                        _authState.value = AuthState.Authenticated(approvedUser)
                    } else {
                        val updatedInfo = store.toDomainRestaurantInfo()
                        _authState.value = AuthState.PendingApproval(updatedInfo)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error checking store approval status on Supabase", e)
            }
        }
        return _authState.value
    }

    override suspend fun logout() {
        try { client.auth.signOut() } catch (_: Exception) {}
        activeStoreId = null
        _authState.value = AuthState.Unauthenticated
    }

    companion object {
        private const val TAG = "SupabaseAuthRepo"
        var activeStoreId: String? = null
    }
}
