package `in`.soogood.restaurant.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object Onboarding : Screen("onboarding")
    object PendingApproval : Screen("pending_approval")
    object MainShell : Screen("main_shell")
    object OrderDetails : Screen("order_details/{orderId}") {
        fun createRoute(orderId: String) = "order_details/$orderId"
    }
    object Reviews : Screen("reviews")
    object Offers : Screen("offers")
    object Notifications : Screen("notifications")
}
