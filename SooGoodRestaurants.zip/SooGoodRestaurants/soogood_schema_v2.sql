-- ============================================================================
-- SOOGOOD PLATFORM UNIFIED SUPABASE DATABASE MIGRATION SCRIPT (v2.1)
-- Location Focus: Nazirpur, Nadia, West Bengal
-- Connects: SooGood (Customer), SooGoodRider (Rider), SooGoodRestaurants (Restaurant)
-- and Web Operations Admin Portal (`index(3).html`).
-- ============================================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ----------------------------------------------------------------------------
-- 1. PROFILES & ROLES
-- Unified user table mapping Customer, Rider, and Restaurant Owner credentials
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS profiles CASCADE;
CREATE TABLE profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name TEXT NOT NULL,
    phone TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE,
    role TEXT NOT NULL DEFAULT 'customer' CHECK (role IN ('customer', 'rider', 'restaurant_owner', 'admin', 'ops', 'support', 'finance')),
    avatar_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 2. STORES & KITCHENS (With Multi-Restaurant & Branch Support)
-- Default Location: Nazirpur, Nadia, West Bengal
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS stores CASCADE;
CREATE TABLE stores (
    id TEXT PRIMARY KEY DEFAULT ('rest_' || gen_random_uuid()),
    parent_store_id TEXT REFERENCES stores(id) ON DELETE SET NULL,
    owner_user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    login_id TEXT UNIQUE,
    name TEXT NOT NULL,
    store_type TEXT NOT NULL DEFAULT 'RESTAURANT' CHECK (store_type IN ('RESTAURANT', 'DARKSTORE')),
    address TEXT NOT NULL,
    area TEXT DEFAULT 'Nazirpur',
    city TEXT DEFAULT 'Nazirpur, Nadia',
    latitude DOUBLE PRECISION DEFAULT 23.9922,
    longitude DOUBLE PRECISION DEFAULT 88.5833,
    phone TEXT NOT NULL,
    email TEXT,
    owner_name TEXT,
    cuisine TEXT,
    fssai TEXT,
    fssai_number TEXT,
    gst TEXT,
    bank_account TEXT,
    bank_account_number TEXT,
    ifsc TEXT,
    ifsc_code TEXT,
    bank_holder TEXT,
    open_time TEXT DEFAULT '09:00',
    close_time TEXT DEFAULT '23:00',
    opening_time TEXT DEFAULT '10:00 AM',
    closing_time TEXT DEFAULT '11:00 PM',
    image_url TEXT,
    status TEXT NOT NULL DEFAULT 'APPROVED' CHECK (status IN ('APPROVED', 'PENDING', 'REJECTED', 'SUSPENDED')),
    is_open BOOLEAN DEFAULT TRUE,
    commission_pct NUMERIC DEFAULT 18.0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 3. RIDERS & FLEET PARTNERS
-- Default Location: Nazirpur, Nadia, West Bengal
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS riders CASCADE;
CREATE TABLE riders (
    id TEXT PRIMARY KEY DEFAULT ('rider_' || gen_random_uuid()),
    user_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    partner_code TEXT UNIQUE NOT NULL,
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    emergency_contact TEXT,
    address TEXT,
    city TEXT DEFAULT 'Nazirpur, Nadia',
    verification_status TEXT DEFAULT 'verified' CHECK (verification_status IN ('verified', 'pending', 'rejected')),
    vehicle_type TEXT DEFAULT 'bike' CHECK (vehicle_type IN ('bike', 'scooter', 'ev_bike', 'bicycle')),
    vehicle_number TEXT NOT NULL,
    dl_number TEXT,
    aadhaar_number TEXT,
    pan_number TEXT,
    photo_url TEXT,
    bank_holder TEXT,
    bank_account_number TEXT,
    ifsc_code TEXT,
    upi_id TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    current_status TEXT DEFAULT 'idle' CHECK (current_status IN ('idle', 'busy', 'offline')),
    rating NUMERIC DEFAULT 4.9,
    total_trips_completed INT DEFAULT 0,
    current_latitude DOUBLE PRECISION DEFAULT 23.9922,
    current_longitude DOUBLE PRECISION DEFAULT 88.5833,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 4. ORDERS & DISPATCH
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS orders CASCADE;
CREATE TABLE orders (
    id TEXT PRIMARY KEY DEFAULT ('ORD_' || gen_random_uuid()),
    order_number TEXT UNIQUE NOT NULL,
    customer_id UUID REFERENCES profiles(id) ON DELETE SET NULL,
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    rider_id TEXT REFERENCES riders(id) ON DELETE SET NULL,
    status TEXT NOT NULL DEFAULT 'PLACED',
    subtotal_amount NUMERIC NOT NULL DEFAULT 0.0,
    delivery_fee NUMERIC NOT NULL DEFAULT 30.0,
    total_amount NUMERIC NOT NULL DEFAULT 0.0,
    payment_type TEXT DEFAULT 'ONLINE',
    is_paid BOOLEAN DEFAULT TRUE,
    customer_name TEXT NOT NULL,
    customer_phone TEXT,
    delivery_address TEXT NOT NULL,
    delivery_latitude DOUBLE PRECISION DEFAULT 23.9922,
    delivery_longitude DOUBLE PRECISION DEFAULT 88.5833,
    customer_otp TEXT NOT NULL DEFAULT '1234',
    order_type TEXT DEFAULT 'food' CHECK (order_type IN ('food', 'grocery')),
    prep_time_adjust_mins INT DEFAULT 0,
    rejection_reason TEXT,
    is_missed BOOLEAN DEFAULT FALSE,
    rider_name TEXT,
    rider_lat DOUBLE PRECISION,
    rider_lng DOUBLE PRECISION,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 5. ORDER LINE ITEMS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS order_items CASCADE;
CREATE TABLE order_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id TEXT REFERENCES orders(id) ON DELETE CASCADE,
    item_name TEXT NOT NULL,
    quantity INT NOT NULL DEFAULT 1,
    unit_price NUMERIC NOT NULL DEFAULT 0.0,
    subtotal NUMERIC NOT NULL DEFAULT 0.0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 6. DISHES & MENUS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS menu_items CASCADE;
CREATE TABLE menu_items (
    id TEXT PRIMARY KEY DEFAULT ('menu_' || gen_random_uuid()),
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    name TEXT NOT NULL,
    description TEXT,
    price NUMERIC NOT NULL DEFAULT 0.0,
    category TEXT NOT NULL DEFAULT 'General',
    is_available BOOLEAN DEFAULT TRUE,
    is_veg BOOLEAN DEFAULT TRUE,
    prep_time_mins INT DEFAULT 20,
    quantity_value TEXT,
    quantity_unit TEXT,
    photo_url TEXT,
    image_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 7. DARKSTORE INVENTORY SKUS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS inventory CASCADE;
CREATE TABLE inventory (
    id TEXT PRIMARY KEY DEFAULT ('inv_' || gen_random_uuid()),
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    store_name TEXT,
    product_name TEXT NOT NULL,
    sku TEXT UNIQUE NOT NULL,
    quantity INT NOT NULL DEFAULT 100,
    low_stock_threshold INT DEFAULT 15,
    unit TEXT DEFAULT 'Pack',
    price NUMERIC DEFAULT 0.0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 8. BANNERS & CAROUSELS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS banners CASCADE;
CREATE TABLE banners (
    id TEXT PRIMARY KEY DEFAULT ('ban_' || gen_random_uuid()),
    title TEXT NOT NULL,
    subtitle TEXT,
    image_url TEXT NOT NULL,
    placement TEXT DEFAULT 'home_top',
    sort_order INT DEFAULT 0,
    link_type TEXT DEFAULT 'none',
    link_value TEXT,
    starts_at TIMESTAMPTZ,
    ends_at TIMESTAMPTZ,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 9. OFFERS & PROMO CODES
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS offers CASCADE;
CREATE TABLE offers (
    id TEXT PRIMARY KEY DEFAULT ('off_' || gen_random_uuid()),
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    code TEXT NOT NULL,
    title TEXT NOT NULL,
    discount_type TEXT DEFAULT 'PERCENTAGE',
    discount_value INT NOT NULL,
    min_order_value INT DEFAULT 0,
    valid_until TEXT NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 10. REVIEWS & RATINGS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS reviews CASCADE;
CREATE TABLE reviews (
    id TEXT PRIMARY KEY DEFAULT ('rev_' || gen_random_uuid()),
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    customer_name TEXT NOT NULL,
    rating INT NOT NULL CHECK (rating BETWEEN 1 AND 5),
    date TEXT DEFAULT CURRENT_DATE::TEXT,
    comment TEXT,
    item_names TEXT,
    reply TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 11. FINANCIAL PAYOUTS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS payouts CASCADE;
CREATE TABLE payouts (
    id TEXT PRIMARY KEY DEFAULT ('pay_' || gen_random_uuid()),
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    rider_id TEXT REFERENCES riders(id) ON DELETE SET NULL,
    date TEXT NOT NULL,
    amount INT NOT NULL,
    status TEXT DEFAULT 'Settled',
    bank_account_snippet TEXT DEFAULT '•••• 4829',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 12. PUSH BROADCAST NOTIFICATIONS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS push_notifications CASCADE;
DROP TABLE IF EXISTS notifications CASCADE;
CREATE TABLE push_notifications (
    id TEXT PRIMARY KEY DEFAULT ('notif_' || gen_random_uuid()),
    store_id TEXT,
    audience TEXT DEFAULT 'all',
    title TEXT NOT NULL,
    message TEXT,
    body TEXT,
    image_url TEXT,
    timestamp TIMESTAMPTZ DEFAULT NOW(),
    is_read BOOLEAN DEFAULT FALSE,
    type TEXT DEFAULT 'ORDER',
    status TEXT DEFAULT 'sent',
    sent_count INT DEFAULT 1,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE notifications AS SELECT * FROM push_notifications WITH NO DATA;

-- ----------------------------------------------------------------------------
-- 13. WEEKLY OPERATING HOURS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS weekly_timings CASCADE;
CREATE TABLE weekly_timings (
    id TEXT PRIMARY KEY DEFAULT ('wt_' || gen_random_uuid()),
    store_id TEXT REFERENCES stores(id) ON DELETE CASCADE,
    day TEXT NOT NULL,
    open_time TEXT NOT NULL,
    close_time TEXT NOT NULL,
    is_open BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 14. IN-APP CHAT MESSAGES
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS order_messages CASCADE;
CREATE TABLE order_messages (
    id TEXT PRIMARY KEY DEFAULT ('msg_' || gen_random_uuid()),
    order_id TEXT REFERENCES orders(id) ON DELETE CASCADE,
    sender_role TEXT NOT NULL CHECK (sender_role IN ('CUSTOMER', 'RIDER', 'RESTAURANT', 'ADMIN')),
    sender_id TEXT NOT NULL,
    text TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 15. REFUNDS & CLAIMS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS refunds CASCADE;
CREATE TABLE refunds (
    id TEXT PRIMARY KEY DEFAULT ('ref_' || gen_random_uuid()),
    order_id TEXT REFERENCES orders(id) ON DELETE CASCADE,
    customer_name TEXT NOT NULL,
    amount NUMERIC NOT NULL,
    reason TEXT NOT NULL,
    status TEXT DEFAULT 'requested' CHECK (status IN ('requested', 'approved', 'rejected')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 16. SUPPORT TICKETS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS support_tickets CASCADE;
CREATE TABLE support_tickets (
    id TEXT PRIMARY KEY DEFAULT ('tkt_' || gen_random_uuid()),
    user_id UUID,
    user_type TEXT DEFAULT 'customer',
    subject TEXT NOT NULL,
    message TEXT NOT NULL,
    status TEXT DEFAULT 'open' CHECK (status IN ('open', 'resolved', 'closed')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- 17. AUDIT LOGS
-- ----------------------------------------------------------------------------
DROP TABLE IF EXISTS audit_logs CASCADE;
CREATE TABLE audit_logs (
    id TEXT PRIMARY KEY DEFAULT ('log_' || gen_random_uuid()),
    admin_email TEXT NOT NULL,
    action TEXT NOT NULL,
    details TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ----------------------------------------------------------------------------
-- INDEXES FOR HIGH-PERFORMANCE QUERYING
-- ----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_orders_store_id ON orders(store_id);
CREATE INDEX IF NOT EXISTS idx_orders_rider_id ON orders(rider_id);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_order_number ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_menu_items_store_id ON menu_items(store_id);
CREATE INDEX IF NOT EXISTS idx_stores_owner_user_id ON stores(owner_user_id);
CREATE INDEX IF NOT EXISTS idx_stores_parent_store_id ON stores(parent_store_id);

-- ----------------------------------------------------------------------------
-- ADMIN ACCOUNT INITIALIZATION
-- Sets up default admin user: apeextechnologies@gmail.com
-- ----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS pgcrypto;

DO $$
DECLARE
    admin_uuid UUID;
BEGIN
    -- Check if user already exists in auth.users
    SELECT id INTO admin_uuid FROM auth.users WHERE email = 'apeextechnologies@gmail.com';

    IF admin_uuid IS NULL THEN
        admin_uuid := gen_random_uuid();

        INSERT INTO auth.users (
            id, instance_id, email, encrypted_password, email_confirmed_at,
            raw_app_meta_data, raw_user_meta_data, created_at, updated_at, role, aud
        ) VALUES (
            admin_uuid, '00000000-0000-0000-0000-000000000000', 'apeextechnologies@gmail.com',
            crypt('Mypass4me@', gen_salt('bf')), NOW(),
            '{"provider": "email", "providers": ["email"]}', '{"full_name": "SooGood Admin"}',
            NOW(), NOW(), 'authenticated', 'authenticated'
        );
    ELSE
        UPDATE auth.users
        SET encrypted_password = crypt('Mypass4me@', gen_salt('bf')),
            email_confirmed_at = COALESCE(email_confirmed_at, NOW()),
            updated_at = NOW()
        WHERE id = admin_uuid;
    END IF;

    -- Upsert into public.profiles with admin role
    INSERT INTO public.profiles (id, full_name, phone, email, role, updated_at)
    VALUES (admin_uuid, 'SooGood Central Admin', '+91 9800000000', 'apeextechnologies@gmail.com', 'admin', NOW())
    ON CONFLICT (id) DO UPDATE SET
        role = 'admin',
        full_name = EXCLUDED.full_name,
        email = EXCLUDED.email,
        updated_at = NOW();
END $$;

-- ----------------------------------------------------------------------------
-- ROW LEVEL SECURITY (RLS) POLICIES
-- Enables open read/write access for authenticated & app services
-- ----------------------------------------------------------------------------
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read profiles" ON profiles;
CREATE POLICY "Public read profiles" ON profiles FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write profiles" ON profiles;
CREATE POLICY "Public write profiles" ON profiles FOR ALL USING (true);

ALTER TABLE stores ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read stores" ON stores;
CREATE POLICY "Public read stores" ON stores FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write stores" ON stores;
CREATE POLICY "Public write stores" ON stores FOR ALL USING (true);

ALTER TABLE riders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read riders" ON riders;
CREATE POLICY "Public read riders" ON riders FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write riders" ON riders;
CREATE POLICY "Public write riders" ON riders FOR ALL USING (true);

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read orders" ON orders;
CREATE POLICY "Public read orders" ON orders FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write orders" ON orders;
CREATE POLICY "Public write orders" ON orders FOR ALL USING (true);

ALTER TABLE order_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read order_items" ON order_items;
CREATE POLICY "Public read order_items" ON order_items FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write order_items" ON order_items;
CREATE POLICY "Public write order_items" ON order_items FOR ALL USING (true);

ALTER TABLE menu_items ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read menu_items" ON menu_items;
CREATE POLICY "Public read menu_items" ON menu_items FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write menu_items" ON menu_items;
CREATE POLICY "Public write menu_items" ON menu_items FOR ALL USING (true);

ALTER TABLE inventory ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read inventory" ON inventory;
CREATE POLICY "Public read inventory" ON inventory FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write inventory" ON inventory;
CREATE POLICY "Public write inventory" ON inventory FOR ALL USING (true);

ALTER TABLE banners ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read banners" ON banners;
CREATE POLICY "Public read banners" ON banners FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write banners" ON banners;
CREATE POLICY "Public write banners" ON banners FOR ALL USING (true);

ALTER TABLE offers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read offers" ON offers;
CREATE POLICY "Public read offers" ON offers FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write offers" ON offers;
CREATE POLICY "Public write offers" ON offers FOR ALL USING (true);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read reviews" ON reviews;
CREATE POLICY "Public read reviews" ON reviews FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write reviews" ON reviews;
CREATE POLICY "Public write reviews" ON reviews FOR ALL USING (true);

ALTER TABLE payouts ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read payouts" ON payouts;
CREATE POLICY "Public read payouts" ON payouts FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write payouts" ON payouts;
CREATE POLICY "Public write payouts" ON payouts FOR ALL USING (true);

ALTER TABLE push_notifications ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "Public read push_notifications" ON push_notifications;
CREATE POLICY "Public read push_notifications" ON push_notifications FOR SELECT USING (true);
DROP POLICY IF EXISTS "Public write push_notifications" ON push_notifications;
CREATE POLICY "Public write push_notifications" ON push_notifications FOR ALL USING (true);

-- ============================================================================
-- END OF CLEAN MIGRATION SCRIPT
-- ============================================================================
