package `in`.soogood.rider.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.ElectricMoped
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PedalBike
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.rider.ui.theme.SooGoodOrangePrimary
import `in`.soogood.rider.ui.theme.StatusOnlineGreen

@Composable
fun OnboardingScreen(
    isLoading: Boolean,
    errorMessage: String?,
    registeredPartnerCode: String?,
    onLogin: (phone: String, password: String) -> Unit,
    onRegister: (fullName: String, phone: String, email: String, vehicleType: String, vehicleNumber: String, password: String) -> Unit,
    onDismissSuccessDialog: () -> Unit,
    onDismissErrorDialog: () -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0 = Login, 1 = Register

    // Login Form States (Strict 10-digit mobile number starting with 6-9)
    var loginPhone by remember { mutableStateOf("") }
    var loginPassword by remember { mutableStateOf("") }

    // Register Form States (Strict 10-digit mobile number starting with 6-9)
    var regFullName by remember { mutableStateOf("") }
    var regPhone by remember { mutableStateOf("") }
    var regEmail by remember { mutableStateOf("") }
    var regVehicleType by remember { mutableStateOf("Cycle") }
    var regVehicleNumber by remember { mutableStateOf("") }
    var regPassword by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(20.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Header Branding
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(SooGoodOrangePrimary, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.DirectionsBike,
                    contentDescription = "SooGood Rider",
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "SooGood Delivery Partner",
                style = MaterialTheme.typography.headlineSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            )

            Text(
                text = "Deliver Happiness. Earn Every Day.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                ),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Segmented Tab Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = SooGoodOrangePrimary,
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Partner Login",
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Apply for Job",
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Main Card Container
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    if (selectedTab == 0) {
                        // ==================== LOGIN FORM ====================
                        Text(
                            text = "Log In to Partner Portal",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )

                        OutlinedTextField(
                            value = loginPhone,
                            onValueChange = { newValue ->
                                val digitsOnly = newValue.filter { it.isDigit() }
                                if (digitsOnly.length <= 10) {
                                    loginPhone = digitsOnly
                                }
                            },
                            label = { Text("Mobile Number (10 Digits)") },
                            placeholder = { Text("Starts with 6, 7, 8, or 9") },
                            leadingIcon = {
                                Icon(Icons.Default.Phone, contentDescription = null)
                            },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            isError = loginPhone.isNotEmpty() && (loginPhone.length != 10 || loginPhone.firstOrNull() !in listOf('6', '7', '8', '9'))
                        )

                        OutlinedTextField(
                            value = loginPassword,
                            onValueChange = { loginPassword = it },
                            label = { Text("Password") },
                            placeholder = { Text("Enter your password") },
                            leadingIcon = {
                                Icon(Icons.Default.Lock, contentDescription = null)
                            },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        Spacer(modifier = Modifier.height(4.dp))

                        val isLoginPhoneValid = loginPhone.length == 10 && loginPhone.firstOrNull() in listOf('6', '7', '8', '9')
                        val isLoginValid = !isLoading && isLoginPhoneValid && loginPassword.isNotBlank()

                        Button(
                            onClick = { onLogin(loginPhone, loginPassword) },
                            enabled = isLoginValid,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SooGoodOrangePrimary
                            )
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            } else {
                                Text(
                                    text = "LOGIN & START DUTY",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Apply Job Option below login screen
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Don't have an account?",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                            )
                            TextButton(onClick = { selectedTab = 1 }) {
                                Text(
                                    text = "Apply for Job",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SooGoodOrangePrimary
                                )
                            }
                        }
                    } else {
                        // ==================== REGISTRATION FORM ====================
                        Text(
                            text = "Apply for Delivery Partner Job",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            )
                        )

                        OutlinedTextField(
                            value = regFullName,
                            onValueChange = { regFullName = it },
                            label = { Text("Full Name") },
                            leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = regPhone,
                            onValueChange = { newValue ->
                                val digitsOnly = newValue.filter { it.isDigit() }
                                if (digitsOnly.length <= 10) {
                                    regPhone = digitsOnly
                                }
                            },
                            label = { Text("Mobile Number (10 Digits)") },
                            placeholder = { Text("Starts with 6, 7, 8, or 9") },
                            leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            isError = regPhone.isNotEmpty() && (regPhone.length != 10 || regPhone.firstOrNull() !in listOf('6', '7', '8', '9'))
                        )

                        OutlinedTextField(
                            value = regEmail,
                            onValueChange = { regEmail = it },
                            label = { Text("Email Address (Optional)") },
                            leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        OutlinedTextField(
                            value = regPassword,
                            onValueChange = { regPassword = it },
                            label = { Text("Create Password") },
                            placeholder = { Text("Set a secure password") },
                            leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                            visualTransformation = PasswordVisualTransformation(),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )

                        Text(
                            text = "Select Vehicle Type",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium)
                        )

                        // 3-Way Vehicle Option Selector (Cycle, EV Scooter, Bike/Scooter)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            VehicleChip(
                                title = "Cycle",
                                icon = Icons.Default.PedalBike,
                                isSelected = regVehicleType == "Cycle",
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    regVehicleType = "Cycle"
                                    regVehicleNumber = "N/A"
                                }
                            )
                            VehicleChip(
                                title = "EV Scooter",
                                icon = Icons.Default.ElectricMoped,
                                isSelected = regVehicleType == "EV Scooter",
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    regVehicleType = "EV Scooter"
                                    if (regVehicleNumber == "N/A") regVehicleNumber = ""
                                }
                            )
                            VehicleChip(
                                title = "Bike/Scooter",
                                icon = Icons.Default.TwoWheeler,
                                isSelected = regVehicleType == "Bike/Scooter",
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    regVehicleType = "Bike/Scooter"
                                    if (regVehicleNumber == "N/A") regVehicleNumber = ""
                                }
                            )
                        }

                        if (regVehicleType != "Cycle") {
                            OutlinedTextField(
                                value = regVehicleNumber,
                                onValueChange = { regVehicleNumber = it },
                                label = { Text("Vehicle Registration Plate Number") },
                                placeholder = { Text("e.g. KA 05 EQ 9090") },
                                leadingIcon = { Icon(Icons.Default.DirectionsBike, contentDescription = null) },
                                modifier = Modifier.fillMaxWidth(),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(
                                        StatusOnlineGreen.copy(alpha = 0.12f),
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "✓ Bicycle selected — No vehicle registration plate required!",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = StatusOnlineGreen
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        val isRegPhoneValid = regPhone.length == 10 && regPhone.firstOrNull() in listOf('6', '7', '8', '9')
                        val isRegValid = !isLoading && regFullName.isNotBlank() && isRegPhoneValid &&
                                regPassword.isNotBlank() && (regVehicleType == "Cycle" || regVehicleNumber.isNotBlank())

                        Button(
                            onClick = {
                                val finalPlate = if (regVehicleType == "Cycle" || regVehicleNumber.isBlank()) "N/A" else regVehicleNumber
                                onRegister(regFullName, regPhone, regEmail, regVehicleType, finalPlate, regPassword)
                            },
                            enabled = isRegValid,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = StatusOnlineGreen
                            )
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(24.dp))
                            } else {
                                Text(
                                    text = "SUBMIT JOB APPLICATION",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            }
                        }

                        // Already have an account option below register
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Already applied / approved?",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                            )
                            TextButton(onClick = { selectedTab = 0 }) {
                                Text(
                                    text = "Login here",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SooGoodOrangePrimary
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Footer
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = StatusOnlineGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Insured by SooGood Partner Shield",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    // Error Pop-up Card Dialog
    if (errorMessage != null) {
        AlertDialog(
            onDismissRequest = onDismissErrorDialog,
            icon = {
                Icon(
                    imageVector = Icons.Default.ErrorOutline,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(44.dp)
                )
            },
            title = {
                Text(
                    text = "Application Alert",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Text(
                    text = errorMessage,
                    textAlign = TextAlign.Center,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
            },
            confirmButton = {
                Button(
                    onClick = onDismissErrorDialog,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SooGoodOrangePrimary
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("OK, GOT IT", fontWeight = FontWeight.Bold, color = Color.White)
                }
            }
        )
    }

    // Registration Success Dialog (Job Application Submitted for Admin Approval)
    if (registeredPartnerCode != null) {
        AlertDialog(
            onDismissRequest = onDismissSuccessDialog,
            icon = {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = StatusOnlineGreen,
                    modifier = Modifier.size(48.dp)
                )
            },
            title = {
                Text(
                    text = "Application Submitted!",
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
            },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Your job application has been successfully submitted to admin for approval.",
                        textAlign = TextAlign.Center,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Your Reference Partner Code is:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = StatusOnlineGreen.copy(alpha = 0.15f)
                        ),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text(
                            text = registeredPartnerCode,
                            fontSize = 24.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = StatusOnlineGreen,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    }
                    Text(
                        text = "Once approved by admin, you can log in using your Mobile Number & Password.",
                        textAlign = TextAlign.Center,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        loginPhone = regPhone
                        selectedTab = 0
                        onDismissSuccessDialog()
                    }
                ) {
                    Text("PROCEED TO LOGIN", fontWeight = FontWeight.Bold, color = SooGoodOrangePrimary)
                }
            }
        )
    }
}

@Composable
fun VehicleChip(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isSelected: Boolean,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) SooGoodOrangePrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.background
        ),
        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, SooGoodOrangePrimary) else null
    ) {
        Column(
            modifier = Modifier
                .padding(10.dp)
                .fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) SooGoodOrangePrimary else MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                color = if (isSelected) SooGoodOrangePrimary else MaterialTheme.colorScheme.onBackground,
                maxLines = 1
            )
        }
    }
}
