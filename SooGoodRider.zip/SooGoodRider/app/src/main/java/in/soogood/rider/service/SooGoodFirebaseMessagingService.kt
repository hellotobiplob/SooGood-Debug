package `in`.soogood.rider.service

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import `in`.soogood.rider.MainActivity
import `in`.soogood.rider.R
import `in`.soogood.rider.data.repository.FirebaseRealtimeRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class SooGoodFirebaseMessagingService : FirebaseMessagingService() {

    private val firebaseRealtimeRepo = FirebaseRealtimeRepository()

    override fun onNewToken(token: String) {
        super.onNewToken(token)
        Log.d(TAG, "New FCM Registration Token: $token")
        syncTokenToFirebase(token)
    }

    override fun onMessageReceived(remoteMessage: RemoteMessage) {
        super.onMessageReceived(remoteMessage)
        Log.d(TAG, "FCM Message Received: ${remoteMessage.data}")

        val title = remoteMessage.notification?.title ?: remoteMessage.data["title"] ?: "SooGood Rider Dispatch"
        val body = remoteMessage.notification?.body ?: remoteMessage.data["body"] ?: "You have a new delivery alert!"

        showHeadsUpNotification(title, body)
    }

    private fun syncTokenToFirebase(token: String) {
        CoroutineScope(Dispatchers.IO).launch {
            try {
                firebaseRealtimeRepo.registerFcmToken(null, token)
                Log.d(TAG, "Successfully synced FCM token to Firebase RTDB")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to sync FCM token to Firebase", e)
            }
        }
    }

    private fun showHeadsUpNotification(title: String, body: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channelId = "soogood_rider_notifications"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Order Dispatches & Alerts",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "High-priority notifications for new order dispatches and status updates"
                enableVibration(true)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(System.currentTimeMillis().toInt(), notification)
    }

    companion object {
        private const val TAG = "SooGoodFcmService"
    }
}
