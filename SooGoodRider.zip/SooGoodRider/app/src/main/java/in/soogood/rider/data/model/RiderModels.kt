package `in`.soogood.rider.data.model

enum class OrderStatus {
    PENDING_ACCEPTANCE,
    HEADING_TO_STORE,
    AT_STORE,
    PICKED_UP,
    EN_ROUTE_TO_CUSTOMER,
    ARRIVED_AT_CUSTOMER,
    DELIVERED,
    CANCELLED
}

data class OrderItem(
    val id: String,
    val name: String,
    val quantity: Int,
    val price: Double,
    val isVeg: Boolean = true
)

data class DeliveryOrder(
    val id: String,
    val orderNumber: String,
    val storeName: String,
    val storeAddress: String,
    val storePhone: String,
    val storeDistanceKm: Double,
    val storeLatitude: Double = 12.9121,
    val storeLongitude: Double = 77.6445,
    val customerName: String,
    val customerAddress: String,
    val customerPhone: String,
    val customerDistanceKm: Double,
    val customerLatitude: Double = 12.9716,
    val customerLongitude: Double = 77.5946,
    val customerOtp: String = "1234",
    val deliveryFee: Double,
    val tip: Double = 0.0,
    val incentiveBonus: Double = 0.0,
    val paymentType: String = "Prepaid / Paid Online",
    val isCod: Boolean = false,
    val codAmount: Double = 0.0,
    val status: OrderStatus = OrderStatus.PENDING_ACCEPTANCE,
    val items: List<OrderItem>,
    val pickupInstructions: String = "Check order number before receiving items",
    val deliveryInstructions: String = "Handover directly to customer or leave at door",
    val timestampMs: Long = System.currentTimeMillis()
) {
    val totalEarnings: Double
        get() = deliveryFee + tip + incentiveBonus
}

data class RiderProfile(
    val id: String = "SGR-8892",
    val name: String = "Rahul Sharma",
    val phone: String = "+91 98765 43210",
    val email: String = "rahul.rider@soogood.in",
    val vehicleType: String = "Electric Bike (EV)",
    val vehicleNumber: String = "KA 05 SG 9090",
    val rating: Double = 4.92,
    val totalTripsCompleted: Int = 384,
    val isOnline: Boolean = true,
    val isDocumentVerified: Boolean = true
)

data class EarningsSummary(
    val todayEarnings: Double = 840.0,
    val todayTrips: Int = 9,
    val todayHoursOnline: Double = 5.5,
    val weeklyEarnings: Double = 5420.0,
    val targetTripsForBonus: Int = 12,
    val bonusAmount: Double = 250.0
)

data class WeeklyEarning(
    val dayName: String,
    val amount: Double,
    val trips: Int
)
