package `in`.soogood.rider.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SooGoodOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = SooGoodOrangeDark,
    secondary = StatusOnlineGreen,
    onSecondary = Color.White,
    tertiary = EarningsGold,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = Color(0xFFE1E2E6),
    onSurface = Color(0xFFE1E2E6)
)

private val LightColorScheme = lightColorScheme(
    primary = SooGoodOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = SooGoodOrangeLight,
    secondary = StatusOnlineGreen,
    onSecondary = Color.White,
    tertiary = EarningsGold,
    background = LightBackground,
    surface = LightSurface,
    onBackground = Color(0xFF191C1E),
    onSurface = Color(0xFF191C1E)
)

@Composable
fun SooGoodRiderTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
