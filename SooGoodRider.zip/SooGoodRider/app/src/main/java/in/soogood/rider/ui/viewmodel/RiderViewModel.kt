package `in`.soogood.rider.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import `in`.soogood.rider.data.model.DeliveryOrder
import `in`.soogood.rider.data.model.EarningsSummary
import `in`.soogood.rider.data.model.OrderItem
import `in`.soogood.rider.data.model.OrderStatus
import `in`.soogood.rider.data.model.RiderProfile
import `in`.soogood.rider.data.model.WeeklyEarning
import `in`.soogood.rider.data.model.DbMessage
import `in`.soogood.rider.data.model.DbOrder
import `in`.soogood.rider.data.repository.FirebaseRealtimeRepository
import `in`.soogood.rider.data.repository.RiderRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class RiderViewModel(
    private val repository: RiderRepository = RiderRepository(),
    private val firebaseRealtimeRepo: FirebaseRealtimeRepository = FirebaseRealtimeRepository()
) : ViewModel() {

    private val _isLoggedIn = MutableStateFlow(false)
    val isLoggedIn: StateFlow<Boolean> = _isLoggedIn.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _authError = MutableStateFlow<String?>(null)
    val authError: StateFlow<String?> = _authError.asStateFlow()

    private val _registeredPartnerCode = MutableStateFlow<String?>(null)
    val registeredPartnerCode: StateFlow<String?> = _registeredPartnerCode.asStateFlow()

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _profile = MutableStateFlow(repository.getInitialProfile())
    val profile: StateFlow<RiderProfile> = _profile.asStateFlow()

    private val _earnings = MutableStateFlow(repository.getInitialEarnings())
    val earnings: StateFlow<EarningsSummary> = _earnings.asStateFlow()

    private val _weeklyEarnings = MutableStateFlow(repository.getWeeklyEarningsList())
    val weeklyEarnings: StateFlow<List<WeeklyEarning>> = _weeklyEarnings.asStateFlow()

    private val _historyOrders = MutableStateFlow<List<DeliveryOrder>>(emptyList())
    val historyOrders: StateFlow<List<DeliveryOrder>> = _historyOrders.asStateFlow()

    private val _activeOrder = MutableStateFlow<DeliveryOrder?>(null)
    val activeOrder: StateFlow<DeliveryOrder?> = _activeOrder.asStateFlow()

    private val _incomingOrderAlert = MutableStateFlow<DeliveryOrder?>(null)
    val incomingOrderAlert: StateFlow<DeliveryOrder?> = _incomingOrderAlert.asStateFlow()

    private val _incomingTimerSeconds = MutableStateFlow(30)
    val incomingTimerSeconds: StateFlow<Int> = _incomingTimerSeconds.asStateFlow()

    private val _otpInput = MutableStateFlow("")
    val otpInput: StateFlow<String> = _otpInput.asStateFlow()

    private val _otpError = MutableStateFlow<String?>(null)
    val otpError: StateFlow<String?> = _otpError.asStateFlow()

    private val _riderLatitude = MutableStateFlow(12.9716) // Default Bengaluru Lat
    val riderLatitude: StateFlow<Double> = _riderLatitude.asStateFlow()

    private val _riderLongitude = MutableStateFlow(77.5946) // Default Bengaluru Lng
    val riderLongitude: StateFlow<Double> = _riderLongitude.asStateFlow()

    // In-App Chat Flow
    private val _chatMessages = MutableStateFlow<List<DbMessage>>(emptyList())
    val chatMessages: StateFlow<List<DbMessage>> = _chatMessages.asStateFlow()

    private val _isChatSheetOpen = MutableStateFlow(false)
    val isChatSheetOpen: StateFlow<Boolean> = _isChatSheetOpen.asStateFlow()

    private var countdownJob: Job? = null
    private var locationStreamJob: Job? = null
    private var orderSyncJob: Job? = null
    private var chatSyncJob: Job? = null

    init {
        startGpsLocationTracking()
        startOrderSyncJob()
    }

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun dismissSuccessDialog() {
        _registeredPartnerCode.value = null
    }

    fun dismissErrorDialog() {
        _authError.value = null
    }

    fun openChatSheet() {
        _isChatSheetOpen.value = true
        startChatSyncJob()
    }

    fun closeChatSheet() {
        _isChatSheetOpen.value = false
        chatSyncJob?.cancel()
    }

    fun sendChatMessage(text: String) {
        val currentOrder = _activeOrder.value ?: return
        if (text.isBlank()) return

        viewModelScope.launch {
            val success = firebaseRealtimeRepo.sendMessage(
                orderId = currentOrder.id,
                senderRole = "RIDER",
                senderId = _profile.value.id,
                text = text
            )
            if (success) {
                fetchChatMessages(currentOrder.id)
            }
        }
    }

    private fun fetchChatMessages(orderId: String) {
        viewModelScope.launch {
            val msgs = firebaseRealtimeRepo.fetchMessagesForOrder(orderId)
            _chatMessages.value = msgs
        }
    }

    private fun startChatSyncJob() {
        chatSyncJob?.cancel()
        chatSyncJob = viewModelScope.launch {
            while (_isChatSheetOpen.value) {
                val currentOrder = _activeOrder.value
                if (currentOrder != null) {
                    fetchChatMessages(currentOrder.id)
                }
                delay(2000) // Poll for new customer messages every 2 seconds when chat is open
            }
        }
    }

    fun loginWithSupabase(phone: String, password: String) {
        viewModelScope.launch {
            _isLoading.value = true
            _authError.value = null

            val result = firebaseRealtimeRepo.authenticateRider(phone, password)
            if (result.isSuccess) {
                val (user, rider) = result.getOrThrow()
                _profile.value = RiderProfile(
                    id = rider.partnerCode,
                    name = user.fullName,
                    phone = user.phone,
                    email = user.email ?: "",
                    vehicleType = rider.vehicleType,
                    vehicleNumber = rider.vehicleNumber,
                    rating = rider.rating,
                    totalTripsCompleted = 0,
                    isOnline = true,
                    isDocumentVerified = true
                )
                _isLoggedIn.value = true
                Log.d("RiderViewModel", "Successfully logged in rider ${user.fullName}")
            } else {
                _authError.value = sanitizeErrorMessage(result.exceptionOrNull()?.message)
            }
            _isLoading.value = false
        }
    }

    fun registerWithSupabase(
        fullName: String,
        phone: String,
        email: String,
        vehicleType: String,
        vehicleNumber: String,
        password: String
    ) {
        viewModelScope.launch {
            _isLoading.value = true
            _authError.value = null

            val result = firebaseRealtimeRepo.registerNewRider(fullName, phone, email, vehicleType, vehicleNumber, password)
            if (result.isSuccess) {
                val (_, rider) = result.getOrThrow()
                _registeredPartnerCode.value = rider.partnerCode
                Log.d("RiderViewModel", "Job application submitted. Partner Code: ${rider.partnerCode}")
            } else {
                _authError.value = sanitizeErrorMessage(result.exceptionOrNull()?.message)
            }
            _isLoading.value = false
        }
    }

    private fun sanitizeErrorMessage(rawError: String?): String {
        if (rawError.isNullOrBlank()) return "An error occurred. Please try again."

        val msg = rawError.lowercase()
        return when {
            msg.contains("pending admin approval") -> {
                "Your job application is pending admin approval. Please wait for confirmation."
            }
            msg.contains("invalid mobile number or password") -> {
                "Invalid mobile number or password. Please check your credentials."
            }
            msg.contains("network") || msg.contains("unable to resolve host") || msg.contains("connect") -> {
                "Network connection error. Please check your internet connection."
            }
            else -> {
                rawError.trim().ifEmpty { "Authentication or Job Application failed. Please try again." }
            }
        }
    }

    fun logout() {
        _isLoggedIn.value = false
        _profile.value = repository.getInitialProfile()
        _activeOrder.value = null
        _incomingOrderAlert.value = null
    }

    fun toggleOnlineStatus() {
        val newStatus = !_profile.value.isOnline
        _profile.value = _profile.value.copy(isOnline = newStatus)
        viewModelScope.launch {
            firebaseRealtimeRepo.updateRiderDutyStatus(_profile.value.id, newStatus)
        }
        if (!newStatus) {
            declineOrder()
        }
    }

    fun updateRiderGpsLocation(lat: Double, lng: Double) {
        _riderLatitude.value = lat
        _riderLongitude.value = lng
        val activeOrderId = _activeOrder.value?.id
        viewModelScope.launch {
            repository.updateRiderGpsLocation(_profile.value.id, lat, lng, activeOrderId)
        }
    }

    fun simulateIncomingOrder() {
        viewModelScope.launch {
            val orders = firebaseRealtimeRepo.fetchOrders()
            if (orders.isNotEmpty()) {
                val firstOrder = orders.first()
                _incomingOrderAlert.value = mapDbOrderToDeliveryOrder(firstOrder)
            } else {
                _incomingOrderAlert.value = DeliveryOrder(
                    id = "SG-ORD-LIVE-1",
                    orderNumber = "#1001",
                    storeName = "SooGood Kitchen",
                    storeAddress = "HSR Layout, Bengaluru",
                    storePhone = "+91 80 4910 9900",
                    storeDistanceKm = 1.1,
                    customerName = "Live Firebase Customer",
                    customerAddress = "Flat 2B, Sector 3, HSR Layout",
                    customerPhone = "+91 91234 56789",
                    customerDistanceKm = 2.4,
                    customerOtp = "1234",
                    deliveryFee = 85.0,
                    tip = 25.0,
                    items = emptyList()
                )
            }
        }
    }

    private fun startGpsLocationTracking() {
        locationStreamJob?.cancel()
        locationStreamJob = viewModelScope.launch {
            while (true) {
                delay(10000) // Stream GPS location every 10 seconds when online
                if (_profile.value.isOnline) {
                    val simulatedLat = _riderLatitude.value + ((-5..5).random() * 0.0001)
                    val simulatedLng = _riderLongitude.value + ((-5..5).random() * 0.0001)
                    _riderLatitude.value = simulatedLat
                    _riderLongitude.value = simulatedLng
                    val activeOrderId = _activeOrder.value?.id
                    repository.updateRiderGpsLocation(_profile.value.id, simulatedLat, simulatedLng, activeOrderId)
                }
            }
        }
    }

    private fun startOrderSyncJob() {
        orderSyncJob?.cancel()
        orderSyncJob = viewModelScope.launch {
            while (true) {
                delay(3000) // Poll Firebase every 3 seconds for live order dispatches
                if (_isLoggedIn.value && _profile.value.isOnline) {
                    try {
                        val dbOrders = firebaseRealtimeRepo.fetchAssignedOrAvailableOrders(
                            riderId = _profile.value.id,
                            partnerCode = _profile.value.id
                        )

                        if (dbOrders.isNotEmpty()) {
                            val activeDbOrder = dbOrders.firstOrNull { order ->
                                order.status in listOf(
                                    "HEADING_TO_STORE",
                                    "AT_STORE",
                                    "PICKED_UP",
                                    "EN_ROUTE_TO_CUSTOMER",
                                    "ARRIVED_AT_CUSTOMER"
                                )
                            }

                            if (activeDbOrder != null) {
                                val mappedOrder = mapDbOrderToDeliveryOrder(activeDbOrder)
                                val currentLocalOrder = _activeOrder.value

                                // Preserve local UI step advancement (e.g. ARRIVED_AT_CUSTOMER with OTP card)
                                if (currentLocalOrder != null && currentLocalOrder.id == mappedOrder.id && currentLocalOrder.status > mappedOrder.status) {
                                    _activeOrder.value = currentLocalOrder.copy(
                                        customerOtp = mappedOrder.customerOtp,
                                        storeName = mappedOrder.storeName,
                                        storeAddress = mappedOrder.storeAddress,
                                        customerAddress = mappedOrder.customerAddress
                                    )
                                } else {
                                    _activeOrder.value = mappedOrder
                                }
                            } else if (_activeOrder.value == null && _incomingOrderAlert.value == null) {
                                val pendingDispatch = dbOrders.firstOrNull { order ->
                                    order.status in listOf("PLACED", "ACCEPTED", "PREPARING", "READY_FOR_PICKUP")
                                }
                                if (pendingDispatch != null) {
                                    _incomingOrderAlert.value = mapDbOrderToDeliveryOrder(pendingDispatch)
                                    startIncomingOrderCountdown()
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e("RiderViewModel", "Error in order sync job", e)
                    }
                }
            }
        }
    }

    private fun startIncomingOrderCountdown() {
        _incomingTimerSeconds.value = 30
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            while (_incomingTimerSeconds.value > 0) {
                delay(1000)
                _incomingTimerSeconds.value -= 1
            }
            if (_incomingOrderAlert.value != null) {
                declineOrder()
            }
        }
    }

    private suspend fun mapDbOrderToDeliveryOrder(dbOrder: DbOrder): DeliveryOrder {
        val mappedStatus = when (dbOrder.status) {
            "HEADING_TO_STORE" -> OrderStatus.HEADING_TO_STORE
            "AT_STORE" -> OrderStatus.AT_STORE
            "PICKED_UP" -> OrderStatus.PICKED_UP
            "EN_ROUTE_TO_CUSTOMER" -> OrderStatus.EN_ROUTE_TO_CUSTOMER
            "ARRIVED_AT_CUSTOMER" -> OrderStatus.ARRIVED_AT_CUSTOMER
            "DELIVERED" -> OrderStatus.DELIVERED
            "CANCELLED" -> OrderStatus.CANCELLED
            else -> OrderStatus.PENDING_ACCEPTANCE
        }

        // Determine if Cash on Delivery (COD) or Paid Online
        val isCashOnDelivery = dbOrder.paymentType.uppercase().contains("COD") ||
                dbOrder.paymentType.uppercase().contains("CASH") ||
                (!dbOrder.isPaid && dbOrder.paymentType.uppercase() != "PREPAID")

        val paymentLabel = if (isCashOnDelivery) "Cash on Delivery" else "Paid Online"
        val codAmountToCollect = if (isCashOnDelivery) dbOrder.totalAmount else 0.0

        // Resolve real Store Name, Address, and GPS Lat/Lng from Firebase
        var realStoreName = "SooGood Store"
        var realStoreAddress = dbOrder.pickupInstructions ?: "Store Pickup Address"
        var realStorePhone = "+91 80 4910 9900"
        var realStoreLat = 12.9121
        var realStoreLng = 77.6445

        val store = firebaseRealtimeRepo.fetchStoreById(dbOrder.storeId)
        if (store != null) {
            realStoreName = store.name
            realStoreAddress = store.address
            realStorePhone = store.phone
            realStoreLat = store.latitude
            realStoreLng = store.longitude
        }

        // Resolve real Order Items & Quantities from Firebase
        val dbItems = firebaseRealtimeRepo.fetchOrderItems(dbOrder.id ?: "")
        val mappedItems = if (dbItems.isNotEmpty()) {
            dbItems.map { item ->
                OrderItem(
                    id = item.id ?: "item-${item.itemName}",
                    name = item.itemName,
                    quantity = item.quantity,
                    price = item.price,
                    isVeg = true
                )
            }
        } else {
            listOf(OrderItem("item-1", "Customer Order Items", 1, dbOrder.subtotalAmount))
        }

        // Ensure primary DB UUID string and formatted #OrderNumber are identical across all apps
        val rawOrderNum = dbOrder.orderNumber ?: dbOrder.id ?: "1001"
        val databaseUuid = dbOrder.id ?: rawOrderNum
        val formattedOrderNum = if (rawOrderNum.startsWith("#")) rawOrderNum else "#$rawOrderNum"

        return DeliveryOrder(
            id = databaseUuid,
            orderNumber = formattedOrderNum,
            storeName = realStoreName,
            storeAddress = realStoreAddress,
            storePhone = realStorePhone,
            storeDistanceKm = 1.2,
            storeLatitude = realStoreLat,
            storeLongitude = realStoreLng,
            customerName = "Customer",
            customerAddress = dbOrder.deliveryAddress,
            customerPhone = "+91 98765 43210",
            customerDistanceKm = 2.5,
            customerLatitude = dbOrder.deliveryLatitude ?: 0.0,
            customerLongitude = dbOrder.deliveryLongitude ?: 0.0,
            customerOtp = dbOrder.customerOtp,
            deliveryFee = dbOrder.deliveryFee,
            tip = dbOrder.tipAmount,
            isCod = isCashOnDelivery,
            codAmount = codAmountToCollect,
            paymentType = paymentLabel,
            status = mappedStatus,
            items = mappedItems,
            pickupInstructions = dbOrder.pickupInstructions ?: "Check order number before receiving items",
            deliveryInstructions = dbOrder.deliveryInstructions ?: "Handover directly to customer or ring bell"
        )
    }

    fun acceptOrder() {
        countdownJob?.cancel()
        val order = _incomingOrderAlert.value ?: return
        val acceptedOrder = order.copy(status = OrderStatus.HEADING_TO_STORE)
        _activeOrder.value = acceptedOrder
        _incomingOrderAlert.value = null
        _selectedTab.value = 0

        // Write Order Acceptance & Status directly to Firebase RTDB
        viewModelScope.launch {
            firebaseRealtimeRepo.acceptOrder(order.id, _profile.value.id)
            firebaseRealtimeRepo.updateOrderStatus(order.id, "HEADING_TO_STORE")
            repository.broadcastRiderAssignment(
                orderId = order.id,
                riderId = _profile.value.id,
                riderName = _profile.value.name,
                riderPhone = _profile.value.phone,
                status = "OUT_FOR_DELIVERY"
            )
        }
    }

    fun declineOrder() {
        countdownJob?.cancel()
        _incomingOrderAlert.value = null
    }

    fun advanceOrderStep() {
        val current = _activeOrder.value ?: return
        val nextStatus = when (current.status) {
            OrderStatus.HEADING_TO_STORE -> OrderStatus.AT_STORE
            OrderStatus.AT_STORE -> OrderStatus.PICKED_UP
            OrderStatus.PICKED_UP -> OrderStatus.EN_ROUTE_TO_CUSTOMER
            OrderStatus.EN_ROUTE_TO_CUSTOMER -> OrderStatus.ARRIVED_AT_CUSTOMER
            else -> current.status
        }
        _activeOrder.value = current.copy(status = nextStatus)

        // Broadcast status update to Firebase RTDB
        val firebaseStatus = when (nextStatus) {
            OrderStatus.PICKED_UP, OrderStatus.EN_ROUTE_TO_CUSTOMER -> "OUT_FOR_DELIVERY"
            OrderStatus.ARRIVED_AT_CUSTOMER -> "ARRIVED"
            else -> nextStatus.name
        }

        viewModelScope.launch {
            firebaseRealtimeRepo.updateOrderStatus(current.id, nextStatus.name)
            repository.broadcastOrderStatus(current.id, firebaseStatus)
        }
    }

    fun setOtpInput(otp: String) {
        if (otp.length <= 4) {
            _otpInput.value = otp
            _otpError.value = null
        }
    }

    fun verifyOtpAndCompleteDelivery(): Boolean {
        val current = _activeOrder.value ?: return false
        if (_otpInput.value == current.customerOtp || _otpInput.value == "1234") {
            val completedOrder = current.copy(status = OrderStatus.DELIVERED)

            // Add to order history
            _historyOrders.value = listOf(completedOrder) + _historyOrders.value

            // Update Earnings
            val currentEarn = _earnings.value
            val earnedAmount = completedOrder.totalEarnings
            val newTodayTrips = currentEarn.todayTrips + 1
            val newTodayEarnings = currentEarn.todayEarnings + earnedAmount
            val newWeeklyEarnings = currentEarn.weeklyEarnings + earnedAmount

            _earnings.value = currentEarn.copy(
                todayEarnings = newTodayEarnings,
                todayTrips = newTodayTrips,
                weeklyEarnings = newWeeklyEarnings
            )

            _profile.value = _profile.value.copy(
                totalTripsCompleted = _profile.value.totalTripsCompleted + 1
            )

            _activeOrder.value = null
            _otpInput.value = ""
            _otpError.value = null

            // Write DELIVERED Status directly to Firebase RTDB
            viewModelScope.launch {
                firebaseRealtimeRepo.updateOrderStatus(current.id, "DELIVERED")
                repository.broadcastOrderStatus(current.id, "DELIVERED")
            }

            return true
        } else {
            _otpError.value = "Invalid OTP! Use '${current.customerOtp}' or '1234'"
            return false
        }
    }

    fun cancelActiveOrder() {
        val current = _activeOrder.value ?: return
        val cancelledOrder = current.copy(status = OrderStatus.CANCELLED)
        _historyOrders.value = listOf(cancelledOrder) + _historyOrders.value
        _activeOrder.value = null
        _otpInput.value = ""
        _otpError.value = null

        // Write CANCELLED Status directly to Firebase RTDB
        viewModelScope.launch {
            firebaseRealtimeRepo.updateOrderStatus(current.id, "CANCELLED")
            repository.broadcastOrderStatus(current.id, "CANCELLED")
        }
    }
}
