package `in`.soogood.rider.ui.theme

import androidx.compose.ui.graphics.Color

val SooGoodOrangePrimary = Color(0xFFFF5722)
val SooGoodOrangeDark = Color(0xFFE64A19)
val SooGoodOrangeLight = Color(0xFFFF8A65)

val StatusOnlineGreen = Color(0xFF2E7D32)
val StatusOnlineGreenLight = Color(0xFFE8F5E9)

val StatusOfflineRed = Color(0xFFC62828)
val StatusOfflineRedLight = Color(0xFFFFEBEE)

val StatusPendingAmber = Color(0xFFF57C00)
val StatusPendingAmberLight = Color(0xFFFFF3E0)

val EarningsGold = Color(0xFFFFB300)

val DarkBackground = Color(0xFF121216)
val DarkSurface = Color(0xFF1E1E24)
val LightBackground = Color(0xFFF4F6F8)
val LightSurface = Color(0xFFFFFFFF)
