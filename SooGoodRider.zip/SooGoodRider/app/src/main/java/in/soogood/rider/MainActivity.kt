package `in`.soogood.rider

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import `in`.soogood.rider.ui.screens.ActiveDeliveryScreen
import `in`.soogood.rider.ui.screens.EarningsScreen
import `in`.soogood.rider.ui.screens.HistoryScreen
import `in`.soogood.rider.ui.screens.HomeScreen
import `in`.soogood.rider.ui.screens.IncomingOrderSheet
import `in`.soogood.rider.ui.screens.OnboardingScreen
import `in`.soogood.rider.ui.screens.OrderChatSheet
import `in`.soogood.rider.ui.screens.ProfileScreen
import `in`.soogood.rider.ui.theme.SooGoodOrangePrimary
import `in`.soogood.rider.ui.theme.SooGoodRiderTheme
import `in`.soogood.rider.ui.theme.StatusOnlineGreen
import `in`.soogood.rider.ui.viewmodel.RiderViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
            )
        }

        setContent {
            SooGoodRiderTheme {
                RiderAppMain()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RiderAppMain(
    viewModel: RiderViewModel = viewModel()
) {
    val isLoggedIn by viewModel.isLoggedIn.collectAsState()
    val isLoading by viewModel.isLoading.collectAsState()
    val authError by viewModel.authError.collectAsState()
    val registeredPartnerCode by viewModel.registeredPartnerCode.collectAsState()

    val selectedTab by viewModel.selectedTab.collectAsState()
    val profile by viewModel.profile.collectAsState()
    val earnings by viewModel.earnings.collectAsState()
    val weeklyEarnings by viewModel.weeklyEarnings.collectAsState()
    val historyOrders by viewModel.historyOrders.collectAsState()
    val activeOrder by viewModel.activeOrder.collectAsState()
    val incomingAlert by viewModel.incomingOrderAlert.collectAsState()
    val timerSeconds by viewModel.incomingTimerSeconds.collectAsState()
    val otpInput by viewModel.otpInput.collectAsState()
    val otpError by viewModel.otpError.collectAsState()

    val chatMessages by viewModel.chatMessages.collectAsState()
    val isChatSheetOpen by viewModel.isChatSheetOpen.collectAsState()

    var isViewingActiveDelivery by remember { mutableStateOf(false) }

    if (!isLoggedIn) {
        OnboardingScreen(
            isLoading = isLoading,
            errorMessage = authError,
            registeredPartnerCode = registeredPartnerCode,
            onLogin = { phone, partnerCode ->
                viewModel.loginWithSupabase(phone, partnerCode)
            },
            onRegister = { fullName, phone, email, vehicleType, vehicleNumber, password ->
                viewModel.registerWithSupabase(fullName, phone, email, vehicleType, vehicleNumber, password)
            },
            onDismissSuccessDialog = {
                viewModel.dismissSuccessDialog()
            },
            onDismissErrorDialog = {
                viewModel.dismissErrorDialog()
            }
        )
    } else {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Text(
                            text = if (isViewingActiveDelivery && activeOrder != null) "Active Delivery" else "SooGood Delivery Partner",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = Color.White
                        )
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = SooGoodOrangePrimary
                    ),
                    actions = {
                        if (profile.isOnline) {
                            Text(
                                text = "ONLINE",
                                color = StatusOnlineGreen,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 11.sp,
                                modifier = Modifier
                                    .padding(end = 16.dp)
                                    .background(Color.White, androidx.compose.foundation.shape.RoundedCornerShape(12.dp))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    val navItems = listOf(
                        NavTab("Home", Icons.Default.Home, 0),
                        NavTab("Earnings", Icons.Default.AccountBalanceWallet, 1),
                        NavTab("History", Icons.Default.History, 2),
                        NavTab("Profile", Icons.Default.Person, 3)
                    )

                    navItems.forEach { item ->
                        val isSelected = selectedTab == item.index && !isViewingActiveDelivery
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                isViewingActiveDelivery = false
                                viewModel.selectTab(item.index)
                            },
                            icon = {
                                if (item.index == 0 && activeOrder != null) {
                                    BadgedBox(
                                        badge = {
                                            Badge(containerColor = SooGoodOrangePrimary) {
                                                Text("1", color = Color.White)
                                            }
                                        }
                                    ) {
                                        Icon(item.icon, contentDescription = item.label)
                                    }
                                } else {
                                    Icon(item.icon, contentDescription = item.label)
                                }
                            },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = SooGoodOrangePrimary,
                                selectedTextColor = SooGoodOrangePrimary,
                                indicatorColor = SooGoodOrangePrimary.copy(alpha = 0.15f)
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isViewingActiveDelivery && activeOrder != null) {
                    ActiveDeliveryScreen(
                        order = activeOrder!!,
                        otpInput = otpInput,
                        otpError = otpError,
                        onAdvanceStep = { viewModel.advanceOrderStep() },
                        onOtpChange = { viewModel.setOtpInput(it) },
                        onCompleteDelivery = {
                            if (viewModel.verifyOtpAndCompleteDelivery()) {
                                isViewingActiveDelivery = false
                            }
                        },
                        onCancelOrder = {
                            viewModel.cancelActiveOrder()
                            isViewingActiveDelivery = false
                        },
                        onOpenChat = {
                            viewModel.openChatSheet()
                        }
                    )
                } else {
                    when (selectedTab) {
                        0 -> HomeScreen(
                            profile = profile,
                            earnings = earnings,
                            activeOrder = activeOrder,
                            onToggleDuty = { viewModel.toggleOnlineStatus() },
                            onSimulateDispatch = { viewModel.simulateIncomingOrder() },
                            onOpenActiveOrder = { isViewingActiveDelivery = true }
                        )

                        1 -> EarningsScreen(
                            earnings = earnings,
                            weeklyEarnings = weeklyEarnings
                        )

                        2 -> HistoryScreen(
                            orders = historyOrders
                        )

                        3 -> ProfileScreen(
                            profile = profile,
                            onLogout = { viewModel.logout() }
                        )
                    }
                }

                // Incoming Order Dispatch Sheet Alert
                if (incomingAlert != null) {
                    IncomingOrderSheet(
                        order = incomingAlert!!,
                        timerSeconds = timerSeconds,
                        onAccept = {
                            viewModel.acceptOrder()
                            isViewingActiveDelivery = true
                        },
                        onDecline = { viewModel.declineOrder() }
                    )
                }

                // In-App Customer Chat Modal
                if (isChatSheetOpen && activeOrder != null) {
                    OrderChatSheet(
                        orderNumber = activeOrder!!.orderNumber,
                        messages = chatMessages,
                        onSendMessage = { text ->
                            viewModel.sendChatMessage(text)
                        },
                        onDismiss = {
                            viewModel.closeChatSheet()
                        }
                    )
                }
            }
        }
    }
}

data class NavTab(
    val label: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val index: Int
)
