package `in`.soogood.rider.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import `in`.soogood.rider.data.model.DeliveryOrder
import `in`.soogood.rider.data.model.OrderStatus
import `in`.soogood.rider.ui.components.InAppCallOverlay
import `in`.soogood.rider.ui.theme.SooGoodOrangePrimary
import `in`.soogood.rider.ui.theme.StatusOnlineGreen

@Composable
fun ActiveDeliveryScreen(
    order: DeliveryOrder,
    otpInput: String,
    otpError: String?,
    onAdvanceStep: () -> Unit,
    onOtpChange: (String) -> Unit,
    onCompleteDelivery: () -> Unit,
    onCancelOrder: () -> Unit,
    onOpenChat: () -> Unit
) {
    val context = LocalContext.current
    val checkedItems = remember { mutableStateMapOf<String, Boolean>() }
    var activeCallTargetLabel by remember { mutableStateOf<String?>(null) }

    activeCallTargetLabel?.let { targetLabel ->
        InAppCallOverlay(
            orderId = order.orderNumber,
            targetRoleLabel = targetLabel,
            onEndCall = { activeCallTargetLabel = null }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
            .verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Order Header Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = SooGoodOrangePrimary
            )
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ORDER ${order.orderNumber}",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 18.sp
                    )
                    Card(
                        shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White.copy(alpha = 0.2f)
                        )
                    ) {
                        Text(
                            text = "TRIP PAY ₹${order.totalEarnings.toInt()}",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Delivery Stepper Progress Bar
                DeliveryProgressStepper(currentStatus = order.status)
            }
        }

        // Store Pickup Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Storefront,
                            contentDescription = null,
                            tint = SooGoodOrangePrimary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "PICKUP RESTAURANT / STORE",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = SooGoodOrangePrimary
                        )
                    }

                    IconButton(onClick = { activeCallTargetLabel = "Restaurant Partner (${order.storeName})" }) {
                        Icon(
                            imageVector = Icons.Default.Call,
                            contentDescription = "Call Store",
                            tint = StatusOnlineGreen
                        )
                    }
                }

                Text(
                    text = order.storeName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Text(
                    text = order.storeAddress,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Restaurant Navigation Button (Direct Saved GPS Lat/Lng)
                OutlinedButton(
                    onClick = {
                        launchGoogleMapsNavigation(
                            context = context,
                            address = order.storeAddress,
                            latitude = order.storeLatitude,
                            longitude = order.storeLongitude
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = null, tint = SooGoodOrangePrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("NAVIGATE TO RESTAURANT", color = SooGoodOrangePrimary, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (order.items.isNotEmpty()) {
                    // Order Item Verification Checklist
                    Text(
                        text = "Items Verification Checklist:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    order.items.forEach { item ->
                        val isChecked = checkedItems[item.id] ?: (order.status >= OrderStatus.PICKED_UP)
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isChecked,
                                onCheckedChange = { checkedItems[item.id] = it },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = StatusOnlineGreen
                                )
                            )
                            Text(
                                text = "${item.quantity}x ${item.name}",
                                fontSize = 14.sp,
                                fontWeight = if (isChecked) FontWeight.SemiBold else FontWeight.Normal,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                if (order.pickupInstructions.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                SooGoodOrangePrimary.copy(alpha = 0.08f),
                                RoundedCornerShape(8.dp)
                            )
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "Note: ${order.pickupInstructions}",
                            fontSize = 12.sp,
                            color = SooGoodOrangePrimary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        // Customer Delivery Details & Payment Handover Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            ),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = StatusOnlineGreen
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CUSTOMER DELIVERY",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = StatusOnlineGreen
                        )
                    }

                    Row {
                        IconButton(onClick = { launchPhoneCall(context, order.customerPhone) }) {
                            Icon(
                                imageVector = Icons.Default.Call,
                                contentDescription = "Call Customer",
                                tint = StatusOnlineGreen
                            )
                        }
                        IconButton(onClick = onOpenChat) {
                            Icon(
                                imageVector = Icons.Default.Message,
                                contentDescription = "In-App Chat",
                                tint = SooGoodOrangePrimary
                            )
                        }
                    }
                }

                Text(
                    text = order.customerName,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )

                Text(
                    text = order.customerAddress,
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Customer Navigation Button (Direct Saved Customer GPS Lat/Lng or Address text)
                Button(
                    onClick = {
                        launchGoogleMapsNavigation(
                            context = context,
                            address = order.customerAddress,
                            latitude = order.customerLatitude,
                            longitude = order.customerLongitude
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusOnlineGreen)
                ) {
                    Icon(Icons.Default.Navigation, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("NAVIGATE TO CUSTOMER", color = Color.White, fontWeight = FontWeight.Bold)
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Payment Handover Status Tag (Prepaid vs COD with NO fee breakdown)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            if (order.isCod) SooGoodOrangePrimary.copy(alpha = 0.15f) else StatusOnlineGreen.copy(alpha = 0.15f),
                            RoundedCornerShape(10.dp)
                        )
                        .padding(12.dp)
                ) {
                    Text(
                        text = if (order.isCod) "COLLECT CASH FROM CUSTOMER: ₹${order.codAmount.toInt()}" else "CUSTOMER ALREADY PAID THROUGH ONLINE - DO NOT COLLECT CASH",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (order.isCod) SooGoodOrangePrimary else StatusOnlineGreen,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Action Stepper Button or OTP Input Card
        when (order.status) {
            OrderStatus.HEADING_TO_STORE -> {
                Button(
                    onClick = onAdvanceStep,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SooGoodOrangePrimary)
                ) {
                    Icon(Icons.Default.Map, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "I HAVE ARRIVED AT STORE",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            OrderStatus.AT_STORE -> {
                Button(
                    onClick = onAdvanceStep,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusOnlineGreen)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "PICKED UP & START DELIVERY",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            OrderStatus.PICKED_UP -> {
                Button(
                    onClick = onAdvanceStep,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SooGoodOrangePrimary)
                ) {
                    Icon(Icons.Default.Map, contentDescription = null, tint = Color.White)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "I HAVE ARRIVED AT CUSTOMER LOCATION",
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
            }

            OrderStatus.EN_ROUTE_TO_CUSTOMER, OrderStatus.ARRIVED_AT_CUSTOMER -> {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = StatusOnlineGreen.copy(alpha = 0.08f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Enter Customer Delivery OTP",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = StatusOnlineGreen
                            )
                        )
                        Text(
                            text = "Ask customer for the 4-digit code (Default code: 1234)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                            ),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = otpInput,
                            onValueChange = onOtpChange,
                            label = { Text("4-Digit OTP") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            isError = otpError != null,
                            modifier = Modifier.fillMaxWidth(0.7f),
                            shape = RoundedCornerShape(12.dp)
                        )

                        if (otpError != null) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = otpError,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        Button(
                            onClick = onCompleteDelivery,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(50.dp),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusOnlineGreen)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "VERIFY OTP & COMPLETE DELIVERY",
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }

            else -> {}
        }

        // Cancel Order Button
        OutlinedButton(
            onClick = onCancelOrder,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = "Report Issue / Cancel Order",
                color = MaterialTheme.colorScheme.error,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun DeliveryProgressStepper(currentStatus: OrderStatus) {
    val steps = listOf("Store Pickup", "Picked Up", "En Route", "Handover")
    val currentStepIndex = when (currentStatus) {
        OrderStatus.HEADING_TO_STORE -> 0
        OrderStatus.AT_STORE -> 1
        OrderStatus.PICKED_UP -> 2
        OrderStatus.EN_ROUTE_TO_CUSTOMER, OrderStatus.ARRIVED_AT_CUSTOMER -> 3
        else -> 0
    }

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, stepName ->
            val isDone = index <= currentStepIndex
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(24.dp)
                        .background(
                            color = if (isDone) Color.White else Color.White.copy(alpha = 0.3f),
                            shape = CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isDone) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = SooGoodOrangePrimary,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = stepName,
                    color = if (isDone) Color.White else Color.White.copy(alpha = 0.6f),
                    fontSize = 10.sp,
                    fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

fun launchGoogleMapsNavigation(context: Context, address: String, latitude: Double?, longitude: Double?) {
    val hasValidGps = latitude != null && longitude != null &&
            latitude != 0.0 && longitude != 0.0 &&
            !(latitude == 12.9716 && longitude == 77.5946)

    val uriStr = if (hasValidGps) {
        "google.navigation:q=$latitude,$longitude"
    } else {
        "geo:0,0?q=${Uri.encode(address)}"
    }
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uriStr)).apply {
        setPackage("com.google.android.apps.maps")
    }
    try {
        context.startActivity(intent)
    } catch (e: Exception) {
        val query = if (hasValidGps) "$latitude,$longitude" else Uri.encode(address)
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$query"))
        context.startActivity(webIntent)
    }
}

fun launchPhoneCall(context: Context, phoneNumber: String) {
    if (phoneNumber.isNotBlank()) {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${phoneNumber.trim()}"))
        context.startActivity(intent)
    }
}
