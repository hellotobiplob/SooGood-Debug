package `in`.soogood.rider.data.repository

import android.util.Log
import `in`.soogood.rider.data.model.DeliveryOrder
import `in`.soogood.rider.data.model.EarningsSummary
import `in`.soogood.rider.data.model.RiderProfile
import `in`.soogood.rider.data.model.WeeklyEarning
import `in`.soogood.rider.data.model.DbOrder

class RiderRepository(
    private val firebaseRealtimeRepo: FirebaseRealtimeRepository = FirebaseRealtimeRepository()
) {

    fun getInitialProfile(): RiderProfile {
        return RiderProfile(
            id = "SGR-8892",
            name = "Rahul Sharma",
            phone = "+91 98765 43210",
            email = "rahul.rider@soogood.in",
            vehicleType = "Electric Bike (EV)",
            vehicleNumber = "KA 05 SG 9090",
            rating = 4.92,
            totalTripsCompleted = 0,
            isOnline = true,
            isDocumentVerified = true
        )
    }

    fun getInitialEarnings(): EarningsSummary {
        return EarningsSummary(
            todayEarnings = 0.0,
            todayTrips = 0,
            todayHoursOnline = 0.0,
            weeklyEarnings = 0.0,
            targetTripsForBonus = 12,
            bonusAmount = 250.0
        )
    }

    fun getWeeklyEarningsList(): List<WeeklyEarning> {
        return emptyList()
    }

    fun getInitialHistoryOrders(): List<DeliveryOrder> {
        return emptyList()
    }

    suspend fun updateRiderGpsLocation(riderId: String, latitude: Double, longitude: Double, activeOrderId: String? = null): Boolean {
        return firebaseRealtimeRepo.updateRiderGpsLocation(riderId, latitude, longitude, activeOrderId)
    }

    fun broadcastRiderAssignment(
        orderId: String,
        riderId: String,
        riderName: String,
        riderPhone: String,
        status: String = "OUT_FOR_DELIVERY"
    ) {
        firebaseRealtimeRepo.broadcastRiderAssignment(orderId, riderId, riderName, riderPhone, status)
    }

    fun broadcastOrderStatus(orderId: String, status: String) {
        firebaseRealtimeRepo.broadcastOrderStatus(orderId, status)
    }

    suspend fun fetchOrdersFromFirebase(): List<DbOrder> {
        return firebaseRealtimeRepo.fetchOrders()
    }

    companion object {
        private const val TAG = "RiderRepository"
    }
}
