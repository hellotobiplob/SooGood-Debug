package `in`.soogood.rider.data.model

import kotlinx.serialization.Serializable

@Serializable
data class DbUser(
    val id: String? = null,
    val phone: String = "",
    val fullName: String = "",
    val email: String? = null,
    val role: String = "RIDER",
    val password: String = ""
)

@Serializable
data class DbRider(
    val id: String? = null,
    val userId: String = "",
    val partnerCode: String = "",
    val vehicleType: String = "",
    val vehicleNumber: String = "",
    val rating: Double = 5.0,
    val isOnline: Boolean = false,
    val currentLatitude: Double? = null,
    val currentLongitude: Double? = null,
    val isApproved: Boolean = false, // false = Pending Admin Approval
    val status: String = "PENDING"
)

@Serializable
data class DbOrder(
    val id: String? = null,
    val orderNumber: String? = null,
    val storeId: String = "store-1",
    val riderId: String? = null,
    val status: String = "PLACED",
    val subtotalAmount: Double = 250.0,
    val totalAmount: Double = 280.0,
    val deliveryFee: Double = 30.0,
    val tipAmount: Double = 0.0,
    val paymentType: String = "COD",
    val isPaid: Boolean = false,
    val deliveryAddress: String = "123 Main Street, Bangalore",
    val deliveryLatitude: Double? = 12.9716,
    val deliveryLongitude: Double? = 77.5946,
    val customerOtp: String = "4321",
    val pickupInstructions: String? = "Collect from counter #3",
    val deliveryInstructions: String? = "Ring doorbell"
)

@Serializable
data class DbStore(
    val id: String = "store-1",
    val name: String = "SooGood Cloud Kitchen",
    val address: String = "MG Road, Bangalore",
    val latitude: Double = 12.9716,
    val longitude: Double = 77.5946,
    val phone: String = "+91 99999 88888"
)

@Serializable
data class DbOrderItem(
    val id: String? = null,
    val orderId: String = "",
    val itemName: String = "Special Meal",
    val quantity: Int = 1,
    val price: Double = 250.0
)

@Serializable
data class DbMessage(
    val id: String? = null,
    val orderId: String = "",
    val senderRole: String = "RIDER",
    val senderId: String? = null,
    val messageText: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class DbFcmToken(
    val id: String? = null,
    val userId: String? = null,
    val deviceToken: String = "",
    val appType: String = "RIDER"
)
