package `in`.soogood.rider.data.repository

import android.util.Log
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import `in`.soogood.rider.data.model.DbFcmToken
import `in`.soogood.rider.data.model.DbMessage
import `in`.soogood.rider.data.model.DbOrder
import `in`.soogood.rider.data.model.DbOrderItem
import `in`.soogood.rider.data.model.DbRider
import `in`.soogood.rider.data.model.DbStore
import `in`.soogood.rider.data.model.DbUser
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

data class LiveOrderState(
    val orderId: String = "",
    val status: String = "PLACED",
    val riderId: String? = null,
    val riderName: String? = null,
    val riderPhone: String? = null,
    val riderLat: Double? = null,
    val riderLng: Double? = null,
    val estimatedDeliveryMinutes: Int = 30,
    val deliveryOtp: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

class FirebaseRealtimeRepository {

    private fun getDatabase(): FirebaseDatabase {
        return FirebaseDatabase.getInstance("https://soogood-aa18e-default-rtdb.firebaseio.com")
    }

    private fun getOrdersRef(): DatabaseReference = getDatabase().getReference("orders")
    private fun getLiveOrdersRef(): DatabaseReference = getDatabase().getReference("live_orders")
    private fun getRidersRef(): DatabaseReference = getDatabase().getReference("riders")
    private fun getUsersRef(): DatabaseReference = getDatabase().getReference("users")
    private fun getStoresRef(): DatabaseReference = getDatabase().getReference("stores")
    private fun getOrderItemsRef(): DatabaseReference = getDatabase().getReference("order_items")
    private fun getMessagesRef(): DatabaseReference = getDatabase().getReference("messages")
    private fun getFcmTokensRef(): DatabaseReference = getDatabase().getReference("fcm_tokens")

    suspend fun registerNewRider(
        fullName: String,
        phone: String,
        email: String,
        vehicleType: String,
        vehicleNumber: String,
        password: String
    ): Result<Pair<DbUser, DbRider>> {
        return try {
            val userId = getUsersRef().push().key ?: "user-${System.currentTimeMillis()}"
            val riderId = getRidersRef().push().key ?: "rider-${System.currentTimeMillis()}"
            val partnerCode = "SGR-${(1000..9999).random()}"

            val user = DbUser(
                id = userId,
                phone = phone.trim(),
                fullName = fullName.trim(),
                email = if (email.isNotBlank()) email.trim() else null,
                role = "RIDER",
                password = password.trim()
            )

            val rider = DbRider(
                id = riderId,
                userId = userId,
                partnerCode = partnerCode,
                vehicleType = vehicleType,
                vehicleNumber = vehicleNumber.trim().uppercase(),
                rating = 5.0,
                isOnline = false,
                isApproved = false,
                status = "PENDING"
            )

            getUsersRef().child(userId).setValue(user).await()
            getRidersRef().child(riderId).setValue(rider).await()

            Log.d(TAG, "Successfully submitted job application for rider: $partnerCode (Pending Approval)")
            Result.success(Pair(user, rider))
        } catch (e: Exception) {
            Log.e(TAG, "Error applying for rider job in Firebase RTDB", e)
            Result.failure(e)
        }
    }

    suspend fun authenticateRider(phone: String, password: String): Result<Pair<DbUser, DbRider>> {
        return try {
            val cleanPhone = phone.trim()
            val cleanPassword = password.trim()

            // Find user by phone
            val usersSnapshot = getUsersRef().get().await()
            var matchedUser: DbUser? = null
            for (child in usersSnapshot.children) {
                val u = child.getValue(DbUser::class.java)
                if (u != null && u.phone == cleanPhone && u.role == "RIDER") {
                    matchedUser = u
                    break
                }
            }

            if (matchedUser == null || matchedUser.password != cleanPassword) {
                return Result.failure(Exception("Invalid mobile number or password."))
            }

            // Find rider linked to this userId
            val ridersSnapshot = getRidersRef().get().await()
            var matchedRider: DbRider? = null
            for (child in ridersSnapshot.children) {
                val r = child.getValue(DbRider::class.java)
                if (r != null && r.userId == matchedUser.id) {
                    matchedRider = r
                    break
                }
            }

            if (matchedRider == null) {
                return Result.failure(Exception("No delivery partner profile found for this account."))
            }

            if (!matchedRider.isApproved) {
                return Result.failure(Exception("Your job application is pending admin approval. Please wait for confirmation."))
            }

            Log.d(TAG, "Successfully authenticated rider: ${matchedUser.fullName} (${matchedRider.partnerCode})")
            Result.success(Pair(matchedUser, matchedRider))
        } catch (e: Exception) {
            Log.e(TAG, "Error authenticating rider in Firebase RTDB", e)
            Result.failure(e)
        }
    }

    suspend fun fetchOrders(): List<DbOrder> {
        return try {
            val snapshot = getOrdersRef().get().await()
            val list = mutableListOf<DbOrder>()
            for (child in snapshot.children) {
                val order = child.getValue(DbOrder::class.java)
                if (order != null) list.add(order)
            }
            list
        } catch (e: Exception) {
            Log.e(TAG, "Error fetching orders from Firebase RTDB", e)
            emptyList()
        }
    }

    suspend fun fetchAssignedOrAvailableOrders(riderId: String, partnerCode: String): List<DbOrder> {
        val allOrders = fetchOrders()
        if (allOrders.isEmpty()) {
            // Return a default sample simulated order for testing if none exist in Firebase
            return listOf(
                DbOrder(
                    id = "order-sim-1",
                    orderNumber = "SG-7789",
                    storeId = "store-1",
                    status = "PLACED",
                    subtotalAmount = 350.0,
                    totalAmount = 390.0,
                    deliveryFee = 40.0,
                    tipAmount = 20.0,
                    paymentType = "COD",
                    isPaid = false,
                    deliveryAddress = "4th Block, Koramangala, Bengaluru",
                    deliveryLatitude = 12.9352,
                    deliveryLongitude = 77.6245,
                    customerOtp = "5821",
                    pickupInstructions = "Collect from Express Counter #2",
                    deliveryInstructions = "Deliver at apartment lobby security desk"
                )
            )
        }
        return allOrders.filter { order ->
            order.riderId == riderId ||
            order.riderId == partnerCode ||
            (order.riderId == null && order.status in listOf("PLACED", "ACCEPTED", "PREPARING", "READY_FOR_PICKUP"))
        }
    }

    suspend fun updateOrderStatus(orderId: String, status: String): Boolean {
        return try {
            getOrdersRef().child(orderId).child("status").setValue(status).await()
            broadcastOrderStatus(orderId, status)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status in Firebase RTDB", e)
            false
        }
    }

    suspend fun acceptOrder(orderId: String, riderId: String): Boolean {
        return try {
            val updates = mapOf<String, Any>(
                "riderId" to riderId,
                "status" to "HEADING_TO_STORE"
            )
            getOrdersRef().child(orderId).updateChildren(updates).await()
            broadcastOrderStatus(orderId, "HEADING_TO_STORE")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error accepting order in Firebase RTDB", e)
            false
        }
    }

    suspend fun updateRiderDutyStatus(riderId: String, isOnline: Boolean): Boolean {
        return try {
            getRidersRef().child(riderId).child("isOnline").setValue(isOnline).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating rider duty status in Firebase RTDB", e)
            false
        }
    }

    suspend fun updateRiderGpsLocation(riderId: String, latitude: Double, longitude: Double, activeOrderId: String? = null): Boolean {
        if (!activeOrderId.isNullOrBlank()) {
            broadcastRiderLocation(activeOrderId, latitude, longitude)
        }
        return try {
            val updates = mapOf<String, Any>(
                "currentLatitude" to latitude,
                "currentLongitude" to longitude
            )
            getRidersRef().child(riderId).updateChildren(updates).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating rider GPS location in Firebase RTDB", e)
            false
        }
    }

    suspend fun fetchStoreById(storeId: String): DbStore? {
        return try {
            val snapshot = getStoresRef().child(storeId).get().await()
            snapshot.getValue(DbStore::class.java) ?: DbStore()
        } catch (e: Exception) {
            DbStore()
        }
    }

    suspend fun fetchOrderItems(orderId: String): List<DbOrderItem> {
        return try {
            val snapshot = getOrderItemsRef().child(orderId).get().await()
            val list = mutableListOf<DbOrderItem>()
            for (child in snapshot.children) {
                val item = child.getValue(DbOrderItem::class.java)
                if (item != null) list.add(item)
            }
            if (list.isEmpty()) {
                list.add(DbOrderItem(id = "item-1", orderId = orderId, itemName = "SooGood Special Combo", quantity = 1, price = 250.0))
            }
            list
        } catch (e: Exception) {
            listOf(DbOrderItem(id = "item-1", orderId = orderId, itemName = "SooGood Special Combo", quantity = 1, price = 250.0))
        }
    }

    suspend fun fetchMessagesForOrder(orderId: String): List<DbMessage> {
        return try {
            val snapshot = getMessagesRef().child(orderId).get().await()
            val list = mutableListOf<DbMessage>()
            for (child in snapshot.children) {
                val msg = child.getValue(DbMessage::class.java)
                if (msg != null) list.add(msg)
            }
            list.sortedBy { it.createdAt }
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun sendMessage(orderId: String, senderRole: String, senderId: String?, text: String): Boolean {
        return try {
            val msgId = getMessagesRef().child(orderId).push().key ?: "msg-${System.currentTimeMillis()}"
            val msg = DbMessage(
                id = msgId,
                orderId = orderId,
                senderRole = senderRole,
                senderId = senderId,
                messageText = text.trim(),
                createdAt = System.currentTimeMillis()
            )
            getMessagesRef().child(orderId).child(msgId).setValue(msg).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error sending message in Firebase RTDB", e)
            false
        }
    }

    suspend fun registerFcmToken(userId: String?, token: String): Boolean {
        return try {
            val tokenId = getFcmTokensRef().push().key ?: "fcm-${System.currentTimeMillis()}"
            val payload = DbFcmToken(
                id = tokenId,
                userId = userId,
                deviceToken = token,
                appType = "RIDER"
            )
            getFcmTokensRef().child(tokenId).setValue(payload).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun broadcastRiderLocation(orderId: String, lat: Double, lng: Double) {
        if (orderId.isBlank()) return
        val updates = mapOf<String, Any>(
            "riderLat" to lat,
            "riderLng" to lng,
            "updatedAt" to System.currentTimeMillis()
        )
        getLiveOrdersRef().child(orderId).updateChildren(updates)
    }

    fun broadcastRiderAssignment(
        orderId: String,
        riderId: String,
        riderName: String,
        riderPhone: String,
        status: String = "OUT_FOR_DELIVERY"
    ) {
        if (orderId.isBlank()) return
        val updates = mapOf<String, Any>(
            "riderId" to riderId,
            "riderName" to riderName,
            "riderPhone" to riderPhone,
            "status" to status,
            "updatedAt" to System.currentTimeMillis()
        )
        getLiveOrdersRef().child(orderId).updateChildren(updates)
    }

    fun broadcastOrderStatus(orderId: String, status: String) {
        if (orderId.isBlank()) return
        val updates = mapOf<String, Any>(
            "status" to status,
            "updatedAt" to System.currentTimeMillis()
        )
        getLiveOrdersRef().child(orderId).updateChildren(updates)
    }

    fun observeLiveOrder(orderId: String): Flow<LiveOrderState?> = callbackFlow {
        if (orderId.isBlank()) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (!snapshot.exists()) {
                    trySend(null)
                    return
                }

                try {
                    val status = snapshot.child("status").getValue(String::class.java) ?: "PLACED"
                    val riderId = snapshot.child("riderId").getValue(String::class.java)
                    val riderName = snapshot.child("riderName").getValue(String::class.java)
                    val riderPhone = snapshot.child("riderPhone").getValue(String::class.java)
                    val riderLat = snapshot.child("riderLat").getValue(Double::class.java)
                    val riderLng = snapshot.child("riderLng").getValue(Double::class.java)
                    val eta = snapshot.child("estimatedDeliveryMinutes").getValue(Int::class.java) ?: 30
                    val otp = snapshot.child("deliveryOtp").getValue(String::class.java) ?: ""
                    val time = snapshot.child("updatedAt").getValue(Long::class.java) ?: System.currentTimeMillis()

                    val liveState = LiveOrderState(
                        orderId = orderId,
                        status = status,
                        riderId = riderId,
                        riderName = riderName,
                        riderPhone = riderPhone,
                        riderLat = riderLat,
                        riderLng = riderLng,
                        estimatedDeliveryMinutes = eta,
                        deliveryOtp = otp,
                        updatedAt = time
                    )
                    trySend(liveState)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing live order snapshot in Rider App", e)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e(TAG, "Rider live order listener cancelled: ${error.message}")
            }
        }

        getLiveOrdersRef().child(orderId).addValueEventListener(listener)

        awaitClose {
            getLiveOrdersRef().child(orderId).removeEventListener(listener)
        }
    }

    companion object {
        private const val TAG = "FirebaseRealtimeRiderRepo"
    }
}
