# Task List: Redesign Login Screen & Admin Approval Flow

- [x] Update FirebaseModels to include password and approval status in DbUser/DbRider
- [x] Update FirebaseRealtimeRepository for phone & password authentication and pending approval registration
- [x] Update RiderViewModel methods for login and job application
- [x] Redesign OnboardingScreen with mobile number (10 digits, starting with 6-9), password, and Apply Job option below login screen
- [x] Build and verify compilation and deployment
- [x] Create walkthrough artifact
