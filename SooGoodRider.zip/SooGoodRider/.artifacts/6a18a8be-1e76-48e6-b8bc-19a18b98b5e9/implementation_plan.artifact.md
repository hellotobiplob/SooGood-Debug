# Redesign Login Screen with Mobile Number (6-9) & Password + Apply Job / Admin Approval Flow

## Goal Description
Redesign the rider login screen to use Mobile Number (strict 10 digits starting with 6-9) and Password. Below the login form, add an explicit "Apply for Job" option. When a rider applies, their application is submitted to the admin for approval.

## User Review Required

> [!IMPORTANT]
> - **Login Fields**: Mobile Number (10 digits starting with 6, 7, 8, or 9) + Password (replacing Partner Code).
> - **Apply Job Option**: Placed clearly below the login form.
> - **Admin Approval Workflow**: New applications are saved with `isApproved = false` (or `status = "PENDING"`), and logging in before admin approval shows a pending approval status message.

## Proposed Changes

### Data Models & Repository
- #### [MODIFY] [FirebaseModels.kt](file:///C:/Users/Biplob/AndroidStudioProjects/SooGoodRider/app/src/main/java/in/soogood/rider/data/model/FirebaseModels.kt)
  - Add `password: String = ""` to `DbUser` or `DbRider`.
  - Add `isApproved: Boolean = false` (or `status: String = "PENDING"`) to `DbRider` for admin approval tracking.
- #### [MODIFY] [FirebaseRealtimeRepository.kt](file:///C:/Users/Biplob/AndroidStudioProjects/SooGoodRider/app/src/main/java/in/soogood/rider/data/repository/FirebaseRealtimeRepository.kt)
  - Update `registerNewRider` to store password and set `isApproved = false` (pending admin approval).
  - Update `authenticateRider` to authenticate by `phone` and `password`, checking if `isApproved` is true (or allowing login with a helpful pending message if unapproved).

### ViewModel & UI
- #### [MODIFY] [RiderViewModel.kt](file:///C:/Users/Biplob/AndroidStudioProjects/SooGoodRider/app/src/main/java/in/soogood/rider/ui/viewmodel/RiderViewModel.kt)
  - Update `loginWithSupabase` (rename/refactor to `loginWithFirebase(phone, password)`) and `registerWithSupabase` (`registerNewRider(fullName, phone, email, vehicleType, vehicleNumber, password)`).
- #### [MODIFY] [OnboardingScreen.kt](file:///C:/Users/Biplob/AndroidStudioProjects/SooGoodRider/app/src/main/java/in/soogood/rider/ui/screens/OnboardingScreen.kt)
  - Redesign Login Form:
    - Mobile Number field with strict validation: 10 digits, must start with `[6-9]`.
    - Password field (obscured text).
    - "Apply for Job" option/button placed below the login form.
  - Apply Job / Registration Form:
    - Full Name, Mobile Number (10 digits starting with 6-9), Email, Password, Vehicle Type, Vehicle Number.
    - Submit application to admin for approval.

## Verification Plan

### Automated Tests
- Run `./gradlew :app:compileDebugKotlin` and `./gradlew :app:assembleDebug` to verify compilation.

### Manual Verification
- Deploy app to connected device, test entering invalid mobile numbers (e.g. starting with 1-5 or not 10 digits), test successful registration (pending admin approval), and test login with mobile number and password.
